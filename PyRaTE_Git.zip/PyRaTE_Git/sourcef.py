#----------------------------------------------------------------------------# 
#  NAME:                                                                     #
#                                                                            #
#  sourcef.py                                                                #
#                                                                            #
#                                                                            #
#  DESCRIPTION:                                                              #
#                                                                            #
#  Python script for calculating the continuum source function (SourceF_c)   #
#  and extinction coefficient (ExtinctCoef_c) for free-free continuum and    #
#  dust radiation as well as the line emission coefficient (EmisCoef_l)      #
#  and absorbtion coefficient (AbsorCoef_l) corrected for stimulated         #
#  emission.                                                                 # 
#                                                                            #
#  If the degree of ionization is zero, then SourceF_c is the continuum      #
#  source function for dust emission and ExtinctCoef_c is the extinction     #
#  coefficient for dust.                                                     #
#                                                                            #
#  The contribution of scattered radiation is included, if the radiation     #
#  density has been previously determined.                                   #
#                                                                            #
#  PARAMETERS:                                                               #
#                                                                            #
#     Input : Freq, r,z, NofF,K                                              #
#     Output : ExtinctCoef_c, SourceF_c, AbsorCoef_l, EmisCoef_l, DLX-Z,XR   #
#                                                                            #
#  COMMENTS:                                                                 #
#                                                                            #
#  Einstein relations:                                                       #
#     g1 * B12 = g2 * B21                                                    #
#     A21 = 2*h*c * Freq**3 * B21                                            #
#                                                                            #
#  Definition of line absorbtion (AbsorCoef_l) and emission coefficients     #
#  (EmisCoef_l):                                                             #
#                                                                            #
# AbsorCoef_l = h*c/(4*PI) * Freq * (n1*B12 - n2*B21) * profile              #
# EmisCoef_l = n2*A21 / (n1*B12 - n2*B21) = 2*h*c*Freq**3 * n2/(g2*n1-g1*n2) #
#                                                                            #
#        *** EmisCoef_l==S_line                                              #
#        *** AbsorCoef_l==Line_abs                                           #
#                                                                            #
#  The "profile" as a function of Freq is treated outside this program.      #
#  Here it is assumed that "profile" = 1.                                    #
#                                                                            #
#  AUTHOR:                                                                   #           
#                                                                            #
#  Aris E. Tritsis                                                           #
#  (Aris.Tritsis@anu.edu.au)                                                 #
#                                                                            #
#  Harold Yorke                                                              #
#                                                                            #
#         THIS SCRIPT IS BASED ON THE RELEVANT SUBROUTINE OF THE             #
#                     FORTRAN CODE "CORELINE"                                #
#----------------------------------------------------------------------------#

#----------------------------------------------------------------------------#
import numpy as np                                                           #
import dust                                                                  #
import planck                                                                #
from scipy.constants import h, c, m_p                                        #
                                                                             #
#- - - - - - - - - - - - - -Convert to cgs- - - - - - - - - - - - - - - - - -#
h=h*1.e+7                                                                    #
c=c*1.e+2                                                                    #
m_p=m_p*1e+3                                                                 #
                                                                             #
#----------------------------------------------------------------------------#


#----------------------------------------------------------------------------#
#                                                                            #
#     Calculate the exponent in Planck's function and take cases to see if   #
#            it reduces to Wien's law or Rayleigh-Jeans law                  #
#                                                                            #
def sourcef(T, freq, dens_grid_point, Xrat, Einstein_A, mol_grid_point, X_DoI, g1, g2, LTE):
                                                                             #
	B_v = planck.planck(T, freq)                                         #
                                                                             #
	#- - - - - - - - - - -call "Dust" subroutine- - - - - - - - - - - - -# 
                                                                             #
	S_c, k_ext=dust.dust(freq, T, dens_grid_point, B_v)                  #
                                                                             #
	S_c=S_c/(k_ext+1.E-37)                                               #
                                                                             #
	#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - #
                                                                             #
	S_line = 2.*h*c**2*freq**3 * Xrat/(g2/g1-Xrat)                       #
                                                                             #
	#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - #
	Abundance = mol_grid_point/(1.+Xrat)                                 #
	                                                                     #
	Line_abs = g2/g1*Abundance*Einstein_A/(8.*np.pi*freq**2)*(1.-(g1/g2)*Xrat)
	#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - #
	#   If non-negligible ionization then figure out its contribution.   #
	#        Use Kirchhoff's law to determine source function.           # 
        #                                                                    #
	#     Absorption coefficient for free-free emision from Spitzer:     #
	if (X_DoI > 1e-3):                                                   #
                                                                             #
		EXT1=0.                                                      #
                                                                             #
		TGAS15=T**1.5                                                #
                                                                             #
		ENP=((dens_grid_point/m_p)*X_DoI)**2                         #
                                                                             #
		GFF=max(1., 0.5513*(np.log(TGAS15/freq)-6.4))                #
                                                                             #
		k_ext_i=1.9798E-23*GFF*ENP/(TGAS15*freq**2)                  #
                                                                             #
	#- - -Combination of both emission from both dust and ionized gas- - #
		S_c=k_ext*B_v+EXT1*S_c                                       #
                                                                             #
		k_ext=k_ext+k_ext_i                                          #
                                                                             #
		S_c=S_c/k_ext                                                #
                                                                             #
	return S_c, k_ext, S_line, Line_abs                                  # 
#----------------------------------------------------------------------------#

