#-------------------------------------------------------------------------------#  
#  NAME:                                                                        #
#                                                                               #
#  units_ch.py                                                                  #
#                                                                               #
#                                                                               #
#  DESCRIPTION:                                                                 #
#                                                                               #
#           small python script for changing the units                          #
#                                                                               #
#  PARAMETERS:                                                                  #
#                                                                               #
#     Input : units, PPV, beam_size, freq0, freq_range0                         #
#     Output : PPV                                                              # 
#                                                                               #
#  AUTHOR:                                                                      #            
#                                                                               #
#  Aris E. Tritsis                                                              #
#  (Aris.Tritsis@anu.edu.au)                                                    #
#                                                                               #
#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -#
#                                                                               #
#       "In radio astronomy, an important quantity is the power received        #
#      by the telescope, which is the product of the flux density Sv and        #
#       the effective telescope area. The unit of the flux density is           #
#                             [Sv] = W m^{-2} Hz^{-1}                           #
#        which is the amount of energy incident on a unit surface per           #
#      unit time and unit frequency. Since the measured flux densities are      #
#     tiny, one conventionally uses the unit called Jy:                         #
#       10^{-26} W m^{-2} Hz^{-1} = 10^{-23} erg s^{-1} Hz^{-1} cm^{-2} = 1 Jy. #
#                                                                               #
#         The term 'density' in the above definition refers to the              #
#                    'spectral density', i.e. the fact that                     #
#    this quantity describes the flux per unit bandwidth, or unit frequency.    #
#                                                                               #
#                        -----------------                                      #
#                        | Pv dv = kT dv |                                      #
#                        -----------------                                      #
#                                                                               #
#    This is the famous Nyquist law which says that a resistor at temperature   #
#       T produces a noise power kT dv per unit bandwidth. Equating this to     #
#                  the power produced by the incoming flux                      #
#                       density Sv, we have:                                    #
#                                                                               #
#                   ---------------------------                                 #
#                   | k TA Dv=(A_eff Sv Dv)/2 |  =>                             #
#                   ---------------------------                                 #
#                                                                               #
#                   ---------------------------                                 #
#                   |    Sv=2*k/A_eff Tv      |                                 #
#                   ---------------------------                                 #
#      This relates the flux density of a source to the antenna temperature.    #
#      For a given flux density, it depends on the size of the telescope,       #
#                  viz. its total collecting area.                              #
#                                                                               #
#                                                                               #
#     The known effective area of the telescope now also delivers its beam      #
#                        solid angle                                            #
#                   Omega_A=lambda^2/A_eff"                                     #
#                                                                               #
#         Radio astronomy: tools, applications and impacts (U.Klein)            #
#                                                                               #
#     Beam solid angle can be computed from telescope's diameter as:            #
#             Omega_A=(pi/4)*(b*lambda/D)^2  where b=1/sqrt(ln2)                #
#                                                                               #
#               Beam size can be computed from diameter as:                     #
#                            beam_size=b*lambda/D                               #
#                                                                               #
#       You may also wish to add aperture efficency etc when post-processing.   #
#                       Some useful relations are:                              #
#		   Ageo=np.pi/4*D**2  & itta=A_eff/Ageo                         #
#-------------------------------------------------------------------------------#

#-------------------------------------------------------------------------------#
import numpy as np                                                              #
from scipy.constants import c, k                                                #
		                                                                #
c=c*1e+2                                                                        #  
K_b=k*1.e+7                                                                     #     
#-------------------------------------------------------------------------------#

#-------------------------------------------------------------------------------#
#         Fix the units here according to user's preferences                    #
def units_ch(units, PPV, beam_size, freq0, freq_range0):                        #
		                                                                #
	#                     convert to mJy                                    #
		                                                                #
	if units==1:                                                            #
		                                                                #
		PPV=np.array(PPV)                                               #
		                                                                #
		PPV=PPV/c*1e+2/freq0                                            #
		                                                                #
	#                convert to antenna temperature                         #
	elif units==2:                                                          #
		#   first compute the effective area of the telescope etc       #
		#   D is the diameter of the telescope which can be found       #
		#   from the beam size already defined. Once D is found         #
		#   we can the find the beam solid angle, then the effective    #
		#                  area and finally T_A                         #
		b=1./np.sqrt(np.log(2.))                                        #
		                                                                #
		#    **  for simplicity and for convinience the diameter   **   #
		#    **  of the telescope is computed from the beam size   **   #
		#    **  and the rest frequency of the line. The proper    **   #
		#    **  treatment would be of course to define D and then **   #
		#    **  the beam size as a function of wavelength.However,**   #
		#    **  beacause it does not vary much and in the         **   #
		#    **  literature people usualy give the beam size       **   #
		#    **  instead of D we choose to do the same for         **   #
		#    **  the convinience of the user.                      **   #
		beam_size=beam_size/3600.*np.pi/180.                            #
		                                                                #		
		D=b*(c/freq0)/beam_size                                         #
		                                                                #
		Omega_A=(np.pi/4)*(b*(c/freq0)/D)**2                            #
		                                                                #
		A_eff=(c/freq0)**2/Omega_A                                      #
		                                                                #
		PPV=np.array(PPV)                                               #
		                                                                #
		PPV=PPV/c                                                       #
		                                                                #
		Ageo=np.pi*D**2                                                 #
		                                                                #
		itta=A_eff/Ageo                                                 #
		                                                                #
		T_A = PPV/(2*K_b)*(c/freq0)**2/(4*np.pi)                        #
		                                                                #
		T_mb= T_A/itta                                                  #
		                                                                #
		PPV = T_mb                                                      #  
	else:                                                                   #
		                                                                #
		PPV=PPV                                                         #
		                                                                #
	return PPV                                                              #
#-------------------------------------------------------------------------------#


