#----------------------------------------------------------------------------# 
#  NAME:                                                                     #
#                                                                            #
#  turbulence.py                                                             #
#                                                                            #
#                                                                            #
#  DESCRIPTION:                                                              #
#                                                                            #
#  Python script for calculating microturbulence to add on the thermal       #
#  width. In this version we either add a single number everywhere or        #
#  we get the distribution of velocities for microturbulence from a          #  
#  Gaussian 1D distribution P(v)=[1/v_0*pi^0.5]*exp(-v^2/v_0^2) where v_0    #
#  is the microturbulent component (Schatzman & Magnan 1975).                #
#                                                                            #
#          http://adsabs.harvard.edu/abs/1975A%26A....38..373S               #
#                                                                            #
#  PARAMETERS:                                                               #
#                                                                            #
#     Input : geom, Dfreq_thermal, freq0                                     #
#             velx, vely, velz                                               #
#     Output : Dfreq_thermal (new width of the line-other than due to        #
#              Doppler broadening-not just thermal)                          # 
#                                                                            #
#  AUTHOR:                                                                   #           
#                                                                            #
#  Aris E. Tritsis                                                           #
#  (Aris.Tritsis@anu.edu.au)                                                 #
#                                                                            #
#----------------------------------------------------------------------------#

#----------------------------------------------------------------------------#
import numpy as np                                                           #
from scipy.constants import c                                                #
import sys                                                                   #
                                                                             #
c=c*1.e+2                                                                    #
#                                                                            #
#         v_type --> If 0 then "microturbulence" will be a constant number   #
#                    everywhere based on min(velocity)*mturbv_param          #
#                                                                            #
#                    If 1 then "microturbulence" will be drawn from a        #
#                    top hat distribution in the interval                    #
#                            [min(velocity), min(velocity)*mturbv_param]     #
#                                                                            #
#                    If 2 then it will be drawn from a gaussian distribution.#
#                                                                            #
#      !!!    Feel free to change an play around with the above     !!!      #
#----------------------------------------------------------------------------#

#----------------------------------------------------------------------------#
def turbulence(geom, Dfreq_thermal, velx, vely, velz, freq_0, v_type, mturbv_param):
                                                                             #
	if np.nanmin((np.abs(velx), np.abs(vely), np.abs(velz)))<=10.:       #
                                                                             #
		print (" "*20+"Minimum velocity in the grid is ridiculously small.")
                                                                             #
		print (" "*20+"Consider changing 'np.nanmin' to 'np.nanmean' in 'turbulence.py'.")
                                                                             #
		print (" "*20+"If small velocities ok for your problem just ignore")
                                                                             #
	dv_thermal=Dfreq_thermal/freq_0*c                                    #
                                                                             #
	if geom==0:                                                          #
                                                                             #
		if v_type==0:                                                #
                                                                             #
			atot=np.sqrt(dv_thermal**2.+(np.nanmin(np.abs(velx))*mturbv_param)**2)
                                                                             #
		elif v_type==1:                                              #
                                                                             #
			interval=(np.nanmin(np.abs(velx))*mturbv_param-np.nanmin(np.abs(velx)))*np.random.random_sample(velx.shape[0])+np.nanmin(np.abs(velx))                                                               #
			atot=np.sqrt(dv_thermal**2.+interval**2)             #
                                                                             #
		elif v_type==2:                                              #
	                                                                     #
			atot=np.sqrt(dv_thermal**2.+(np.random.randn(velx.shape[0])*np.nanmin(np.abs(velx))*mturbv_param)**2)
	                                                                     #
		else:                                                        #
			raise SystemExit("'v_type==1' must be an integer in in [0, 2]")
	elif geom==1:                                                        #
                                                                             #
		if v_type==0:                                                #
                                                                             #
			atot=np.sqrt(dv_thermal**2.+(np.nanmin((np.abs(velx), np.abs(vely)))*mturbv_param)**2)
                                                                             #
		elif v_type==1:                                              #
	                                                                     #
			interval=(np.nanmin((np.abs(velx),np.abs(vely)))*mturbv_param-np.nanmin((np.abs(velx),np.abs(vely))))*np.random.random_sample(velx.shape)+np.nanmin((np.abs(velx),np.abs(vely)))                          #
	                                                                     #
			atot=np.sqrt(dv_thermal**2.+interval**2)             #
	                                                                     #
		elif v_type==2:                                              #
                                                                             #
			atot=np.sqrt(dv_thermal**2.+(np.random.randn(velx.shape)*np.nanmin((np.abs(velx), np.abs(vely)))*mturbv_param)**2)
		else:                                                        #
			raise SystemExit("'v_type==1' must be an integer in in [0, 2]")
                                                                             #
	else:                                                                #
                                                                             #
		if v_type==0:                                                #
                                                                             #
			atot=np.sqrt(dv_thermal**2.+(np.nanmin((np.abs(velx), np.abs(vely), np.abs(velz)))*mturbv_param)**2)
                                                                             #
		elif v_type==1:                                              #
	                                                                     #
			interval=(np.nanmin((np.abs(velx), np.abs(vely), np.abs(velz)))*mturbv_param-np.nanmin((np.abs(velx), np.abs(vely), np.abs(velz))))*np.random.random_sample(velx.shape)+np.nanmin((np.abs(velx), np.abs(vely), np.abs(velz)))
	                                                                     #
			atot=np.sqrt(dv_thermal**2.+interval**2)             #
	                                                                     #
		elif v_type==2:                                              #
                                                                             #
			atot=np.sqrt(dv_thermal**2.+(np.random.randn(velx.shape)*np.nanmin((np.abs(velx), np.abs(vely), np.abs(velz)))*mturbv_param)**2)                                                   #
		else:                                                        #
			raise SystemExit("'v_type==1' must be an integer in in [0, 2]")
                                                                             #
	return atot*freq_0/c                                                 #
#----------------------------------------------------------------------------#
