#----------------------------------------------------------------------------# 
#  NAME:                                                                     #
#                                                                            #
#  plank.py                                                                  #
#                                                                            #
#                                                                            #
#  DESCRIPTION:                                                              #
#                                                                            #
#  Python script for calculating thermal emission                            #
#                                                                            #
#  PARAMETERS:                                                               #
#                                                                            #
#     Input : freq, T                                                        #
#     Output : B_v                                                           #
#                                                                            #
#  AUTHOR:                                                                   #           
#                                                                            #
#  Aris E. Tritsis                                                           #
#  (Aris.Tritsis@anu.edu.au)                                                 #
#                                                                            #
#  Harold Yorke                                                              #
#                                                                            #
#         THIS SCRIPT IS BASED ON THE RELEVANT SUBROUTINE OF THE             #
#                     FORTRAN CODE "CORELINE"                                #
#----------------------------------------------------------------------------#

#----------------------------------------------------------------------------#
import numpy as np                                                           #
import dust                                                                  #
from scipy.constants import h, c, k                                          #
                                                                             #
#- - - - - - - - - - - - - -Convert to cgs- - - - - - - - - - - - - - - - - -#
h=h*1.e+7                                                                    #
c=c*1.e+2                                                                    #
K_b=k*1.e+7                                                                  #
                                                                             #
#----------------------------------------------------------------------------#


#----------------------------------------------------------------------------#
#                                                                            #
#     Calculate the exponent in Planck's function and take cases to see if   #
#            it reduces to Wien's law or Rayleigh-Jeans law                  #
#                                                                            #
def planck(T, freq):                                                         #
                                                                             #
	exponent=h*c*freq/(K_b*T)                                            #
                                                                             #
	if exponent>=0.1:                                                    #
                                                                             #
		if exponent>=50:                                             #
                                                                             #
			B_v=0.                                               #
		else:                                                        #
			B_v=2*h*c**2*freq**3*np.exp(-exponent)/(1.-np.exp(-exponent))
                                                                             #
	#- - - -for (hv/kT)<1 Taylor expand e^(hv/kT) and compute B_v from- -#
	#- - - - - - - - - from Rayleigh-Taylor's law- - - - - - - - - - - - #     
	else:			                                             #
		Taylor=1.-exponent*(.5-exponent*(8.33333333333333333333e-2-exponent**2*1.38888888888888888889e-3))
                                                                             #
		B_v=freq**2*T*Taylor*2*h*c**2/(h*c/K_b)                      #
                                                                             #
	return B_v                                                           #
#----------------------------------------------------------------------------#
