#-------------------------------------------------------------------------# 
#  NAME:                                                                  #
#                                                                         #
#  sim_import.py                                                          #
#                                                                         #
#                                                                         #
#  DESCRIPTION:                                                           #
#                                                                         #
#   This routine exports all data from the simulations in numpy arrays    #
#    So, what we will do is read a file given in "path" and then          #
#        make numpy arrays of abundance as a function of r, z             #
#    density as a function of x/r(y,z/z) and velocities as a              #
#                      function of x/r(y,z/z)                             #
#                                                                         #
#  PARAMETERS:                                                            #
#                                                                         #
#     Input: path, level, molecule, geom, dictionary                      #
#     Output: dens, mol, velx, vely, velz, x, y, z, T                     #
#                                                                         #
#  AUTHOR:                                                                #           
#                                                                         #
#  Aris E. Tritsis                                                        #
#  (Aris.Tritsis@anu.edu.au)                                              #
#                                                                         #
#-------------------------------------------------------------------------#

#-------------------------------------------------------------------------#
from yt.mods import *                                                     #
import numpy as np                                                        #
from scipy.constants import m_p, parsec                                   #
import sys                                                                #
import os                                                                 #
                                                                          #
m_p=m_p*1e+3                                                              #
parsec=parsec*1e+2                                                        #
#-------------------------------------------------------------------------#

#-------------------------------------------------------------------------#
def sim_import(path, level, molecule, geom, dictionary):                  #
                                                                          #
	for keys, values in dictionary.items():                           #
       		if values == molecule:                                    #
       	    		sp=keys                                           #
	#     construct the grid and take what you came here to take      #
	pf=load('{}'.format(path))                                        #
	                                                                  #
	dd=pf.all_data()                                                  #
	                                                                  #
	#-----------------------------------------------------------------#
	#			                                          #
	#                      Spherical                                  #
	#			                                          #
	#-----------------------------------------------------------------#
	if geom==0:                                                       #
						                          #
		dims=pf.domain_dimensions*pf.refine_by**level             # 
			                                                  #
		dims=[dims[0], 1, 1]                                      #
			                                                  #
		cube=pf.covering_grid(level, left_edge=pf.domain_left_edge, dims=dims)
			                                                  #
		#- - - - - - - - - - - - Density- - - - - - - - - - - - - #
		density=cube['dens']                                      #
			                                                  #
		density=np.array(density)                                 #
			                                                  #
		dens=density.reshape(dims[0])                             #
			                                                  #
		dens=np.array(dens)                                       #
				                                          #
		size=dens.shape                                           #
		#- - - - - - - - - - - -Abundance- - - - - - - - - - - - -#
		mol=cube[sp]                                              #
			                                                  #
		mol=np.array(mol)                                         #
			                                                  #
		mol=mol.reshape(dims[0])                                  #
				                                          #
		mol=np.array(mol)                                         #
		#- - - - - - - - -r-velocity component - - - - - - - - - -#
		velx=cube['velx']                                         #
					                                  #
		velx=np.array(velx)                                       #
					                                  #
		velx=velx.reshape(dims[0])                                #
					                                  #
		velx=np.array(velx)                                       #
		#- - - - - - - - - - - -temperature- - - - - - - - - - - -#
		T=cube['temperature']                                     #
					                                  #
		T=np.array(T)                                             #
					                                  #
		T=T.reshape(dims[0])                                      #
					                                  #
		T=np.array(T)                                             #
		#- - - - - - - - - -r coordinate - - - - - - - - - - - - -#
		x=dd['r']                                                 #
						                          #
		x=np.array(x)                                             #
						                          #
		x=np.linspace(min(x), max(x), len(dens))                  #
		#- - - - - - - - - - -Projections- - - - - - - - - - - - -#
		dens2, mol2, velx2, T2=dens[::-1], mol[::-1], velx[::-1], T[::-1]
				                                          #
		velx=-velx                                                #
				                                          #
		dens, mol, velx, T=np.hstack((dens2, dens)), np.hstack((mol2, mol)), np.hstack((velx2, velx)),  np.hstack((T2, T))
				                                          #
		x2=-x[::-1]                                               #
				                                          #
		x=np.hstack((x2, x))                                      #
				                                          #
		y, z, vely, velz = x.copy(), None, None, None             #
	#-----------------------------------------------------------------#
	#			                                          #
	#                      Cylindrical                                #
	#			                                          #
	#-----------------------------------------------------------------#
	elif geom==1:                                                     #
						                          #
		dims=pf.domain_dimensions*pf.refine_by**level             # 
			                                                  #
		dims=[dims[0], dims[1], 1]                                #
			                                                  #
		cube=pf.covering_grid(level, left_edge=pf.domain_left_edge, dims=dims)
			                                                  #
		#- - - - - - - - - - - - Density- - - - - - - - - - - - - #
		density=cube['dens']                                      #
			                                                  #
		density=np.array(density)                                 #
			                                                  #
		dens=density.reshape(dims[0], dims[1])                    #
			                                                  #
		dens=np.rot90(dens)                                       #
				                                          #
		dens=np.array(dens)                                       #
				                                          #
		size=dens.shape                                           #
		#- - - - - - - - - - - -Abundance- - - - - - - - - - - - -#
		mol=cube[sp]                                              #
			                                                  #
		mol=np.array(mol)                                         #
			                                                  #
		mol=mol.reshape(dims[0], dims[1])                         #
			                                                  #
		mol=np.rot90(mol)                                         #
				                                          #
		mol=np.array(mol)                                         #
		#- - - - - - - - -r-velocity component - - - - - - - - - -#
		velx=cube['velx']                                         #
					                                  #
		velx=np.array(velx)                                       #
					                                  #
		velx=velx.reshape(dims[0], dims[1])                       #
					                                  #
		velx=np.rot90(velx)                                       #
					                                  #
		velx=np.array(velx)                                       #
		#- - - - - - - - -z-velocity component - - - - - - - - - -#
		velz=cube['vely']                                         #
					                                  #
		velz=np.array(velz)                                       #
					                                  #
		velz=velz.reshape(dims[0], dims[1])                       #
					                                  #
		velz=np.rot90(velz)                                       #
					                                  #
		velz=np.array(velz)                                       #
		#- - - - - - - - - - - -temperature- - - - - - - - - - - -#
		T=cube['temperature']                                     #
					                                  #
		T=np.array(T)                                             #
					                                  #
		T=T.reshape(dims[0], dims[1])                             #
					                                  #
		T=np.rot90(T)                                             #
					                                  #
		T=np.array(T)                                             #
		#- - - - - - - - - -r coordinate - - - - - - - - - - - - -#
		x=dd['r']                                                 #
						                          #
		x=np.array(x)                                             #
						                          #
		x=np.linspace(min(x), max(x), (size[1]))                  #
		#- - - - - - - - - - -z coordinate - - - - - - - - - - - -#
		z=dd['z']                                                 #
						                          #
		z=np.array(z)                                             #
						                          #
		z=np.linspace(min(z), max(z), size[0])                    #
						                          #
		#- - - - - - - - - - -Projections- - - - - - - - - - - - -#
		dens2, mol2, velz2, velx2, T2=dens[::-1], mol[::-1], -velz[::-1], velx[::-1], T[::-1]
		                                                          #
		dens,mol,velz,velx=np.vstack((dens, dens2)),np.vstack((mol, mol2)),np.vstack((velz, velz2)),np.vstack((velx, velx2))
		                                                          #
		T=np.vstack((T, T2))                                      #
	                                                                  #
		dens2, mol2, velz2, velx2, T2=np.fliplr(dens), np.fliplr(mol), np.fliplr(velz), np.fliplr(velx), np.fliplr(T)
	                                                                  #
		dens,mol,velz,velx=np.hstack((dens2, dens)),np.hstack((mol2, mol)),np.hstack((velz2, velz)),np.hstack((velx2, -velx))
	                                                                  #
		T=np.hstack((T2, T))                                      #
	                                                                  #
		velz=velz[::-1]                                           #
	                                                                  #
		x2, z2=-x[::-1], -z[::-1]                                 #
	                                                                  #
		x, z=np.hstack((x2, x)), np.hstack((z2, z))               #
	                                                                  #
		y, vely = z.copy(), None                                  #
	#-----------------------------------------------------------------#
	#			                                          #
	#                        Cartesian                                #
	#			                                          #
	#-----------------------------------------------------------------#
	else:                                                             #
		if pf.dimensionality==3:                                  #
			                                                  #
			dims=pf.domain_dimensions*pf.refine_by**level     #
			                                                  #
			dims=[dims[0], dims[1], dims[2]]                  #
					                                  #
			cube=pf.covering_grid(level, left_edge=pf.domain_left_edge, dims=dims)
					                                  #
			#- - - - - - - - - Density- - - - - - - - - - - - #
			density=cube['dens']                              #
					                                  #
			density=np.array(density)                         #
					                                  #
			dens=density.reshape(dims[0], dims[1], dims[2])   #
					                                  #
			dens=np.rot90(dens)                               #
						                          #
			dens=np.array(dens)                               #
						                          #
			size=dens.shape                                   #
			#- - - - - - - - - -Abundance- - - - - - - - - - -#
			mol=cube[sp]                                      #
					                                  #
			mol=np.array(mol)                                 #
					                                  #
			mol=mol.reshape(dims[0], dims[1], dims[2])        #
					                                  #
			mol=np.rot90(mol)                                 #
						                          #
			mol=np.array(mol)                                 #
			#- - - - - - - - x-velocity component - - - - - - #
			velx=cube['velx']                                 #
							                  #
			velx=np.array(velx)                               #
							                  #
			velx=velx.reshape(dims[0], dims[1], dims[2])      #
						                          #
			velx=np.rot90(velx)                               #
							                  #
			velx=np.array(velx)                               #
			#- -  - - - -y-velocity component - - - - - - - - #
			vely=cube['vely']                                 #
							                  #
			vely=np.array(vely)                               #
							                  #
			vely=vely.reshape(dims[0], dims[1], dims[2])      #
							                  #
			vely=np.rot90(vely)                               #
						                          #
			vely=np.array(vely)                               #
			#- - - - - - - -z-velocity component - - - - - - -#
			velz=cube['velz']                                 #
							                  #
			velz=np.array(velz)                               #
							                  #
			velz=velz.reshape(dims[0], dims[1], dims[2])      #
							                  #
			velz=np.rot90(velz)                               #
						                          #
			velz=np.array(velz)                               #
			#- - - -  - - - - - -temperature- - - - - - - - - #
			T=cube['temperature']                             #
							                  #
			T=np.array(T)                                     #
							                  #
			T=T.reshape(dims[0], dims[1], dims[2])            #
							                  #
			T=np.rot90(T)                                     #
						                          #
			T=np.array(T)                                     #
			#- - - - - - - - - -x coordinate - - - - - - - - -#
			x=dd['x']                                         #
								          #
			x=np.array(x)                                     #
							                  #
			x=np.linspace(min(x), max(x), size[1])            #
			#- - - - - - - - - -y coordinate - - - - - - - - -#
			y=dd['y']                                         #
								          #
			y=np.array(y)                                     #
								          #
			y=np.linspace(min(y), max(y), size[0])            #
			#- - - - - - - - - -z coordinate - - - - - - - - -#
			z=dd['z']                                         #
								          #
			z=np.array(z)                                     #
								          #
			z=np.linspace(min(z), max(z), size[2])            #
								          #
		elif pf.dimensionality==2:                                #
						                          #
			dims=pf.domain_dimensions*pf.refine_by**level     # 
					                                  #
			dims=[dims[0], dims[1], 1]                        #
					                                  #
			cube=pf.covering_grid(level, left_edge=pf.domain_left_edge, dims=dims)
					                                  #
			#- - - - - - - - - - - - Density- - - - - - - - - #
			density=cube['dens']                              #
					                                  #
			density=np.array(density)                         #
					                                  #
			dens=density.reshape(dims[0], dims[1])            #
					                                  #
			dens=np.rot90(dens)                               #
						                          #
			dens=np.array(dens)                               #
						                          #
			size=dens.shape                                   #
			#- - - - - - - - - - - -Abundance- - - - - - - - -#
			mol=cube[sp]                                      #
					                                  #
			mol=np.array(mol)                                 #
					                                  #
			mol=mol.reshape(dims[0], dims[1])                 #
					                                  #
			mol=np.rot90(mol)                                 #
						                          #
			mol=np.array(mol)                                 #
			#- - - - - - - - - x-velocity component - - - - - #
			velx=cube['velx']                                 #
							                  #
			velx=np.array(velx)                               #
							                  #
			velx=velx.reshape(dims[0], dims[1])               #
						                          #
			velx=np.rot90(velx)                               #
							                  #
			velx=np.array(velx)                               #
			#- - - - - - - -y-velocity component - - - - - - -#
			vely=cube['vely']                                 #
							                  #
			vely=np.array(vely)                               #
							                  #
			vely=vely.reshape(dims[0], dims[1])               #
							                  #
			vely=np.rot90(vely)                               #
						                          #
			vely=np.array(vely)                               #
			#- - - - - - - -z-velocity component - - - - - - -#
			velz=vely.copy()                                  #
						                          #
			#- - - -  - - - - - -temperature- - - - - - - - - #
			T=cube['temperature']                             #
							                  #
			T=np.array(T)                                     #
							                  #
			T=T.reshape(dims[0], dims[1])                     #
							                  #
			T=np.rot90(T)                                     #
						                          #
			T=np.array(T)                                     #
			#- - - - - - - - - -x coordinate - - - - - - - - -#
			x=dd['x']                                         #
								          #
			x=np.array(x)                                     #
							                  #
			x=np.linspace(min(x), max(x), size[1])            #
			#- - - - - - - - - -y coordinate - - - - - - - - -#
			y=dd['y']                                         #
								          #
			y=np.array(y)                                     #
								          #
			y=np.linspace(min(y), max(y), size[0])            #
			#- - - - - - - - - -z coordinate - - - - - - - - -#
			z=y.copy()                                        #
								          #
			#- - - - - - - - - - - - - - - - - - - - - - - - -#
			#                                                 #
			#  Rendering 1...Starting with a 2D array we      #
			#  create the 3rd dimension as if we had periodic #
		        #  boundary conditions and the sheet is a slice   #
			#  through a cube. Please modify to suit your     #
			#  needs                                          #
			#                                                 #
			#  Rendering 2...Starting with a 2D array we      #
			#  create the 3rd dimension as if we had periodic #
		        #  boundary conditions. So, the second value in   #
			#  the 3rd dimension is the 2nd value in the x    #
			#  direction. Thus (i, j=0)=(i=0, j=0, k)         #
			#- - - - - - - - - - - - - - - - - - - - - - - - -#
			dens3D=[]                                         #
								          #
			mol3D=[]                                          #
								          #
			velx3D=[]                                         #
								          #
			vely3D=[]                                         #
								          #
			velz3D=[]                                         #
								          #
			T3D=[]                                            #
								          #
			for i in range (0, len(dens)):                    #
								          #
                                dens3D.append(dens)                       #
								          #
                                mol3D.append(mol)                         #
								          #
                                velx3D.append(velx)                       #
								          #
                                vely3D.append(vely)                       #
								          #
                                velz3D.append(velz)                       #
								          #
                                T3D.append(T)                             #
								          #		
				#dens3D.append(np.roll(dens, -i, axis=1)) #
								          #
				#mol3D.append(np.roll(mol, -i, axis=1))   #
								          #
				#velx3D.append(np.roll(velx, -i, axis=1)) #
								          #
				#vely3D.append(np.roll(vely, -i, axis=1)) #
								          #
				#velz3D.append(np.roll(velz, -i, axis=1)) #
								          #
				#T3D.append(np.roll(T, -i, axis=1))       #
								          #
			dens=np.array(dens3D)                             #
								          #
			mol=np.array(mol3D)                               #
								          #
			velx=np.array(velx3D)                             #
								          #
			vely=np.array(vely3D)                             #
								          #
			velz=np.array(velz3D)                             #
								          #
			T=np.array(T3D)                                   #
	#-----------------------------------------------------------------#
						                          #
	time=np.array(pf.current_time)                                    #
						                          #
	time=np.round(np.multiply(time, 3.16887646e-14), 2)               #
						                          #
	print (" "*10), ("="*78)                                          #
	print (" "*25),"time for the file you gave me is", time, "Myrs"   #
	print (" "*25), ("-"*42)                                          #
	print (" "*15), "the molecule under consideration is", molecule, "or", sp, "in code language"
	print (" "*10), ("="*78)                                          #
						                          #
	del cube, dims                                                    #
						                          #
	return dens, mol, velx, vely, velz, x, y, z, T                    #
#-------------------------------------------------------------------------#
