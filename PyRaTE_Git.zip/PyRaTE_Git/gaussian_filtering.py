#----------------------------------------------------------------------------# 
#  NAME:                                                                     #
#                                                                            #
#  gaussian_filtering.py                                                     #
#                                                                            #
#                                                                            #
#  DESCRIPTION:                                                              #
#                                                                            #
#  Python script for lowering the spatial resolution of a map                #
#  with a gaussian filter.                                                   #
#                                                                            #
#                                                                            #
#  PARAMETERS:                                                               #
#                                                                            #
#     Input : Final integrated emission map, grid resolution                 #
#     Output : The map after gaussian filtering                              #
#                                                                            #
#  AUTHOR:                                                                   #           
#                                                                            #
#  Aris E. Tritsis                                                           #
#  (Aris.Tritsis@anu.edu.au)                                                 #
#                                                                            #
#----------------------------------------------------------------------------#


#----------------------------------------------------------------------------#
import numpy as np                                                           #
from scipy import ndimage                                                    #
from scipy.constants import parsec                                           #
import sys                                                                   #
                                                                             #
parsec=parsec*1e+2                                                           #
#- - - - - -Parameters for Gaussian filtering to lower resolution- - - - - - #
autopc=4.8481367817e-6                                                       #
                                                                             #
def gaussian_filtering(resolution, emission_map, beam_size, distance):       #
                                                                             #
	desired_resolution=beam_size*distance*autopc                         #
                                                                             #
	resolution=resolution/parsec/2.                                      #
                                                                             #
	FWHM=desired_resolution/resolution                                   #
                                                                             #
	sigma=FWHM/(2.*np.sqrt(2.*np.log(2.)))                               #
                                                                             #
	emission_map=ndimage.filters.gaussian_filter(emission_map, sigma=sigma, mode='constant')
                                                                             #
	return emission_map                                                  #
#----------------------------------------------------------------------------#
