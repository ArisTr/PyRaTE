#----------------------------------------------------------------------------# 
#  NAME:                                                                     #
#                                                                            #
#  populations_cylDB.py                                                      #
#                                                                            #
#                                                                            #
#  DESCRIPTION:                                                              #
#                                                                            #
#  Python script for calculating the ratio between the population densities  #
#  through an iterative process (CYLINDRICAL GEOMETRY).                      #
#                                                                            #
#  1. Assume beta                                                            #
#  2. Compute dtau_l                                                         #
#  3. Compute tau_l as the sum of dtau_l for dv_ij < Dfreq_thermal           #
#                                                                            #
#         With "dv_ij < Dfreq_thermal" we basically assume a                 #
#         step function for the profile.    ^                                #
#                                           |  f(v)                          #
#              1/2v_th Dv<v_th          ____|____                            #
#     f(v) = {                          |   |   |                            #
#              0 otherwise       _______|   |   |________                    #
#                                                                            #
#  4. Compute PopRat from tau_l                                              #
#  5. Circle back and check if (PopRat_b-PopRat_a)> tollerance               #
#                                                                            #
#  PARAMETERS:                                                               #
#                                                                            #
#     Input : dens, Einstein_A, C21, freq_0, Dfreq_thermal, T, mol,          #
#             velx, vely, velz, dist, geom, y, g1, g2, amu_mean, cmb         #
#     Output : PopRat                                                        # #                                                                            #
#  AUTHOR:                                                                   #           
#                                                                            #
#  Aris E. Tritsis                                                           #
#  (Aris.Tritsis@anu.edu.au)                                                 #
#                                                                            #
#----------------------------------------------------------------------------#

#----------------------------------------------------------------------------#
#         g1                                                                 #
#   C21 = -- * C12*e^(E/k_B*T)                                               #
#         g2                                                                 #
#   ____________________________________________________  2                  #
#      ^         |            |            ^       |                         #
#      | B12*I   |  B21*I     |  A21       | C12   | C21                     #
#      |         |            |            |       |                         #
#      |         v            v            |       v                         #
#   ----------------------------------------------------  1                  #
#                                                                            #
#   How the population in n2 change? equilibrium from what excites           #
#   & de-excites:                                                            #
#                                                                            #
#   dn2/dt=0=-n2*A21*beta+n1*n_H2*C12-n2*n_H2*C21 =>                         #
#                                                                            #
#   n2*(A21*beta+n_H2*C21)=n1*n_H2*C12 =>                                    #      
#                                                                            #
#   n2*(A21*beta+n_H2*C21)=n1*n_H2*C21*e^(-E/k_B*T)*(g2/g1) =>               #     
#                                                                            #
#   n2/n1= n_H2*C21*e^(-E/k_B*T)*(g2/g1)/(A21*beta+n_H2*C21) =>              #
#                                                                            #
#   _______________________________________                                  #
#   |                                     |                                  #
#   | n2      (g2/g1)*e^(-E/k_B*T)        |                                  #
#   | -- = ------------------------------ |                                  #
#   | n1   {1 + [A21/(n_H2*C21)]*beta}    |                                  #
#   _______________________________________                                  #
#                                                                            #
#                     =>                                                     #
#                                                                            #
#   ___________________________________________________                      #
#   |                                                 |                      #
#   |           n_H2*C21    g2*n1                     |                      #
#   |beta =    {--------* [ ----- * e^(-E/k_B*T)-1] } |                      #
#   |             A21       g1*n2                     |                      #
#   ___________________________________________________                      #
#                                                                            #
#                                                                            #
#    where beta is the escape probability                                    # 
#----------------------------------------------------------------------------#


#----------------------------------------------------------------------------#
import numpy as np                                                           #
from scipy.constants import h, c, k, m_p                                     #
from mpi4py import MPI                                                       #
import sys                                                                   #
from scipy.optimize import root                                              #
                                                                             #
comm = MPI.COMM_WORLD                                                        #
iproc=comm.Get_rank()                                                        #
nproc=comm.Get_size()                                                        #
                                                                             #
#- - - - - - - - - - - - - -Convert to cgs- - - - - - - - - - - - - - - - - -#
h=h*1.e+7                                                                    #
c=c*1.e+2                                                                    #
K_b=k*1.e+7                                                                  #
m_p=m_p*1e+3                                                                 #
tols=np.array([1e-5, 5e-5, 1e-4, 5e-3])                                      #
                                                                             #
Tcmb=2.7255                                                                  #
method='lm'   # 'lm', 'broyden1', 'broyden2', 'anderson', 'linearmixing'     #
              # 'krylov', 'diagbroyden', 'excitingmixin', 'df-sane'          #
#----------------------------------------------------------------------------#

#----------------------------------------------------------------------------#
def populations_cylDB(dens, Einstein_A, Cij, cij, freq0_DB, Dfreq_thermal_DB, T, mol, velr, velz, dist, geom, z, gij, amu_mean, cmb):                                                                        #
                                                                             #
	#       beta_0 is the initial guess for the "1rst" grid point.       #
	#  However, the initial guess for the 2nd grid point is the final    #
	#           beta computed for the first grid point.                  #
                                                                             #
	beta_0=np.ones(8)*0.5                                                #
                                                                             #
	pds_init = np.ones(8)/np.linspace(2, 18, 8)                          # 
                                                                             #
	dv_thermal = []                                                      #
                                                                             #
	for n in range (0, len(freq0_DB)):                                   #
                                                                             #
		dv_thermal.append(Dfreq_thermal_DB[n]/freq0_DB[n]*c)         #
                                                                             #
	dv_thermal=np.array(dv_thermal)                                      #
                                                                             #
	if cmb==True:                                                        #
                                                                             #
		exp_cmb=1./(np.exp(h*freq0_DB*c/(K_b*2.725))-1.)             #
	else:                                                                #
                                                                             #
		exp_cmb=np.zeros(len(freq0_DB))                              #
                                                                             #
	Texcit = freq0_DB*h*c/K_b                                            #
                                                                             #
	TexcitDiff = []                                                      #
                                                                             #
	Dumtexcit = Texcit[0]                                                #
                                                                             #
	for m in range (1, len(Texcit)):                                     #
                                                                             #
		Dumtexcit = Dumtexcit + Texcit[m]                            #
                                                                             #
		TexcitDiff.append(Dumtexcit)                                 #
                                                                             #
	grat=[]                                                              #
                                                                             #
	for m in range (0, len(gij)):                                        #
                                                                             #
		temp = []                                                    #
                                                                             #
		for n in range (0, len(gij)):                                #
                                                                             #
			temp.append(gij[m]/gij[n])                           #
                                                                             #
		grat.append(temp)                                            #
                                                                             #
	grat = np.array(grat)                                                #
                                                                             #
	TexcitDiff = np.array(TexcitDiff)                                    #
                                                                             #
	CMB = Einstein_A*exp_cmb                                             #
                                                                             #
	def equations(x, molgp, densgp, Tgp, beta):                          #
                                                                             #
		n0, n1, n2, n3, n4, n5, n6, n7 = x                           #
                                                                             #
		eq1 = n0 + n1 + n2 + n3 + n4 + n5 + n6 + n7 - 1.             #
                                                                             #
		#                 For n0                                     #
		eq2 = Einstein_A[0]*n1 + Cij(Tgp)[0]*densgp*(n1-grat[1, 0]*np.exp(-Texcit[0]/Tgp)*n0)+Einstein_A[0]*(1-beta[0])*(n1-grat[1, 0]*n0)/(n0/n1*grat[1, 0]-1) + densgp*(cij(Tgp)[0]*n2+cij(Tgp)[1]*n3+cij(Tgp)[3]*n4+cij(Tgp)[6]*n5+cij(Tgp)[10]*n6+cij(Tgp)[15]*n7)-densgp*n0*(grat[2, 0]*cij(Tgp)[0]*np.exp(-TexcitDiff[0]/Tgp)+grat[3, 0]*cij(Tgp)[1]*np.exp(-TexcitDiff[1]/Tgp)+grat[4, 0]*cij(Tgp)[3]*np.exp(-TexcitDiff[2]/Tgp)+grat[5, 0]*cij(Tgp)[6]*np.exp(-TexcitDiff[3]/Tgp)+grat[6, 0]*cij(Tgp)[10]*np.exp(-TexcitDiff[4]/Tgp)+grat[7, 0]*cij(Tgp)[15]*np.exp(-TexcitDiff[5]/Tgp))+CMB[0]*beta[0]*(n1-grat[1, 0]*n0)                                      #
                                                                             #
		#                 For n1                                     #
		eq3 = Einstein_A[1]*n2-Einstein_A[0]*n1+Cij(Tgp)[1]*densgp*(n2-grat[2, 1]*np.exp(-Texcit[1]/Tgp)*n1)+Cij(Tgp)[0]*densgp*(grat[1, 0]*n0*np.exp(-Texcit[0]/Tgp)-n1)+Einstein_A[0]*(1-beta[0])/(grat[1, 0]*n0/n1-1.)*(grat[1, 0]*n0-n1)+Einstein_A[1]*(1-beta[1])/(grat[2, 1]*n1/n2-1.)*(n2-grat[2, 1]*n1) + densgp*(cij(Tgp)[2]*n3+cij(Tgp)[4]*n4+cij(Tgp)[7]*n5+cij(Tgp)[11]*n6+cij(Tgp)[16]*n7) - densgp*n1*(grat[3, 1]*cij(Tgp)[2]*np.exp(-(TexcitDiff[1]-Texcit[0])/Tgp)+grat[4, 1]*cij(Tgp)[4]*np.exp(-(TexcitDiff[2]-Texcit[0])/Tgp)+grat[5, 1]*cij(Tgp)[7]*np.exp(-(TexcitDiff[3]-Texcit[0])/Tgp)+grat[6, 1]*cij(Tgp)[11]*np.exp(-(TexcitDiff[4]-Texcit[0])/Tgp)+grat[7, 1]*cij(Tgp)[16]*np.exp(-(TexcitDiff[5]-Texcit[0])/Tgp))+CMB[0]*beta[0]*(grat[1, 0]*n0-n1)+CMB[1]*beta[1]*(n2-grat[2, 1]*n1)         #
                                                                             #
		#                 For n2                                     #
		eq4 = Einstein_A[2]*n3-Einstein_A[1]*n2+Cij(Tgp)[2]*densgp*(n3-grat[3, 2]*n2*np.exp(-Texcit[2]/Tgp))+Cij(Tgp)[1]*densgp*(grat[2, 1]*n1*np.exp(-Texcit[1]/Tgp)-n2)+Einstein_A[1]*(1-beta[1])/(grat[2, 1]*n1/n2-1.)*(grat[2, 1]*n1-n2)+Einstein_A[2]*(1-beta[2])/(grat[3, 2]*n2/n3-1.)*(n3-grat[3, 2]*n2)-cij(Tgp)[0]*densgp*n2+n0*densgp*grat[2, 0]*cij(Tgp)[0]*np.exp(-TexcitDiff[0]/Tgp) + densgp*(cij(Tgp)[5]*n4+cij(Tgp)[8]*n5+cij(Tgp)[12]*n6+cij(Tgp)[17]*n7) - densgp*n2*(grat[4, 2]*cij(Tgp)[5]*np.exp(-(TexcitDiff[2]-TexcitDiff[0])/Tgp)+grat[5, 2]*cij(Tgp)[8]*np.exp(-(TexcitDiff[3]-TexcitDiff[0])/Tgp)+grat[6, 2]*cij(Tgp)[12]*np.exp(-(TexcitDiff[4]-TexcitDiff[0])/Tgp)+grat[7, 2]*cij(Tgp)[17]*np.exp(-(TexcitDiff[5]-TexcitDiff[0]))/Tgp) +CMB[1]*beta[1]*(grat[2, 1]*n1-n2)+CMB[2]*beta[2]*(n2-grat[3, 2]*n3)
                                                                             #
		#                 For n3                                     #
		eq5 = Einstein_A[3]*n4-Einstein_A[2]*n3+Cij(Tgp)[3]*densgp*(n4-grat[4, 3]*n3*np.exp(-Texcit[3]/Tgp))+Cij(Tgp)[2]*densgp*(grat[3, 2]*n2*np.exp(-Texcit[2]/Tgp)-n3) +Einstein_A[2]*(1-beta[2])/(grat[3, 2]*n2/n3-1.)*(grat[3, 2]*n2-n3)+Einstein_A[3]*(1-beta[3])/(grat[4, 3]*n3/n4-1.)*(n4-grat[4, 3]*n3) + densgp*(cij(Tgp)[9]*n5+cij(Tgp)[13]*n6+cij(Tgp)[18]*n7) - densgp*n3*(grat[5, 3]*cij(Tgp)[9]*np.exp(-(TexcitDiff[3]-TexcitDiff[1])/Tgp)+grat[6, 3]*cij(Tgp)[13]*np.exp(-(TexcitDiff[4]-TexcitDiff[1])/Tgp)+grat[7, 3]*cij(Tgp)[18]*np.exp(-(TexcitDiff[5]-TexcitDiff[1])/Tgp))- n3*densgp*(cij(Tgp)[1]+cij(Tgp)[2]) + densgp*n0*grat[3, 0]*cij(Tgp)[1]*np.exp(-TexcitDiff[1]/Tgp) + densgp*n1*grat[3, 1]*cij(Tgp)[2]*np.exp(-(TexcitDiff[1]-Texcit[0])/Tgp)+CMB[2]*beta[2]*(grat[3, 2]*n2-n3)+CMB[3]*beta[3]*(n4-grat[4, 3]*n3)
                                                                             #
		#                 For n4                                     #
		eq6 = Einstein_A[4]*n5-Einstein_A[3]*n4+Cij(Tgp)[4]*densgp*(n5-grat[5, 4]*n4*np.exp(-Texcit[4]/Tgp))+Cij(Tgp)[3]*densgp*(grat[4, 3]*n3*np.exp(-Texcit[3]/Tgp)-n4)+Einstein_A[3]*(1-beta[3])/(grat[4, 3]*n3/n4-1.)*(grat[4, 3]*n3-n4)+Einstein_A[4]*(1-beta[4])/(grat[5, 4]*n4/n5-1.)*(n5-grat[5, 4]*n4) +densgp*cij(Tgp)[3]*(np.exp(-TexcitDiff[2]/Tgp)*n0-n4) + densgp*(cij(Tgp)[14]*n6+cij(Tgp)[19]*n7) - densgp*n4*(grat[6, 4]*cij(Tgp)[14]*np.exp(-(TexcitDiff[4]-TexcitDiff[2])/Tgp)+grat[7, 4]*cij(Tgp)[19]*np.exp(-(TexcitDiff[5]-TexcitDiff[2])/Tgp)) - n4*densgp*(cij(Tgp)[3]+cij(Tgp)[4]+cij(Tgp)[5]) + densgp*n0*grat[4, 0]*cij(Tgp)[3]*np.exp(-TexcitDiff[2]/Tgp) + densgp*n1*grat[4, 1]*cij(Tgp)[4]*np.exp(-(TexcitDiff[2]-Texcit[0])/Tgp) + densgp*n2*grat[4, 2]*cij(Tgp)[5]*np.exp(-(TexcitDiff[2]-TexcitDiff[0])/Tgp) +CMB[3]*beta[3]*(grat[4, 3]*n3-n4)+CMB[4]*beta[4]*(n5-grat[5, 4]*n4)                                               #
                                                                             #
		#                 For n5                                     #
		eq7 = Einstein_A[5]*n6-Einstein_A[4]*n5+Cij(Tgp)[5]*densgp*(n6-grat[6, 5]*n5*np.exp(-Texcit[5]/Tgp))+Cij(Tgp)[4]*densgp*(grat[5, 4]*n4*np.exp(-Texcit[4]/Tgp)-n5)+Einstein_A[4]*(1-beta[4])/(grat[5, 4]*n4/n5-1.)*(grat[5, 4]*n4-n5)+Einstein_A[5]*(1-beta[5])/(grat[6, 5]*n5/n6-1.)*(n6-grat[6, 5]*n5) + densgp*cij(Tgp)[20]*n7 - densgp*n5*(grat[7, 5]*cij(Tgp)[20]*np.exp(-(TexcitDiff[5]-TexcitDiff[3])/Tgp))-n5*densgp*(cij(Tgp)[6]+cij(Tgp)[7]+cij(Tgp)[8]+cij(Tgp)[9]) + densgp*n0*grat[5, 0]*cij(Tgp)[6]*np.exp(-TexcitDiff[3]/Tgp) + densgp*n1*grat[5, 1]*cij(Tgp)[7]*np.exp(-(TexcitDiff[3]-Texcit[0])/Tgp) + densgp*n2*grat[5, 2]*cij(Tgp)[8]*np.exp(-(TexcitDiff[3]-TexcitDiff[0])/Tgp) + densgp*n3*grat[5, 3]*cij(Tgp)[9]*np.exp(-(TexcitDiff[3]-TexcitDiff[1])/Tgp) +CMB[4]*beta[4]*(grat[5, 4]*n4-n5)+CMB[5]*beta[5]*(n6-grat[6, 5]*n5)
                                                                             #
		#                 For n6                                     #
		eq8 = Einstein_A[6]*n7-Einstein_A[5]*n6+Cij(Tgp)[6]*densgp*(n7-grat[7, 6]*n6*np.exp(-Texcit[6]/Tgp))+Cij(Tgp)[5]*densgp*(grat[6, 5]*n5*np.exp(-Texcit[5]/Tgp)-n6)+Einstein_A[5]*(1-beta[5])/(grat[6, 5]*n5/n6-1.)*(grat[6, 5]*n5-n6)+Einstein_A[6]*(1-beta[6])/(grat[7, 6]*n6/n7-1.)*(n7-grat[7, 6]*n6) - n6*densgp*(cij(Tgp)[10]+cij(Tgp)[11]+cij(Tgp)[12]+cij(Tgp)[13]+cij(Tgp)[14]) + densgp*n0*grat[6, 0]*cij(Tgp)[10]*np.exp(-TexcitDiff[4]/Tgp) + densgp*n1*grat[6, 1]*cij(Tgp)[11]*np.exp(-(TexcitDiff[4]-Texcit[0])/Tgp) + densgp*n2*grat[6, 2]*cij(Tgp)[12]*np.exp(-(TexcitDiff[4]-TexcitDiff[0])/Tgp) + densgp*n3*grat[6, 3]*cij(Tgp)[13]*np.exp(-(TexcitDiff[4]-TexcitDiff[1])/Tgp) + densgp*n4*grat[6, 4]*cij(Tgp)[14]*np.exp(-(TexcitDiff[4]-TexcitDiff[2])/Tgp)                              #
                                                                             #
		return eq1, eq2, eq3, eq4, eq5, eq6, eq7, eq8                #
	#--------------------------------------------------------------------#
	#                                                                    #
	#             !!!         CYLINDRICAL         !!!                    #
        #                                                                    #
	#--------------------------------------------------------------------#
						                             #
	size = dens.shape                                                    #
				                                             #
	chopped_zs=np.empty(size[0]/nproc, dtype=np.float64)                 #
                                                                             #
	comm.Scatter([z, MPI.DOUBLE], [chopped_zs, MPI.DOUBLE])              #
                                                                             #
	PopRat=[]                                                            #
                                                                             #
	for i in range (0, len(chopped_zs)):                                 #
                                                                             #
		index=np.where(z==chopped_zs[i])[0][0]                       #
                                                                             #
		temp=[]                                                      #
                                                                             #
		for j in range (0, len(dens[0])):                            #
                                                                             #
			pds_a = root(equations, x0=(pds_init), args=(mol[index, j], dens[index, j], T[index, j], beta_0), method=method, tol=1.e-5).x                                                                 #
			#  with that specific population densities ratio go  #
			#     and compute dt_l*dist for all grid points      #
			dummy=False                                          #
						                             #
			counter=0                                            #
						                             #
			while (dummy==False):                                #
			                                                     #
				counter=counter+1                            #
						                             #
				dt_l=[]                                      #
						                             #
				for m in range (0, len(pds_a)-1):            #
								             #
					Abundance = mol/(1.+pds_a[m+1]/pds_a[m])
                                                                             #
					Line_abs_temp = gij[m+1]/gij[m]*Abundance*Einstein_A[m]/(8.*np.pi*freq0_DB[m]**3)*(1.-(gij[m]/gij[m+1])*pds_a[m+1]/pds_a[m])/dv_thermal[m]                                      #
					dt_l.append(Line_abs_temp*dist)      #
                                                                             #
				# Now compare which are one thermal linewidth#
				#   away. Do this towards both directions.   #
				dt_l=np.array(dt_l, dtype=np.float64)        #
			                                                     #
				t_line = []                                  #
                                                                             #
				for k in range (0, len(dt_l)):               #
                                                                             #
					t_line_right=dt_l[k, i, np.where(abs(velr[index, j]-velr[index, j+1:len(velr[0])]) < dv_thermal[k, index, j+1:len(velr[0])])].sum()                                                     #
					t_line_left=dt_l[k, i, np.where(abs(velr[index, j]-velr[index, -len(velr[0]):j]) < dv_thermal[k, index, -len(velr[0]):j])].sum()                                                         #
					t_line_up=dt_l[k, np.where(abs(velz[index, j]-velz[index+1:len(velz), j]) < dv_thermal[k, index+1:len(velz), j]), j].sum()                                                                #
					t_line_down=dt_l[k, np.where(abs(velz[index, j]-velz[-len(velz):index, j]) < dv_thermal[k, -len(velz):index, j]), j].sum()                                                                #
					t_line.append(np.nanmin((t_line_right, t_line_left, t_line_up, t_line_down)))
									     #
				t_line = np.array(t_line)                    #
								             #
				t_line[np.where(np.isnan(t_line)==True)[0]]=0.
							                     #
				beta_0 = np.exp(-t_line)                     #  
								             #
				beta_0[beta_0>1.] = 1.                       #
								             #
				pds_a[np.where(np.isnan(pds_a)==True)[0]]=0. #
								             #       
				pds_b = root(equations, x0=(pds_init), args=(mol[index, j], dens[index, j], T[index, j], beta_0), method=method, tol=1.e-5).x                                                                 #
				pds_b[pds_b<1e-20] = 0.                      #
								             #
				check = np.absolute(pds_b[0:4]-pds_a[0:4])/pds_b[0:4]
								             #
				check[np.isfinite(check)==False]=0.          #
								             #
				check[check==1] = 0.                         #
								             #
				if np.all(check<=tols):                      #
							                     #
					dummy=True                           #
								             #
				if counter>=80:                              #
					                                     #
					raise SystemExit("I am having troubles converging!! The last two values of population ratios computed were {} and {}. Perhaps try reducing the tollerance or changing the initial guess?".format(pds_a, pds_b))
						                             #
				pds_a=pds_b*0.7+pds_a*0.3                    #
						                             #
			temp.append(pds_b)                                   #
			                             	                     #
		PopRat.append(temp)                          	             #
					                                     #
	return np.array(PopRat)                                              #
#----------------------------------------------------------------------------#


