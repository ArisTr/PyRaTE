#----------------------------------------------------------------------------# 
#  NAME:                                                                     #
#                                                                            #
#  PPV.py                                                                    #
#                                                                            #
#                                                                            #
#  DESCRIPTION:                                                              #
#                                                                            #
#  Python script for creting a PPV cube or postprocessing one if the         #
#  the geometry is such that a PPV cube is already created during            #
#  ray-tracing.                                                              #
#                                                                            #
#                                                                            #
#  PARAMETERS:                                                               #
#                                                                            #
#     Input : The PPV cube, freq_range, r, noise, ppv                        #
#     Output : slices in each velocity                                       #
#                                                                            #
#  AUTHOR:                                                                   #           
#                                                                            #
#  Aris E. Tritsis                                                           #
#  (tritsis@physics.uoc.gr)                                                  #
#                                                                            #
#----------------------------------------------------------------------------#

#----------------------------------------------------------------------------#
import numpy as np                                                           #
from scipy import interpolate                                                #
import gaussian_noise                                                        #
import gaussian_filtering                                                    #
                                                                             #
def func(xx, yy):                                                            #
	return np.sqrt(xx**2+yy**2)                                          #
#----------------------------------------------------------------------------#
		                                                              
#----------------------------------------------------------------------------#
def PPV(freq_range, emission, r, noise, ppv, beam, eSNR, mean, beam_size, distance):
		                                                             #
	print('\n')                                                          #
	print(" "*20+"Starting post-processing. This may take a while...")   #
		                                                             #
	if emission.ndim==2:                                                 #
		                                                             #
		X=np.linspace(min(r), max(r), len(r))                        #
				                                             #
		Y=X.copy()                                                   #
				                                             #
		X, Y=np.meshgrid(X, Y)                                       #
		                                                             #
		#------------------------------------------------------------#
		#      spherical and cylindrical-face on cases               #
		#------------------------------------------------------------#
		if ppv==True:                                                #
				                                             #
			grid_z=interpolate.griddata(r, emission, func(X, Y), method='nearest', fill_value=0.)
				                                             #
			grid_z1 = grid_z[::-1]                               #
				                                             #
			miso1=np.vstack((grid_z1, grid_z))                   #
				                                             #
			miso2= np.rot90(miso1, 2)                            #
				                                             #
			PPV=np.hstack((miso2, miso1))                        #
		                                                             #
			if noise==True:                                      #
			#- -if noise is "true" we will add gaussian noise- - #
			#- - - - - - - - - - - -to the data- - - - - - - - - #
				PPV_new=[]                                   #
				                                             #
				for i in range (0, len(PPV)):                #
				                                             #
					temp=[]                              #
				                                             #
					for j in range (0, len(PPV[0])):     #
				                                             #
						ILOS=PPV[i, j, :]            #
						                             #
						ILOS=gaussian_noise.gaussian_noise(ILOS, np.mean(PPV), eSNR, mean)
						                             #
						temp.append(ILOS)            #
						                             #
					PPV_new.append(temp)                 #
						                             #
				PPV=np.array(PPV_new)                        #
						                             #
		#- - - - - - -Here to do integrated emission map- - - - - - -#
		#- - - - -use of the same symbols only for convenience- - - -#
		else:                                                        #
			emission_map=[]                                      #
						                             #
			for j in range (0, len(r)):                          #
				                                             #
				emission_map.append(np.trapz(emission[j], freq_range))
				                                             #
			emission_map=np.array(emission_map)                  #
			                                                     #
			grid_z=interpolate.griddata(r, emission_map, func(X, Y), method='cubic')
			                                                     #
			grid_z1 = grid_z[::-1]                               # 
			                                                     #
			miso1=np.vstack((grid_z1, grid_z))                   #
			                                                     #
			miso2= np.rot90(miso1, 2)                            #
			                                                     #
			PPV=np.hstack((miso2, miso1))                        #
		                                                             #
		if beam==True:                                               #
			                                                     #
			resolution=r[1]-r[0]                                 #
			                                                     #
			if isinstance(PPV[0][0], np.ndarray or list)==False: #
			                                                     #
				PPV[np.isnan(PPV)]=0.                        #
			                                                     #
				PPV=gaussian_filtering.gaussian_filtering(resolution, PPV, beam_size, distance)		
			else:                                                #
			                                                     #
				PPVnew=[]                                    #
			                                                     #
				for i in range (0, len(PPV[0, 0])):          #
			                                                     #
					PPVnew=gaussian_filtering.gaussian_filtering(resolution, PPV[:, :, i], beam_size, distance)
			                                                     #
				PPV=np.array(PPVnew)                         #
		                                                             #
	elif emission.ndim==3:                                               #
		#------------------------------------------------------------#
		#    cartesian and cylindrical-fi!=90 cases                  #
		#------------------------------------------------------------#
				                                             #
		if ppv==True:                                                #
				                                             #
			PPV=np.array((emission))                             #
		                                                             #
			if noise==True:                                      #
			#- -if noise is "true" we will add gaussian noise- - #
			#- - - - - - - - - - - -to the data- - - - - - - - - #
				PPV_new=[]                                   #
				                                             #
				for i in range (0, len(PPV)):                #
				                                             #
					temp=[]                              #
				                                             #
					for j in range (0, len(PPV[0])):     #
				                                             #
						ILOS=PPV[i, j, :]            #
						                             #
						ILOS=gaussian_noise.gaussian_noise(ILOS, np.mean(PPV), eSNR, mean)
						                             #
						temp.append(ILOS)            #
						                             #
					PPV_new.append(temp)                 #
						                             #
				PPV=np.array(PPV_new)                        #
						                             #
		#- - - - - - -Here to do integrated emission map- - - - - - -#
		#- - - - -use of the same symbols only for convenience- - - -#
		else:                                                        #
			PPV=np.array((emission))                             #
						                             #
			PPV_new=[]                                           #
						                             #
			for i in range (0, len(PPV)):                        #
				                                             #
				rows=[]                                      #
				                                             #
				for j in range (0, len(PPV[0])):             #
				                                             #
					rows.append(np.trapz(PPV[i, j, :], freq_range))
				                                             #
				PPV_new.append(rows)                         #
				                                             #
			PPV=np.array(PPV_new)                                # 
		                                                             #
		if beam==True:                                               #
			                                                     #
			resolution=r[1]-r[0]                                 #
			                                                     #
			if isinstance(PPV[0, 0],  np.ndarray or list)==False:#
			                                                     #
				PPV[PPV==np.nan]=0.                          #
			                                                     #
				PPV=gaussian_filtering.gaussian_filtering(resolution, PPV, beam_size, distance)		
			else:                                                #
			                                                     #
				PPVnew=[]                                    #
			                                                     #
				for i in range (0, len(PPV[0, 0])):          #
			                                                     #
					PPVnew=gaussian_filtering.gaussian_filtering(resolution, PPV[:, :, i], beam_size, distance)
			                                                     #
				PPV=np.array(PPVnew)                         #
		                                                             #
	return PPV                                                           #
#----------------------------------------------------------------------------#

