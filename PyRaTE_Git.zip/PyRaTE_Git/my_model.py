#----------------------------------------------------------------------------# 
#  NAME:                                                                     #
#                                                                            #
#  my_model.py                                                               #
#                                                                            #
#                                                                            #
#  DESCRIPTION:                                                              #
#                                                                            #
#  Hi there!!! Very simple module to create models and play around           #
#  It will also help you get familiar with the code.                         #
#  I have only made an example for spherical geometry. Making 2D, 3D arrays  #
#  with numpy is simple stuff so give it a try. The only two things          #
#  that you need to take care of is the symmetry and for 2D and 3D geometries#
#  this function will have more arguments both here and in main              # 
#                                                                            #
#  PARAMETERS:                                                               #
#                                                                            #
#     Input : geom                                                           #
#     Output : dens, mol, T, r, velx                                         #
#                                                                            #
#  AUTHOR:                                                                   #           
#                                                                            #
#  Aris E. Tritsis                                                           #
#  (Aris.Tritsis@anu.edu.au)                                                 #
#                                                                            #
#----------------------------------------------------------------------------#

#----------------------------------------------------------------------------#
import numpy as np                                                           #
import sys                                                                   #
from scipy.constants import parsec, m_p                                      #
                                                                             #
m_p=m_p*1e+3                                                                 #
parsec=parsec*1e+2                                                           #
#----------------------------------------------------------------------------#

#----------------------------------------------------------------------------#
def my_model(geom):                                                          #
                                                                             #
	if geom==0:                                                          #
		#     Let's make an isothermal/a bit clumpy sphere with      #
		#                  a velocity gradient                       #
		r=np.linspace(0.001*parsec, 0.55*parsec, 32)                 #
                                                                             #
		dens=5.e+4*np.exp(-2*r/max(r))                               #
                                                                             #
		mol=1.e-3*np.ones(len(dens))                                 #
                                                                             #
		dens=dens*m_p*2.4                                            #
                                                                             #
		T=10*np.ones(len(dens))                                      #
                                                                             #
		velr=-np.sin(r*np.pi/max(r))*1.e+5                           #
                                                                             #
		dens2, mol2, velr2, T2=dens[::-1], mol[::-1], velr[::-1], T[::-1]
                                                                             #
		dens, mol, velx, T=np.hstack((dens2, dens)), np.hstack((mol2, mol)), np.hstack((velr2, -velr)),  np.hstack((T2, T))
                                                                             #
		r2=-r[::-1]                                                  #
				                                             #
		x=np.hstack((r2, r))                                         #
                                                                             #
	else:                                                                #
		raise SystemExit("No one reads the comments, right :P? Please read comments in 'my_model.py'")
                                                                             #
	return dens, mol, velx, None, None, x, None, None, T                 #
#----------------------------------------------------------------------------#
