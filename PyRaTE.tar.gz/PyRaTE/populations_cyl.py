#----------------------------------------------------------------------------# 
#  NAME:                                                                     #
#                                                                            #
#  populations_cyl.py                                                        #
#                                                                            #
#                                                                            #
#  DESCRIPTION:                                                              #
#                                                                            #
#  Python script for calculating the ratio between the population densities  #
#  through an iterative process (CYLINDRICAL GEOMETRY).                      #
#                                                                            #
#  1. Assume beta                                                            #
#  2. Compute dtau_l                                                         #
#  3. Compute tau_l as the sum of dtau_l for dv_ij < Dfreq_thermal           #
#                                                                            #
#         With "dv_ij < Dfreq_thermal" we basically assume a                 #
#         step function for the profile.    ^                                #
#                                           |  f(v)                          #
#              1/2v_th Dv<v_th          ____|____                            #
#     f(v) = {                          |   |   |                            #
#              0 otherwise       _______|   |   |________                    #
#                                                                            #
#  4. Compute PopRat from tau_l                                              #
#  5. Circle back and check if (PopRat_b-PopRat_a)> tollerance               #
#                                                                            #
#  PARAMETERS:                                                               #
#                                                                            #
#     Input : dens, Einstein_A, C21, freq_0, Dfreq_thermal, T, mol,          #
#             velx, vely, velz, dist, geom, y, g1, g2, amu_mean, cmb         #
#     Output : PopRat                                                        # #                                                                            #
#  AUTHOR:                                                                   #           
#                                                                            #
#  Aris E. Tritsis                                                           #
#  (Aris.Tritsis@anu.edu.au)                                                 #
#                                                                            #
#----------------------------------------------------------------------------#

#----------------------------------------------------------------------------#
#         g1                                                                 #
#   C21 = -- * C12*e^(E/k_B*T)                                               #
#         g2                                                                 #
#   ____________________________________________________  2                  #
#      ^         |            |            ^       |                         #
#      | B12*I   |  B21*I     |  A21       | C12   | C21                     #
#      |         |            |            |       |                         #
#      |         v            v            |       v                         #
#   ----------------------------------------------------  1                  #
#                                                                            #
#   How the population in n2 change? equilibrium from what excites           #
#   & de-excites:                                                            #
#                                                                            #
#   dn2/dt=0=-n2*A21*beta+n1*n_H2*C12-n2*n_H2*C21 =>                         #
#                                                                            #
#   n2*(A21*beta+n_H2*C21)=n1*n_H2*C12 =>                                    #      
#                                                                            #
#   n2*(A21*beta+n_H2*C21)=n1*n_H2*C21*e^(-E/k_B*T)*(g2/g1) =>               #     
#                                                                            #
#   n2/n1= n_H2*C21*e^(-E/k_B*T)*(g2/g1)/(A21*beta+n_H2*C21) =>              #
#                                                                            #
#   _______________________________________                                  #
#   |                                     |                                  #
#   | n2      (g2/g1)*e^(-E/k_B*T)        |                                  #
#   | -- = ------------------------------ |                                  #
#   | n1   {1 + [A21/(n_H2*C21)]*beta}    |                                  #
#   _______________________________________                                  #
#                                                                            #
#                     =>                                                     #
#                                                                            #
#   ___________________________________________________                      #
#   |                                                 |                      #
#   |           n_H2*C21    g2*n1                     |                      #
#   |beta =    {--------* [ ----- * e^(-E/k_B*T)-1] } |                      #
#   |             A21       g1*n2                     |                      #
#   ___________________________________________________                      #
#                                                                            #
#                                                                            #
#    where beta is the escape probability                                    # 
#----------------------------------------------------------------------------#


#----------------------------------------------------------------------------#
import numpy as np                                                           #
from scipy.constants import h, c, k, m_p                                     #
from mpi4py import MPI                                                       #
import sys                                                                   #
                                                                             #
comm = MPI.COMM_WORLD                                                        #
iproc=comm.Get_rank()                                                        #
nproc=comm.Get_size()                                                        #
                                                                             #
#- - - - - - - - - - - - - -Convert to cgs- - - - - - - - - - - - - - - - - -#
h=h*1.e+7                                                                    #
c=c*1.e+2                                                                    #
K_b=k*1.e+7                                                                  #
m_p=m_p*1e+3                                                                 #
                                                                             #
Tcmb=2.7255                                                                  #
#----------------------------------------------------------------------------#

#----------------------------------------------------------------------------#
def populations_cyl(dens, Einstein_A, C21, freq_0, Dfreq_thermal, T, mol, velr, velz, dist, geom, z, g1, g2, amu_mean, cmb):
                                                                             #
	#       beta_0 is the initial guess for the "1rst" grid point.       #
	#  However, the initial guess for the 2nd grid point is the final    #
	#           beta computed for the first grid point.                  #
                                                                             #
	beta_0=0.5                                                           #
                                                                             #
	dv_thermal=Dfreq_thermal/freq_0*c                                    #
                                                                             #
	Texcit = freq_0*h*c/K_b                                              #
                                                                             #
	opt_importance=Einstein_A/(dens*C21)                                 #
                                                                             #
	if cmb==True:                                                        #
                                                                             #
		exp_cmb=1./(np.exp(h*freq_0*c/(K_b*2.725))-1.)               #
	else:                                                                #
                                                                             #
		exp_cmb=0.                                                   #
	#--------------------------------------------------------------------#
	#                                                                    #
	#             !!!         CYLINDRICAL         !!!                    #
        #                                                                    #
	#--------------------------------------------------------------------#
						                             #
	size = dens.shape                                                    #
					                                     #
	chopped_zs=np.empty(size[0]/nproc, dtype=np.float64)                 #
                                                                             #
	comm.Scatter([z, MPI.DOUBLE], [chopped_zs, MPI.DOUBLE])              #
                                                                             #
	PopRat=[]                                                            #
                                                                             #
	for i in range (0, len(chopped_zs)):                                 #
                                                                             #
		index=np.where(z==chopped_zs[i])[0][0]                       #
                                                                             #
		temp=[]                                                      #
                                                                             #
		for j in range (0, len(dens[0])):                            #
                                                                             #
			#           intial guess for beta                    #
			        		                             #
			beta=beta_0                                          #
					                                     #
			PopRat_a=(g2/g1*np.exp(-Texcit/T[index, j])+g2/g1*beta*Einstein_A*exp_cmb/(dens[index, j]*C21))/(1.+Einstein_A*beta*(1.+exp_cmb)/(dens[index, j]*C21))                                              #
					                                     #
			#     with that specific population ratio go and     #
			#       compute dt_l*dist for all grid points        #
			dummy=False                                          #
					                                     #
			counter=0                                            #
					                                     #
			while (dummy==False):                                #
			                                                     #
				counter=counter+1                            #
						                             #
				Abundance = mol/(1.+PopRat_a)                #
						                             #
				Line_abs_temp= g2/g1*Abundance*Einstein_A/(8.*np.pi*freq_0**2)*(1.-(g1/g2)*PopRat_a)/dv_thermal[m, k]
						                             #
				dt_l = Line_abs_temp*dist                    #
                  						             #
				# Now compare which are one thermal linewidth#
				#   away. Do this towards all 4 directions   #
				dt_l=np.array(dt_l)                          #
						                             #
				t_line_right=dt_l[i, np.where(abs(velr[index, j]-velr[index, j+1:len(velr[0])]) < dv_thermal[index, j+1:len(velr[0])])].sum()                                                                #
				t_line_left=dt_l[i, np.where(abs(velr[index, j]-velr[index, -len(velr[0]):j]) < dv_thermal[index, -len(velr[0]):j])].sum()                                                              #
				t_line_up=dt_l[np.where(abs(velz[index, j]-velz[index+1:len(velz), j]) < dv_thermal[index+1:len(velz), j]), j].sum()                                                                           #
				t_line_down=dt_l[np.where(abs(velz[index, j]-velz[-len(velz):index, j]) < dv_thermal[-len(velz):index, j]), j].sum()                                                                           #
				t_line = min(t_line_right, t_line_left, t_line_up, t_line_down)
						                             #
				beta_0 = np.exp(-t_line)                     #  
						                             #
				PopRat_b=(g2/g1*np.exp(-Texcit/T[index, j])+g2/g1*beta_0*Einstein_A*exp_cmb/(dens[index, j]*C21))/(1.+Einstein_A*beta_0*(1.+exp_cmb)/(dens[index, j]*C21))                        #
							                     #
				if np.absolute(PopRat_b-PopRat_a)<=1.e-7:    #
						                             #
					dummy=True                           #
						                             #
				if counter>=80:                              #
					                                     #
					raise SystemExit("I am having troubles converging!! The last two values of population ratios computed were {} and {}. Perhaps try reducing the tollerance or changing the initial guess?".format(PopRat_a, PopRat_b))
						                             #
				PopRat_a=(PopRat_b+PopRat_a)*0.5             #
						                             #
			temp.append(PopRat_b)                                #
			                             	                     #
		PopRat.append(temp)                          	             #
		              			                             #
	return np.array(PopRat)                                              #
#----------------------------------------------------------------------------#


