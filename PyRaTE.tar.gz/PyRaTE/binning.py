#----------------------------------------------------------------------------# 
#  NAME:                                                                     #
#                                                                            #
#  binning.py                                                                #
#                                                                            #
#                                                                            #
#  DESCRIPTION:                                                              #
#                                                                            #
#  Python script for binning velocities from the PPV cube.                   #
#  The parameter "nbins" controls every how many points we will bin          #
#  velocities and parameter "BINS" controls if the profile will be binned    #
#  or convolved with a Gaussian                                              #
#                                                                            #
#                                                                            #
#  PARAMETERS:                                                               #
#                                                                            #
#     Input : The PPV cube, freq_range                                       #
#     Output : binned PPV cube                                               #
#                                                                            #
#  NAME DESCRIPTION:                                                         #
#                                                                            #
#  nbins--> In case you want to do the run in high spectral resolution and   #
#           then degrade the spectral res to facilitate with observations    #
#           this parameter controls the number of velocity slices            #
#  BINS--> Boolean, if True do binning, if False then convolve with Gaussian #
#  OSR --> Original spectral resolution                                      #
#  DSR --> Desired spectral resolution                                       #
#                                                                            #
#  AUTHOR:                                                                   #           
#                                                                            #
#  Aris E. Tritsis                                                           #
#  (Aris.Tritsis@anu.edu.au)                                                 #
#                                                                            #
#----------------------------------------------------------------------------#

#----------------------------------------------------------------------------#
import numpy as np                                                           #
from scipy import ndimage                                                    #
                                                                             #
#----------------------------------------------------------------------------#

#----------------------------------------------------------------------------#
				                                             #
def binning(freq_range, PPV, nbins, BINS, OSR, DSR):                         #
				                                             #
	if BINS==True:                                                       #
				                                             #
		step = len(freq_range)/nbins                                 # 
						                             #
		step = int(step)                                             #
						                             #
		PPV_new=[]                                                   #
		#              In case we have an actual PPV cube            #
						                             #
		if isinstance(PPV[0], list)==True:                           #
						                             #
			for i in range (0, len(PPV)):                        # 
								             #
				temp=[]                                      #
								             #                                       
				for j in range (0, len(PPV[0])):             #
								             #
					local_em=[]                          #
								             #
					for f in range (0, len(freq_range)-step, step):
									     #
						ILOS=PPV[i, j, f:f+step]     #
									     #
						local_em.append(np.mean(ILOS))
									     #
					temp.append(local_em)                #
						                             #
				PPV_new.append(temp)                         #
						                             #
			PPV=np.array(PPV_new)                                #
						                             #
		#                In case we have a single line               #
		else:                                                        #
						                             #
			local_em=[]                                          #
						                             #
			for f in range (0, len(freq_range)-step, step):      #
								             #
				ILOS=PPV[f:f+step]                           #
								             #
				local_em.append(np.mean(ILOS))               #
								             #
			PPV=np.array(local_em)                               #
				                                             #
		binned_freqs=[]                                              #
						                             #	
		for f in range (0, len(freq_range)-step, step):              #
				                                             #
			freq_range_i=freq_range[f:f+step]                    #
				                                             #
			binned_freqs.append(np.mean(freq_range_i))           #
				                                             #
		binned_freqs=np.array(binned_freqs)                          #
		                                                             #
	else:                                                                #
		                                                             #
		FWHM=DSR/OSR                                                 #
		                                                             #
		sigma=FWHM/(2.*np.sqrt(2.*np.log(2.)))                       #
		                                                             #
		PPV_new=[]                                                   #
		#              In case we have an actual PPV cube            #
						                             #
		if isinstance(PPV[0], list)==True:                           #
						                             #
			for i in range (0, len(PPV)):                        # 
								             #
				temp=[]                                      #
								             #                                       
				for j in range (0, len(PPV[0])):             #
								             #                                       
					ILOS=ndimage.filters.gaussian_filter(PPV[i, j, :], sigma=sigma, mode='nearest')
									     #
					temp.append(ILOS)                    #
									     #
				PPV_new.append(temp)                         #
						                             #
			PPV=np.array(PPV_new)                                #
						                             #
		#                In case we have a single line               #
		else:                                                        #
						                             #
			PPV=ndimage.filters.gaussian_filter(PPV, sigma=sigma, mode='nearest')
				                                             #
		binned_freqs=freq_range                                      #
				                                             #
	return binned_freqs, PPV                                             #
#----------------------------------------------------------------------------#
