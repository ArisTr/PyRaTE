#----------------------------------------------------------------------------# 
#  NAME:                                                                     #
#                                                                            #
#  rad_tran_eq_integration.py                                                #
#                                                                            #
#                                                                            #
#  DESCRIPTION:                                                              #
#                                                                            #
#  Python script for computing the line-of-sight intensity. We neend to      #
#  Integrate the radiative trnasfer equation:                                #
#                                                                            #
#           dI/ds=-k_line*I+k_line*S+k_cont*S_cont*e^(t_cont)  (eq. 7-9)     #
#                                                                            #
#  Specifically, we need to compute the quantity:                            #
#                                                                            #
#   I_b={[e^(-t_cont_b)-p]*I_a+p*S_line_a+q*S_line_b+S_k}/(1+q)  (eq. 7-10)  #
#                                                                            #
#  where a and b denote two grid points. Other quantities are define as:     #
#                                                                            #
#          q=t_line_b/(1+e^(-t_line_b))                                      #
#          p=q*e^(-t_line_b-t_cont_b)                                        #
#  S_k=e^(-t_cont_b)*integral_a^b(k_cont*S_cont*e^(integral(k_cont ds')) ds) #
#          t_line_b=integral_a^b(k_line ds)                                  #
#                                                                            #
#   The last equation depends on the population densities N1 & N2 and the    #
#      Doppler-shifted frequency v'. Einstein's coefficients do not vary     #
#        from grid point to grid point. We thus need to compute:             #
#                                                                            #
#      t_line_b=N1*B12(hv0/4pi)[1-(N2g1/N1g2)]*integral_a^b(f(v) ds)         #
#                                                                            #
#              which for a Gaussian-like profile reduces to:                 #
# t_line_b=N1*B12(hv0/4pi)[1-(N2g1/N1g2)]*((sb-sa)/(vlos_b-vlos_a))*(P_b-P_a)#
#                                                                            #
#                     where P is the error function                          #
#                                                                            #
#                                                                            #
#  PARAMETERS:                                                               #
#                                                                            #
#  Input:  LOS velocity, v0 (central velocity of line)                       #
#                                                                            #
#  Output: I_b                                                               #
#                                                                            #
#                                                                            #
#  AUTHOR:                                                                   #           
#                                                                            #
#  Aris E. Tritsis                                                           #
#  (Aris.Tritsis@anu.edu.au)                                                 #
#                                                                            #
#  Harold Yorke                                                              #
#                                                                            #
#         THIS SCRIPT IS BASED ON THE RELEVANT SUBROUTINE OF THE             #
#                     FORTRAN CODE "CORELINE"                                #
#----------------------------------------------------------------------------#


#----------------------------------------------------------------------------#
import numpy as np                                                           #
from scipy.special import erf                                                #
from scipy.integrate import nquad, quad                                      #
from scipy.constants import h, c, k, m_p                                     #
import sys                                                                   #
                                                                             #
#- - - - - - - - - - - - - -Convert to cgs- - - - - - - - - - - - - - - - - -#
h=h*1.e+7                                                                    #
c=c*1.e+2                                                                    #
K_b=k*1.e+7                                                                  #
                                                                             #
def integration(y):                                                          #
	return np.exp(-y**2)  #*2/np.pi                                      #
#----------------------------------------------------------------------------#


#----------------------------------------------------------------------------#
#                                                                            #
#          /\                                                                #
#         /  \                                                               #
#        / || \              WE ARE ALL HERE TO SERVE YOU                    #
#       /  ||  \                                                             #
#      /   ..   \            ALL OTHER SUVROUTINES ARE HERE                  #
#     /          \           TO GET "INTEGRATION" WHAT IT NEEDS!             #
#     ------------                                                           #
#                                                                            #
#----------------------------------------------------------------------------#



#----------------------------------------------------------------------------#
def rad_tran_eq_integration(freq, vel_a, vel_b, dist, freq_0, Dfreq_thermal, I_a, S_c_a, S_c_b, S_line_a, S_line_b, Line_abs_a, Line_abs_b, k_ext_a, k_ext_b):                                                           #
                                                                             #
	#- - The following are correct if no sharp discontinuities in grid- -#
                                                                             #
	ya=freq*(1.-vel_a/c)/Dfreq_thermal-freq_0/Dfreq_thermal              #
		                                                             #
	yb=freq*(1.-vel_b/c)/Dfreq_thermal-freq_0/Dfreq_thermal              #
		                                                             #
	Qa=quad(integration, 0, ya)[0]                                       #
		                                                             #
	Qb=quad(integration, 0, yb)[0]                                       #
		                                                             #
	Qmean=quad(integration, 0, (ya+yb)/2.)[0]                            #
		                                                             #
	#- - - - -Velocity differences between grid points so small- - - - - #
	#- - -that lead values < machine precision->ignore, only continuum- -#
	#- - - - - - - - - contributes to the line.- - - - - - - - - - - - - #
		                                                             #  
	if(abs(Qa-Qb)/(abs(Qa)+abs(Qb)+1.e-10) < 1.e-6):                     #
		                                                             #
		PM=np.exp(-((ya+yb)/2.)**2)                                  #
		                                                             #
		dQdV=PM/Dfreq_thermal*freq/c                                 #
		                                                             #
		weight_a = 0.5                                               #
		                                                             #
	else:                                                                #
		                                                             #
		dQdV = -(Qb-Qa)/(vel_b-vel_a)                                #
		                                                             #
		weight_a = max(0.,(Qmean-Qa)/(Qb-Qa))                        #
		                                                             #
		weight_a = min(1., weight_a)                                 #
		                                                             #
	weight_b = 1.0-weight_a                                              #   
		                                                             #
	t_line_b=(Line_abs_a*weight_a+Line_abs_b*weight_b)*dist*dQdV/freq    #
		                                                             #
	t_cont_b=dist*(k_ext_a+k_ext_b)/2.                                   #
		                                                             #
	q=t_line_b/(1.+np.exp(-t_line_b))                                    #
		                                                             #
	p=q*np.exp(-t_line_b-t_cont_b)                                       #
		                                                             #
	if t_cont_b <2.e-3:                                                  #
		                                                             #
		if t_cont_b>=0.:                                             #
		                                                             #
			S_c=t_cont_b*(S_c_a*(0.5+t_cont_b*(t_cont_b*0.125-1/3.)) + S_c_b*(0.5+t_cont_b*(t_cont_b*(1/24.)-1/6.)))
		                                                             #
			temp=1.+t_cont_b*(t_cont_b*(0.5-t_cont_b*(1/16.))-1.)#
		                                                             #
	else:                                                                #
		                                                             #
		temp=(1.-np.exp(-t_cont_b))/t_cont_b                         #
		                                                             #
		S_c = S_c_b-S_c_a*np.exp(-t_cont_b)+(S_c_a-S_c_b)*temp       #
                                                                             #
		                                                             #
	I_b=((temp-p)*I_a+p*S_line_a+q*S_line_b+S_c)/(1.+q)                  # 
                                                                             #
	return I_b                                                           #
#----------------------------------------------------------------------------#
