#----------------------------------------------------------------------------# 
#  NAME:                                                                     #
#                                                                            #
#  populations_crt.py                                                        #
#                                                                            #
#                                                                            #
#  DESCRIPTION:                                                              #
#                                                                            #
#  Python script for calculating the ratio between the population densities  #
#  through an iterative process (CARTESIAN GEOMETRY).                        #
#                                                                            #
#  1. Assume beta                                                            #
#  2. Compute dtau_l                                                         #
#  3. Compute tau_l as the sum of dtau_l for dv_ij < Dfreq_thermal           #
#                                                                            #
#         With "dv_ij < Dfreq_thermal" we basically assume a                 #
#         step function for the profile.    ^                                #
#                                           |  f(v)                          #
#              1/2v_th Dv<v_th          ____|____                            #
#     f(v) = {                          |   |   |                            #
#              0 otherwise       _______|   |   |________                    #
#                                                                            #
#  4. Compute PopRat from tau_l                                              #
#  5. Circle back and check if (PopRat_b-PopRat_a)> tollerance               #
#                                                                            #
#  PARAMETERS:                                                               #
#                                                                            #
#     Input : dens, Einstein_A, C21, freq_0, Dfreq_thermal, T, mol,          #
#             velx, vely, velz, dist, geom, y, g1, g2, amu_mean, cmb         #
#     Output : PopRat                                                        # #                                                                            #
#  AUTHOR:                                                                   #           
#                                                                            #
#  Aris E. Tritsis                                                           #
#  (Aris.Tritsis@anu.edu.au)                                                 #
#                                                                            #
#----------------------------------------------------------------------------#

#----------------------------------------------------------------------------#
#         g1                                                                 #
#   C21 = -- * C12*e^(E/k_B*T)                                               #
#         g2                                                                 #
#   ____________________________________________________  2                  #
#      ^         |            |            ^       |                         #
#      | B12*I   |  B21*I     |  A21       | C12   | C21                     #
#      |         |            |            |       |                         #
#      |         v            v            |       v                         #
#   ----------------------------------------------------  1                  #
#                                                                            #
#   How the population in n2 change? equilibrium from what excites           #
#   & de-excites:                                                            #
#                                                                            #
#   dn2/dt=0=-n2*A21*beta+n1*n_H2*C12-n2*n_H2*C21 =>                         #
#                                                                            #
#   n2*(A21*beta+n_H2*C21)=n1*n_H2*C12 =>                                    #      
#                                                                            #
#   n2*(A21*beta+n_H2*C21)=n1*n_H2*C21*e^(-E/k_B*T)*(g2/g1) =>               #     
#                                                                            #
#   n2/n1= n_H2*C21*e^(-E/k_B*T)*(g2/g1)/(A21*beta+n_H2*C21) =>              #
#                                                                            #
#   _______________________________________                                  #
#   |                                     |                                  #
#   | n2      (g2/g1)*e^(-E/k_B*T)        |                                  #
#   | -- = ------------------------------ |                                  #
#   | n1   {1 + [A21/(n_H2*C21)]*beta}    |                                  #
#   _______________________________________                                  #
#                                                                            #
#                     =>                                                     #
#                                                                            #
#   ___________________________________________________                      #
#   |                                                 |                      #
#   |           n_H2*C21    g2*n1                     |                      #
#   |beta =    {--------* [ ----- * e^(-E/k_B*T)-1] } |                      #
#   |             A21       g1*n2                     |                      #
#   ___________________________________________________                      #
#                                                                            #
#                                                                            #
#    where beta is the escape probability                                    # 
#----------------------------------------------------------------------------#


#----------------------------------------------------------------------------#
import numpy as np                                                           #
from scipy.constants import h, c, k, m_p                                     #
from mpi4py import MPI                                                       #
                                                                             #
comm = MPI.COMM_WORLD                                                        #
iproc=comm.Get_rank()                                                        #
nproc=comm.Get_size()                                                        #
                                                                             #
#- - - - - - - - - - - - - -Convert to cgs- - - - - - - - - - - - - - - - - -#
h=h*1.e+7                                                                    #
c=c*1.e+2                                                                    #
K_b=k*1.e+7                                                                  #
m_p=m_p*1e+3                                                                 #
                                                                             #
Tcmb=2.7255                                                                  #
#----------------------------------------------------------------------------#

#----------------------------------------------------------------------------#
def populations_crt(dens, Einstein_A, C21, freq_0, Dfreq_thermal, T, mol, velx, vely, velz, dist, geom, y, g1, g2, amu_mean, cmb):
                                                                             #
	#       beta_0 is the initial guess for the "1rst" grid point.       #
	#  However, the initial guess for the 2nd grid point is the final    #
	#           beta computed for the first grid point.                  #
                                                                             #
	beta_0=0.5                                                           #
                                                                             #
	dv_thermal=Dfreq_thermal/freq_0*c                                    #
                                                                             #
	Texcit = freq_0*h*c/K_b                                              #
                                                                             #
	if cmb==True:                                                        #
                                                                             #
		exp_cmb=1./(np.exp(h*freq_0*c/(K_b*2.725))-1.)               #
	else:                                                                #
                                                                             #
		exp_cmb=0.                                                   #
	#--------------------------------------------------------------------#
	#                                                                    #
	#             !!!          CARTESIAN          !!!                    #
        #                                                                    #
	#--------------------------------------------------------------------#
						                             #
	size = dens.shape                                                    #
				                                             #
	chopped_ys=np.empty(size[0]/nproc, dtype=np.float64)                 #
                                                                             #
	comm.Scatter([y, MPI.DOUBLE], [chopped_ys, MPI.DOUBLE])              #
                                                                             #
	PopRat=[]                                                            #
	                                                                     #
	for i in range (0, len(chopped_ys)):                                 #
                                                                             #
		index=np.where(y==chopped_ys[i])[0][0]                       #
                                                                             #
		temp=[]                                                      #
                                                                             #
		for j in range (0, len(dens[0])):                            #
                                                                             #
			temp2=[]                                             #
		                                                             #
			for k in range (0, len(dens[0][0])):                 #
		                                                             #
				beta=beta_0                                  #
								             #
	 			PopRat_a=(g2/g1*np.exp(-Texcit/T[index, j, k])+g2/g1*beta*Einstein_A*exp_cmb/(dens[index, j, k]*C21))/(1.+Einstein_A*beta*(1.+exp_cmb)/(dens[index, j, k]*C21))                       #
									     #
				#     with that specific population ratio    #
				#    compute dt_l*dist for all grid points   #
				dummy=False                                  #
							                     #
				counter = 0.                                 #
							                     #
				while (dummy==False):                        #
							                     #
					counter=counter+1                    #
							                     #
					Abundance = mol/(1.+PopRat_a)        #
							                     #
					Line_abs_temp = g2/g1*Abundance*Einstein_A/(8.*np.pi*freq_0**2)*(1.-g2/g1*PopRat_a)/dv_thermal
							                     #
					dt_l = Line_abs_temp*dist            #
							                     #
					#  Now compare which are one thermal #
					#  linewidth away. Do this towards   #
					#            all 6 rays              #
					dt_l=np.array(dt_l)                  #
							                     #
					t_line_right=dt_l[i, np.where(abs(velx[index, j, k]-velx[index, j+1:len(velx[0]), k]) < dv_thermal[index, j+1:len(velx[0]), k]), k].sum()			                             #
					t_line_left=dt_l[i, np.where(abs(velx[index, j, k]-velx[index, -len(velx[0]):j, k]) < dv_thermal[index, -len(velx[0]):j, k]), k].sum()		                                     #
					t_line_up=dt_l[np.where(abs(vely[index, j, k]-vely[index+1:len(vely), j, k]) < dv_thermal[index+1:len(vely), j, k]), j, k].sum()				                     #
					t_line_down=dt_l[np.where(abs(vely[index, j, k]-vely[-len(vely):index, j, k]) < dv_thermal[-len(vely):index, j, k]), j, k].sum()				             #
					t_line_in=dt_l[i, j, np.where(abs(velz[index, j, k]-velz[index, j, k+1:len(velz[0][0])]) < dv_thermal[index, j, k+1:len(velz[0][0])])].sum()			                     #
					t_line_out=dt_l[i, j, np.where(abs(velz[index, j, k]-velz[index, j, -len(velz[0][0]):k]) < dv_thermal[index, j, -len(velz[0][0]):k])].sum()		                             #
					t_line = min(t_line_right, t_line_left, t_line_up, t_line_down, t_line_in, t_line_out)
							                     #
					beta_0 = np.exp(-t_line)             #
							                     #
					PopRat_a=(g2/g1*np.exp(-Texcit/T[index, j, k])+g2/g1*beta_0*Einstein_A*exp_cmb/(dens[index, j, k]*C21))/(1.+Einstein_A*beta_0*(1.+exp_cmb)/(dens[index, j, k]*C21))                     #
							                     #
					if np.absolute(PopRat_b-PopRat_a)<=1.e-7:
						                             #
						dummy=True                   #
							                     #
					if counter>=80:                      #
							                     #
						raise SystemExit("I am having troubles converging!! The last two values of population ratios computed were {} and {}. Perhaps try reducing the tollerance or changing the initial guess?".format(PopRat_a, PopRat_b))
							                     #
					PopRat_a=(PopRat_b+PopRat_a)*0.5     #
							                     #
				temp2.append(PopRat_b)                       #
					                                     #
			temp.append(temp2)                                   #
					                                     #
		PopRat.append(temp)                                          #
				                                             #
	return np.array(PopRat)                                              #
#----------------------------------------------------------------------------#


