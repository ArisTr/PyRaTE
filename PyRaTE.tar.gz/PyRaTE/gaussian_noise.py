#----------------------------------------------------------------------------# 
#  NAME:                                                                     #
#                                                                            #
#  gaussian_noise.py                                                         #
#                                                                            #
#                                                                            #
#  DESCRIPTION:                                                              #
#                                                                            #
#  Small python scipt for adding gaussian noise to the spectral line         #
#  The mean will always be zero and the SNR will be ~8                       #
#                                                                            #
#  AUTHOR:                                                                   #           
#                                                                            #
#  Aris E. Tritsis                                                           #
#  (Aris.Tritsis@anu.edu.au)                                                 #
#                                                                            #
#----------------------------------------------------------------------------#

#----------------------------------------------------------------------------#
import numpy as np                                                           #
                                                                             #
#----------------------------------------------------------------------------#

#----------------------------------------------------------------------------#
def gaussian_noise(ILOS, outofarea, eSNR, mean):                             #
	if max(ILOS)!=0.:                                                    #
		sigma = np.mean(ILOS)/eSNR                                   #
	else:                                                                #
		sigma = outofarea/eSNR                                       #
	noise = np.random.normal(mean, sigma, len(ILOS))                     #
	ILOS = ILOS+noise                                                    #
	return ILOS                                                          #
#----------------------------------------------------------------------------#
