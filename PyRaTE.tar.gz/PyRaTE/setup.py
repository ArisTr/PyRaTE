#-------------------------------------------------------------------------------# 
#  NAME:                                                                        #
#                                                                               #
#  setup.py                                                                     #
#                                                                               #
#  DESCRIPTION:                                                                 #
#                                                                               #
#   Python script for setting up all the relevant parameters for your run       #
#                                                                               #
#  PARAMETERS:                                                                  #
#                                                                               #
#     Input : None                                                              #
#     Output : Parameters of the run                                            #    
#                                                                               #
#  NAME DESCRIPTION:                                                            #
#                                                                               #
#  path--> were the simulation output is stored.                                #
#  level--> level of refinement/spatial resolution                              #  
#  molecule--> Name of the molecule you want to examine                         #
#  transition_up/low--> transition of the molecule.                             #
#                       For J (1-0), transition_up = 1, , transition_low = 0    #
#                                                                               #
#  geom--> geometry to consider.                                                #
#                                                                               #
#          geom = 0---> spherical                                               #
#          geom = 1---> cylindrical                                             #
#          geom = 2---> cartesian                                               #
#                                                                               #
#  fi0, th0--> projection angles in degrees.                                    #
#              Theta will only be needed if we will work                        #
#              on cartesian coordiantes                                         #
#                                                                               #
#			  Here are the angles for off-axis ray tracing. "theta" #
#			      and "fi" are the angles shown in the figure       #
#                                 bellow such that when theta=fi=0 we do        #
#                                ray-tracing along z-axis (line-of-sight)       #
#                                                                               #
#			                                                        #
#			                           (Bfield)                     # 
#			            /---------/|      y ^                       #  
#			           /         / |        |                       #
#			          /---------/  |     \th|                       #
#			          |         |  |      \ |                       #
#			          |         |  |       \|------------> x        #
#			          |         | /         /\           (POS)      #
#			          |---------|/         /  \                     #
#			                            z V fi \                    #
#					          (LOS)                         #
#			                                                        #
#  v_type --> type of microturbulence to add. See 'turbulence.py' for more      #
#  mturbv_param --> parameter that controls 'how much' microturbulence          #
#                   you want to add.                                            #
#  amu_mean--> the mean molecular weight from simulations                       #
#                                                                               #
#  spectr_res--> spectral resolution in km/s                                    #
#  npoints --> number of frequency points. That number along with the spectral  #
#              determine the bandwidth                                          #
#- - - - - - - - - - -Logical parameters(just helping)- - - - - - - - - - - - - #
#                                                                               #
#      txt_export ---> write everything to txt files for further processing     #
#      noise ---> add gaussian noise to the spectra                             #
#      ppv ---> if false then you get an integrated emission map, if true       #
#               you get a position-position velocity (frequency) cube           #
#      beam ---> convolve the images with a gaussian filter                     #     
#      line ---> Single line or molecular emission map?                         #
#      hyperfine ---> files in "lambda" directory with hyperfine data           #
#                     for the molecule end in "*_hfs"                           #
#      bins ---> bin the frequencies/velocities. Thus, from ~64 frequencies     #
#                will go to 16 (default-can be changed in "binning.py")         #
#      vturb---> If true then Dfreq_thermal will be updated as                  #
#                Dfreq_thermal=(Dfreq_thermal^2+vtrub^2)^0.5                    #
#      debug_h---> If true then a few plots will show up to make sure everything#
#                is as expected and there is no misunderstanding with symmetries#
#                etc                                                            #
#      fits--->  If true then you will get your result in fits format           #
#                                                                               #
#      sim--->   If sim is true then you will load your actual simulation.      #
#                If false then you will model, whatever is in 'my_model.py'     #
#      LTE---> If true then the population ratios will be computed under the    #
#              LTE approximation                                                #
#      cmb---> If true then cmb temperature will be also used in calculations   #
#              When dealing with low densities it should be set to True         #
#      Tbgr--> Background temperature. That can be 0., 2.7 (cmb) or anything    #
#              you want that will be computed from Planck's function            # 
#                                                                               #
#            Other parameters controling the final result after                 #
#                   the integration along the LOS are:                          #
#                                                                               #
#    eSNR --> log10(signal to noise ratio) in "gaussian_noise"                  #
#    mean --> Mean value for noise                                              #
#    beam_size --> telescope's beam size in arcsec used in "gaussian_filtering" #
#                  and in "units_ch"                                            #
#    distance --> the distance of the cloud in pc also in "gaussian_filtering"  #
#                                                                               #
#    nbins--> In case you want to do the run in high spectral resolution        #
#           and then degrade the spectral resolution to facilitate with         #
#           observations, this parameter controls the number of velocity slices #
#    BINS--> Boolean, if True do binning, if False then convolve with Gaussian  #
#    DSR --> Desired spectral resolution (in km/s)                              #
#    TrueDB--> If True the do the actual detail balance (12 levels, implemented #
#              only for spherical geometry as of yet                            #
#    units---> In what units to plot the y-axis (Intensity)                     #
#              0-> v*Fv                                                         #
#              1-> Jansky                                                       #
#              2-> Antena temperature                                           #
#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -#
#    X_DoI-->Degree of ionization                                               #
#       REFERENCES:                                                             #
#                                                                               #
#  http://iopscience.iop.org/article/10.1086/305624/pdf                         #
#  http://iopscience.iop.org/article/10.1086/306034/pdf                         #
#  http://iopscience.iop.org/article/10.1086/306791/pdf                         #
#                                                                               #
#  Ranges are between 10^{-8}~10^{-6}. For something more fancy you can do:     #
#             X_DoI=10^{-7}(n(H_2)/10^4)^{1/2}   (Elmegreen 1979)               #
#                                                                               #
#  AUTHOR:                                                                      #           
#                                                                               #
#  Aris E. Tritsis                                                              #
#  (Aris.Tritsis@anu.edu.au)                                                    #
#                                                                               #
# This code has been tested as good as possible. However, I cannot guarantee    # 
# that it is free of errors and that you will obtain correct results in all     #
#                            situations.                                        #
#-------------------------------------------------------------------------------#

#-------------------------------------------------------------------------------#
import numpy as np                                                              #
import os                                                                       #
#-------------------------------------------------------------------------------#

#-------------------------------------------------------------------------------#
def setup():                                                                    #
                                                                                #
	path = os.path.abspath('/home/user/path-to-simulation-output/')         #
	level=0                                                                 #
	molecule='CO'                                                           #
	geom=0                                                                  #
                                                                                #
	fi0=0.0                                                                 #
	th0=0.0                                                                 #
                                                                                #
	eSNR=8.                                                                 #
	beam_size=40                                                            #
	distance=140                                                            #
                                                                                #
	units=2                                                                 #
	spectr_res=0.05                                                         #
	npoints = 64                                                            #
	DSR=0.3                                                                 #
	Tbgr=0.                                                                 #
	#                 Logical parameters....                                #
                                                                                #
	txtexport=False                                                         #
	noise=False                                                             #
	ppv=True                                                                #
	beam=False                                                              #
	line=True                                                               #
	bins=False                                                              #
	vturb=False                                                             #
	debug_h=True                                                            #
	fits=False                                                              #
	sim=False                                                               #
	LTE=True                                                                #
	cmb=False                                                               #
	BINS=False                                                              #
                                                                                #
	#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -#
	#                         Not so frequently used                        #
	#                                                                       #
	#   Dictionary with species. Change this to match your astrochemical    #
	#                             simulations                               #
	species=[]                                                              #
	for i in range (1, 205):                                                #
	    species.append('m{:03}'.format(i))                                  #
		                                                                #
	for i in range (283, 291):                                              #
	    species.append('m{:03}'.format(i))                                  #
		                                                                #
	spec=['H+', 'H', 'H2+','H3+','He', 'He+', 'C+','C','CH','CH+','CH2+','CH2','N', 'N+','CH3','NH+','CH3+','NH','NH2+','O','CH4','CH4+','O+','NH2','CH5+','OH','OH+','NH3+','NH3','H2O','NH4+','H2O+','H3O+','C2','C2+','C2H+','C2H','C2H2+','C2H2','CN','CN+','HCN+','C2H3+','HCN','HNC','Si+','C2H4+','H2NC+','Si','N2','CO+','HCNH+','CO','N2+','HCO','N2H+','HCO+','H2CO','H2CO+','NO','NO+','H3CO+','CH3OH','O2','O2+','CH3OH2+','C3+','C3H+','C2N+','CNC+','C3H3+','CH3CN','CH3CNH+','CO2','CO2+','HCO2+','HC3N','HC3NH+','D+','D','HD+','D2+','H2D+','HD2+','D3+','CD','CD+','CHD+','CD2+','CHD','CD2','CH2D','CHD2','CD3','ND+','CH2D+','CHD2+','CD3+','ND','NHD+','ND2+','CH3D','CH2D2','CHD3','CD4','CH3D+','CH2D2+','CHD3+','CD4+','NHD','ND2','CH4D+','CH3D2+','CH2D3+','CHD4+','CD5+','OD','OD+','NH2D+','NHD2+','ND3+','NH2D','NHD2','ND3','HDO','D2O','NH3D+','NH2D2+','NHD3+','ND4+','HDO+','D2O+','H2DO+','HD2O+','D3O+','C2D+','C2D','C2HD+','C2D2+','C2HD','C2D2','DCN+','C2H2D+','C2HD2+','C2D3+','DCN','DNC','C2H3D+','C2H2D2+','C2HD3+','C2D4+','HDNC+','D2NC+','DCNH+','HCND+','DCND+','DCO','N2D+','DCO+','HDCO','D2CO','HDCO+','D2CO+','H2DCO+','HD2CO+','D3CO+','CH2DOH','CHD2OH','CD3OH','CH3OD','CH2DOD','CHD2OD','CD3OD','CH3OHD+','CH3OD2+','CH2DOH2+','CHD2OH2+','CD3OH2+','CH2DOHD+','CHD2OHD+','CD3OHD+','CH2DOD2+','CHD2OD2+','CD3OD2+','C3D+','C3H2D+','C3HD2+','C3D3+','CH2DCN','CHD2CN','CD3CN','CH3CND+','CH2DCNH+','CHD2CNH+','CD3CNH+','CH2DCND+','CHD2CND+','CD3CND+','DCO2+','DC3N','DC3NH+','HC3ND+','DC3ND+','HD','C3H2','C3H','C3H2+','C3HD','C3D','C3HD+','C3D2','C3D2+']
		                                                                #
	dictionary=dict(zip(species, spec))                                     #
                                                                                #
	transition_up=1.                                                        #
	transition_low=0.                                                       #
	#     for compatibility with the lists from Leiden I will add '1' in    #
	#                    transition_up/transition_low                       #
	transition_up, transition_low = transition_up+1, transition_low+1       #
	X_DoI=1.e-7                                                             #
	nbins=16.                                                               #
	mean=0.                                                                 #
	amu_mean=2.4237981621576                                                #
	vtype=0                                                                 #
	mturbv_param=50.                                                        #
	TrueDB=True                                                             #
	#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -#
	return transition_up, transition_low, X_DoI, nbins, mean, amu_mean, vtype, mturbv_param, path, level, molecule, geom, fi0, th0, eSNR, beam_size, distance, units, spectr_res, txtexport, noise, ppv, beam, line, bins, vturb, debug_h, fits, sim, LTE, cmb, npoints, Tbgr, BINS, DSR, dictionary, TrueDB                                                              #
#-------------------------------------------------------------------------------#
