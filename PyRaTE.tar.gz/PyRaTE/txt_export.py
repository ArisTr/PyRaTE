#----------------------------------------------------------------------------# 
#  NAME:                                                                     #
#                                                                            #
#  txt_export.py                                                             #
#                                                                            #
#                                                                            #
#  DESCRIPTION:                                                              #
#                                                                            #
#  Python script for exporting the data from the simulation to a txt file    #
#  This format may be usefull for other codes.                               #
#                                                                            #
#  AUTHOR:                                                                   #           
#                                                                            #
#  Aris E. Tritsis                                                           #
#  (Aris.Tritsis@anu.edu.au)                                                 #
#                                                                            #
#----------------------------------------------------------------------------#

#----------------------------------------------------------------------------#
import os                                                                    #
                                                                             #
working_dir = os.getcwd()                                                    #
#----------------------------------------------------------------------------#

#----------------------------------------------------------------------------# 
def txt_export(geom, x, y, z, dens, mol, velx, vely, velz, PopRat):          #
	#- - - - - - - - - - -cylindrical- - - - - - - - - - - - - - - - - - #
	if geom==1:                                                          #
		f = open("{}/output_files/data.txt".format(working_dir),"w") #
		for i in range (0, len(z)):                                  #
			for j in range (0, len(x)):                          #
				f.write("{}".format(z[i]))                   #
				f.write(" ")                                 #
				f.write("{}".format(x[j]))                   #
				f.write(" ")                                 #
				f.write("{}".format(dens[i, j]))             #
				f.write(" ")                                 #
				f.write("{}".format(mol[i, j]))              #
				f.write(" ")                                 #
				f.write("{}".format(velx[i, j]))             #
				f.write(" ")                                 #
				f.write("{}".format(velz[i, j]))             #
				f.write(" ")                                 #
				f.write("{}".format(PopRat[i, j]))           #
				f.write("\n")                                # 
                                                                             #
		f.close()                                                    #
	#- - - - - - - - - - -spherical- - - - - - - - - - - - - - - - - - - #
	elif geom==0:                                                        #
		f = open("{}/output_files/data.txt".format(working_dir),"w") #
		for j in range (0, len(x)):                                  #
			f.write("{}".format(x[j]))                           # 
			f.write(" ")                                         #
			f.write("{}".format(dens[j]))                        #
			f.write(" ")                                         #
			f.write("{}".format(mol[j]))                         #
			f.write(" ")                                         #
			f.write("{}".format(velx[j]))                        #
			f.write(" ")                                         #
			f.write("{}".format(PopRat[j]))                      #
			f.write("\n")                                        #
		f.close()                                                    # 
                                                                             #
	elif geom==2:                                                        #
		f = open("{}/output_files/data.txt".format(working_dir),"w") #
		for i in range (0, len(y)):                                  #
			for j in range (0, len(x)):                          #
				for k in range (0, len(z)):                  #
					f.write("{}".format(y[i]))           #
					f.write(" ")                         #
					f.write("{}".format(x[j]))           #
					f.write(" ")                         #
					f.write("{}".format(z[k]))           #
					f.write(" ")                         #
					f.write("{}".format(dens[i, j, k]))  #
					f.write(" ")                         #
					f.write("{}".format(mol[i, j, k]))   #
					f.write(" ")                         #
					f.write("{}".format(velx[i, j, k]))  #
					f.write(" ")                         #
					f.write("{}".format(velz[i, j, k]))  #
					f.write(" ")                         #
					f.write("{}".format(vely[i, j, k]))  #
					f.write(" ")                         #
					f.write("{}".format(PopRat[i, j, k]))#
					f.write("\n")                        # 
                                                                             #
		f.close()                                                    #
#----------------------------------------------------------------------------# 

