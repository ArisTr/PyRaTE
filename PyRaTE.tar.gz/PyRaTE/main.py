#-------------------------------------------------------------------------------#
#                                                                               #
#   This is the main routine that will do all the work. From here we            #
#              will call the routines that:                                     #
#                                                                               #
#    1.) Import data from FLASH simulations                                     #
#      i. Density as a function of r, z (x, y,z)--> parameter "dens"            #
#     ii. Abundance as a function of r, z   (x, y,z)--> parameter "mol"         #
#    iii. Velocity components as a function of r,z  (x, y,z)--> parameter velr  #
#                                                               & velz & vely   #
#       iv. The actual coordinates (r, z) or (r) or (x, y, z) depending         #
#           on the simulation                                                   #
#                                                                               #
#    2.) Read in molecular data from Leiden                                     #
#                                                                               #
#    3.) Find the velocity along the LOS                                        #
#                                                                               #
#    4.) Perform the integration of RT equation along the LOS                   #
#                                                                               #
#                                                                               #
# http://www.lenntech.com/calculators/molecular/molecular-weight-calculator.htm #    
#- - - - - - - - - - - -other useful data/site include- - - - - - - - - - - - - #
#           https://www.astro.umd.edu/rareas/lma/lgm/mol2.html                  #
#                                                                               #
#     G) The projection angle(s)                                                #
#                                                                               #
#            More comments and explanation as we go on.....                     #
#                                                                               #
# **** "temp" seen in some subroutines is just a temporary dummy variable ****  #
#                                                                               #
#                                                                               #
#                           REQUIREMENTS                                        #
#                          --------------                                       #
#                                                                               #
#     1.) yt with "INST_SCIPY" equal to 1                                       #
#     2.) MPICH2 for parallel parts: This can be set up by:                     #
#                   "pip install mpi4py"                                        #
#     3.) numpy                                                                 #
#     4.) scipy                                                                 #
#     5.) matplotlib                                                            #
#                                                                               #
#  AUTHORS:                                                                     #               
#                                                                               #
#  Aris E. Tritsis                                                              #
#  (Aris.Tritsis@anu.edu.au)                                                    #
#                                                                               #
#  Harold Yorke                                                                 #
#                                                                               #
#    !!!!     THIS CODE IS BASED ON THE FORTRAN CODE "CORELINE"     !!!!        #
#-------------------------------------------------------------------------------#
#                                                                               #
#                 run as "mpirun -np * ipython main.py"                         #     
#                                                                               #
#       replacing "*" with the available # of processors of your machine        #
#                                                                               #
#    For spherical geometry better run with "mpirun -np 1 ipython main.py"      #
#                      or simply with ipython main.py                           #
#-------------------------------------------------------------------------------#


#-------------------------------------------------------------------------------#
import os                                                                       #
import math                                                                     #
import numpy as np                                                              #
import sim_import                                                               #
import setup                                                                    #
import txtreader                                                                #
import sourcef                                                                  #
import populations_sph                                                          #
import populations_sphDB                                                        #
import populations_cyl                                                          #
import populations_cylDB                                                        #
import populations_crt                                                          #
import populations_crtDB                                                        #
import rad_tran_eq_integration                                                  #
import txt_export                                                               #
import units_ch                                                                 #
from scipy.constants import h, c, k, m_p, parsec                                #
from scipy import interpolate                                                   #
import PPV                                                                      #
import gaussian_noise                                                           #
import binning                                                                  #
import sys                                                                      #
import welcome                                                                  #
import turbulence                                                               #
import debug                                                                    #
import pyfits                                                                   #
import my_model                                                                 #
import planck                                                                   #
import warnings                                                                 #
from mpi4py import MPI                                                          #
                                                                                #
comm = MPI.COMM_WORLD                                                           #
iproc=comm.Get_rank()                                                           #
nproc=comm.Get_size()                                                           #
working_dir = os.getcwd()                                                       #
#- - - - - - - - - - - - - - -Convert to cgs- - - - - - - - - - - - - - - - - - #
h=h*1.e+7                                                                       #
c=c*1.e+2                                                                       #
K_b=k*1.e+7                                                                     #
m_p=m_p*1e+3                                                                    #
parsec=parsec*1e+2                                                              #
#                                                                               #
#- - - - - - - small function to monitor progress of the code- - - - - - - - - -#
#                                                                               #
def update_progress(progress):                                                  #
	barLength = 100                                                         #
	status = ""                                                             #
	if isinstance(progress, int):                                           #
        	progress = float(progress)                                      #
	if not isinstance(progress, float):                                     #
		progress = 0                                                    #
		status = "error: progress var must be float\r\n"                #
	if progress < 0:                                                        #
		progress = 0                                                    #
		status = "Halt...\r\n"                                          #
	if progress >= 1:                                                       #
		progress = 1                                                    # 
		status = "Done...\r\n"                                          #
	block = int(round(barLength*progress))                                  #
	text = "\rPercent: [{0}] {1}% {2}".format( "#"*block + "-"*(barLength-block), round(progress*100,1), status)
	sys.stdout.write(text)                                                  #
	sys.stdout.flush()                                                      #
#                 Make python shut up/disable useless warnings                  #
warnings.filterwarnings("ignore")                                               #
warnings.filterwarnings("ignore",category=DeprecationWarning)                   #
#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -#
#                                                                               #
#    Some utility functions useful for MPI parallel programming                 #
#                                                                               #
#                                                                               #
def rut_even(f):                                                                #
	return math.ceil(f / 2.) * 2                                            #
                                                                                #
def pprint(str="", end="\n", comm=MPI.COMM_WORLD):                              #
    """Print for MPI parallel programs: Only rank 0 prints *str*."""            #
    if iproc == 0:                                                              #
        print (str+end),                                                        #
                                                                                #
pprint('\n')                                                                    #
#-------------------------------------------------------------------------------#

#-------------------------------------------------------------------------------#
#                  Load parameters for specific run                             #
if iproc==0:                                                                    #
                                                                                #
	transition_up, transition_low, X_DoI, nbins, mean, amu_mean, v_type, mturbv_param, path, level, molecule, geom, fi0, th0, eSNR, beam_size, distance, units, spectr_res, txtexport, noise, ppv, beam, line, bins, vturb, debug_h, fits, sim, LTE, cmb, npoints, Tbgr, BINS, DSR, dictionary, TrueDB = setup.setup()                                              #
                                                                                #
	fi=math.radians(fi0)                                                    #
	th=math.radians(th0)                                                    #
else:                                                                           #
	transition_up, transition_low, X_DoI, nbins, mean, amu_mean, v_type, mturbv_param = None, None, None, None, None, None, None, None
	path, level, molecule, geom, fi0, th0, eSNR, beam_size, spectr_res, DSR = None, None, None, None, None, None, None, None, None, None
	distance, units, fortexport, noise, ppv, beam, line, Tbgr, BINS, dictionary =  None, None, None, None, None, None, None, None, None, None
	bins, TrueDB, vturb, debug_h, fits, sim, LTE, fi, th, cmb, npoints =  None, None, None, None, None, None, None, None, None, None, None
                                                                                #
X_DoI, amu_mean, LTE, geom = comm.bcast(X_DoI, root=0), comm.bcast(amu_mean, root=0), comm.bcast(LTE, root=0), comm.bcast(geom, root=0)
fi0, th0, fi,th,line = comm.bcast(fi0, root=0), comm.bcast(th0, root=0), comm.bcast(fi, root=0), comm.bcast(th, root=0), comm.bcast(line, root=0)
cmb, Tbgr, TrueDB = comm.bcast(cmb, root=0), comm.bcast(Tbgr, root=0), comm.bcast(TrueDB, root=0)
#-------------------------------------------------------------------------------#


#-------------------------------------------------------------------------------#
if iproc ==0:                                                                   #
                                                                                #
	if (fi0!=90. and geom==1 and line==True):                               #
                                                                                #
		raise SystemExit("Single Line not yet implemented for cylindrical geometry seen at this angle. Sorry :( !!")
                                                                                #
	elif (geom==2 and line==True):                                          #
                                                                                #
		raise SystemExit("Single Line not yet implemented for cartesian geometry. Sorry :( !!")
#-------------------------------------------------------------------------------#


#-------------------------------------------------------------------------------#
#                                                                               #
#         First take all relative information from simulation                   #
#                                                                               #
#      Velocities moving towards me are negative, velocities moving away        #
#                                are positive                                   #
if iproc==0:                                                                    #
                                                                                #
	if sim==True:                                                           #
                                                                                #
		dens, mol, velx, vely, velz, x, y, z, T=sim_import.sim_import(path, level, molecule, geom, dictionary)
				                                                #
	else:                                                                   #
				                                                #
		dens, mol, velx, vely, velz, x, y, z, T=my_model.my_model(geom) #
else:                                                                           #
                                                                                #
	dens, mol, velx, vely, velz, x, y, z, T = None, None, None, None, None, None, None, None, None 
                                                                                #
dens, mol, velx=comm.bcast(dens, root=0), comm.bcast(mol, root=0), comm.bcast(velx, root=0)
vely, velz, x, y=comm.bcast(vely, root=0), comm.bcast(velz, root=0), comm.bcast(x, root=0), comm.bcast(y, root=0)
z, T = comm.bcast(z, root=0), comm.bcast(T, root=0)                             #
                                                                                #
size=dens.shape                                                                 #
		                                                                #
pprint('\n')                                                                    #
#-------------------------------------------------------------------------------#

#-------------------------------------------------------------------------------#
#               Read data for the molecule from Leiden                          #
if iproc==0:                                                                    #
                                                                                #
	Einstein_A, amu, freq0, C21, gij, Eij, temper, C31 =txtreader.txtreader(molecule, transition_up, transition_low, working_dir)
	                                                                        #
	g1, g2 = gij[int(transition_low-1)], gij[int(transition_up-1)]          #
	                                                                        #
	if TrueDB==False:                                                       #
	                                                                        #
		f=interpolate.interp1d(temper, C21, bounds_error=False, fill_value=C21[:, 0])
			                                                        #
		f2=interpolate.interp1d(temper, C31, bounds_error=False, fill_value=C31[:, 0])
			                                                        #
		C21=f(np.nanmean(T)).sum()                                      #
			                                                        #
		Einstein_A=Einstein_A[int(transition_low-1)]                    #
		#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -#
		#   Convert frequency given in GHz to wavenumber (code units)   #
		#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -#
		freq0=freq0[int(transition_low-1)]*1e+9                         #
			                                                        #
		window=spectr_res*(npoints-1)*freq0/(2.*c)*1.e+5                #
			                                                        #
		freq_0=freq0/c                                                  #
			                                                        #
		freq_range0=np.linspace(freq0-window, freq0+window, npoints)    #
			                                                        #
		freq_range=freq_range0/c                                        #
			                                                        #
		#                  Thermal broadening of the line               #
			                                                        #
		Dfreq_thermal=np.sqrt(1.5*K_b*T/(m_p*amu*c**2))*freq0/c         #
				                                                #
		#  Multiplicity (degeneracy) for linear molecules (e.g. CO) is  #
		#                         g=2*J+1          (*)                  #
		#               In general, g is defined as:                    #
		#                                                               #
		#                        J(J+1)-L(L+1)+S(S+1)                   #
		#                   g=1+----------------------                  #
		#                             2J(J+1)                           #
		#  where S is the total spin of the molecule, L is the total    #
		#      orbital angular momentum and J=L+S is the total          #
		#        angular momentum. This will be useful later            #
		#   when I include circular polarization. For now, equation (*) #
		#                    is sufficient                              #
				                                                #
		#                    Einstein's B coefficient                   #
		Einsteins_B=(Einstein_A/(2.*h*c*freq_0**3))*(g2/g1)             #
		#           B12=(g2/g1)*(Einstein_A/(2*h*c*freq**3))            #
	                                                                        #
		Einstein_A_DB, Cij, freq0_DB, Dfreq_thermal_DB = None, None, None, None
	else:                                                                   #
	                                                                        #
		Einstein_A_DB=Einstein_A.copy()                                 #
			                                                        #
		freq0_DB=freq0.copy()*1e+9                                      #
			                                                        #
		Einstein_A=Einstein_A[int(transition_low-1)]                    #
		#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -#
		#   Convert frequency given in GHz to wavenumber (code units)   #
		#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -#
		freq0=freq0[int(transition_low-1)]*1e+9                         #
			                                                        #
		window=spectr_res*(npoints-1)*freq0/(2.*c)*1.e+5                #
			                                                        #
		freq_0=freq0/c                                                  #
			                                                        #
		freq_range0=np.linspace(freq0-window, freq0+window, npoints)    #
			                                                        #
		freq_range=freq_range0/c                                        #
			                                                        #
		#                  Thermal broadening of the line               #
		Dfreq_thermal_DB = []                                           #
			                                                        #
		for i in range (0, len(freq0_DB)):                              #
			                                                        #
			Dfreq_thermal_DB.append(np.sqrt(1.5*K_b*T/(m_p*amu*c**2))*freq0_DB[i]/c)
			                                                        #
		Dfreq_thermal_DB = np.array(Dfreq_thermal_DB)                   #
			                                                        #
		Dfreq_thermal=np.sqrt(1.5*K_b*T/(m_p*amu*c**2))*freq0/c         #
				                                                #
		freq0_DB = freq0_DB/c                                           #
				                                                #
		Einsteins_B = None                                              #
				                                                #
	print('\n')                                                             #	
else:	                                                                        #
	Einstein_A, amu, freq_0, freq_range, temper=None, None, None, None, None#
	Dfreq_thermal, g2, g1, Einsteins_B, C21=None, None, None, None, None    #
	gij, Eij, Einstein_A_DB, freq0_DB, Cij = None, None, None, None, None   #
	Dfreq_thermal_DB, C31 = None, None                                      #
	                                                                        #
#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -#
#                 Broadcast everything to the rest of the processors            #
#                                                                               #
Einstein_A, amu = comm.bcast(Einstein_A, root=0), comm.bcast(amu, root=0)       #
freq_0, freq_range = comm.bcast(freq_0, root=0), comm.bcast(freq_range, root=0) #
Dfreq_thermal, Eij = comm.bcast(Dfreq_thermal, root=0), comm.bcast(Eij, root=0) #
g2, g1, gij=comm.bcast(g2, root=0), comm.bcast(g1, root=0), comm.bcast(gij, root=0)
Einsteins_B, C21, C31=comm.bcast(Einsteins_B, root=0), comm.bcast(C21, root=0), comm.bcast(C31, root=0)
Einstein_A_DB, freq0_DB = comm.bcast(Einstein_A_DB, root=0), comm.bcast(freq0_DB, root=0)
Dfreq_thermal_DB, temper = comm.bcast(Dfreq_thermal_DB, root=0), comm.bcast(temper, root=0)
	                                                                        #
if TrueDB==True:                                                                #
	                                                                        #
	Cij=interpolate.interp1d(temper, C21, bounds_error=False, fill_value=C21[:, 0])
	                                                                        #
	cij=interpolate.interp1d(temper, C31, bounds_error=False, fill_value=C31[:, 0])
	                                                                        #
	C21=Cij(np.nanmean(T)).sum()                                            #
#-------------------------------------------------------------------------------#


#-------------------------------------------------------------------------------#
#	                                                                        #
#          If anything doesn't work or it works but seems unresonable,          #
#        you get nans or something from the million things that can go wrong    #
#                  here is a small section to test that so far                  #
#               everything we put into the guts of the code are ok              #
#	                                                                        #
#          In any case DO NOT LOSE HOPE and e-mail me, I can probably help      #
#	                                                                        #
if iproc==0:                                                                    #
		                                                                #
	if debug_h==True:                                                       #
		                                                                #
		import matplotlib.pyplot as plt                                 #
		                                                                #
		if geom==0:                                                     #
		                                                                #
			vely, velz=np.zeros(velx.shape), np.zeros(velx.shape)   #
		                                                                #
			y, z=np.zeros(x.shape), np.zeros(x.shape)               #
		                                                                #
			fig=debug.debug(geom, dens, mol, x, y, z, Dfreq_thermal, T, C21, velx, vely, velz, Einstein_A, freq0, amu)
                                                                                #
		elif geom==1:                                                   #
		                                                                #
			vely=np.zeros(velx.shape)                               #
		                                                                #
			y=np.zeros(x.shape)                                     #
		                                                                #
			fig=debug.debug(geom, dens, mol, x, y, z, Dfreq_thermal, T, C21, velx, vely, velz, Einstein_A, freq0, amu)
		                                                                #
		elif geom==2:                                                   #
		                                                                #
			fig=debug.debug(geom, dens, mol, x, y, z, Dfreq_thermal, T, C21, velx, vely, velz, Einstein_A, freq0, amu)
                                                                                #
		plt.show()                                                      #
#-------------------------------------------------------------------------------#

#-------------------------------------------------------------------------------#
if iproc==0:                                                                    #
	welcome.welcome()                                                       #
                                                                                #
pprint('\n')                                                                    #
                                                                                #
pprint(" "*35+"Running on %d core(s)" % comm.size)                              #
#-------------------------------------------------------------------------------#

#-------------------------------------------------------------------------------#
                                                                                #
if iproc==0:                                                                    #
                                                                                #
	if not os.path.exists('{}/output_files'.format(working_dir)):           #
				                                                #
		os.mkdir('{}/output_files'.format(working_dir))                 #
		                                                                #
#-------------------------------------------------------------------------------#

#-------------------------------------------------------------------------------#
#         call "populations" to get the population ratio between the            #
#                          the upper and lower levels                           #
#        	                                                                #
#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -#
#                                                                               #
#                              SPHERICAL                                        #
#                                                                               #
#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -#
if LTE==False:                                                                  #
			                                                        #
	pprint('\n')                                                            #
	pprint(" "*20+"Calculating population densities. Please wait :)")       #
			                                                        #
	if geom==0:                                                             #
		 	                                                        #
		if TrueDB==False:                                               #
		 	                                                        #
			if iproc==0:                                            #
			 	                                                #
				dist=x[1]-x[0]                                  #
			 	                                                #
				PopRat=populations_sph.populations_sph(dens/m_p/amu_mean, Einstein_A, C21, freq_0, Dfreq_thermal, T, mol, velx, velz, dist, geom, g1, g2, amu_mean, cmb)                                        #
			else:                                                   #
				PopRat=None                                     #
			                                                        #
		else:                                                           #
		 	                                                        #
			if iproc==0:                                            #
			 	                                                #
				dist=x[1]-x[0]                                  #
			 	                                                #
				PopRat=populations_sphDB.populations_sphDB(dens/m_p/amu_mean, Einstein_A_DB, Cij, cij, freq0_DB, Dfreq_thermal_DB, T, mol, velx, velz, dist, geom, gij, amu_mean, cmb)           #
			 	                                                #
				np.save('{}/output_files/PopRat_DB'.format(working_dir), PopRat)
			 	                                                #
				PopRat = PopRat[:, transition_up-1]/PopRat[:, transition_low-1]
			else:                                                   #
				PopRat=None                                     #
			                                                        #
		PopRat=comm.bcast(PopRat, root=0)                               #
	#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -#
	#                                                                       #
	#                         CYLINDRICAL                                   #
	#                                                                       #
	#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -#
			                                                        #
	elif geom==1:                                                           #
			                                                        #
		if TrueDB==False:                                               #
			                                                        #
			dist=x[1]-x[0]                                          #
					                                        #
			PopRat=populations_cyl.populations_cyl(dens/m_p/amu_mean, Einstein_A, C21, freq_0, Dfreq_thermal, T, mol, velx, velz, dist, geom, z, g1, g2, amu_mean, cmb)                                           #
					                                        #
			PopRat_gathered=comm.gather(PopRat, root=0)             #
										#
			if iproc==0:                                            #
									        #
				PopRat=np.array(PopRat_gathered).astype(float)  #
										#
				size2=PopRat.shape                              #
									        #
				PopRat=PopRat.reshape(nproc*size2[1], size2[2]) #
					                                        #
			else:                                                   #
				PopRat=None                                     #
					                                        #
			PopRat=comm.bcast(PopRat, root=0)                       #
					                                        #
		else:                                                           #
					                                        #
			dist=x[1]-x[0]                                          #
					                                        #
			PopRat=populations_cylDB.populations_cylDB(dens/m_p/amu_mean, Einstein_A_DB, Cij, cij, freq0_DB, Dfreq_thermal_DB, T, mol, velx, velz, dist, geom, z, gij, amu_mean, cmb)                             #
					                                        #
			PopRat_gathered=comm.gather(PopRat, root=0)             #
										#
			if iproc==0:                                            #
									        #
				PopRat=np.array(PopRat_gathered).astype(float)  #
										#
				size2=PopRat.shape                              #
									        #
				PopRat=PopRat.reshape(nproc*size2[1], size2[2], size2[3])
					                                        #
				np.save('{}/output_files/PopRat_DB'.format(working_dir), PopRat)
			 	                                                #
				PopRat = PopRat[:, :, transition_up-1]/PopRat[:, :, transition_low-1]
			 	                                                #
			else:                                                   #
				PopRat=None                                     #
					                                        #
			PopRat=comm.bcast(PopRat, root=0)                       #
					                                        #
	#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -#
	#                                                                       #
	#                               CARTESIAN                               #
	#                                                                       #
	#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -#
		                                                                #
	if geom==2:                                                             #
			                                                        #
		if TrueDB==False:                                               #
			                                                        #
			dist=x[1]-x[0]                                          #
					                                        #
			PopRat=populations_crt.populations_crt(dens/m_p/amu_mean, Einstein_A, C21, freq_0, Dfreq_thermal, T, mol, velx, vely, velz, dist, geom, y, g1, g2, amu_mean, cmb)                                     #
					                                        #
			PopRat_gathered=comm.gather(PopRat, root=0)             #
										#
			if iproc==0:                                            #
									        #
				PopRat=np.array(PopRat_gathered).astype(float)  #
										#
				size2=PopRat.shape                              #
									        #
				PopRat=PopRat.reshape(nproc*size2[1], size2[2]) #
					                                        #
			else:                                                   #
				PopRat=None                                     #
					                                        #
			PopRat=comm.bcast(PopRat, root=0)                       #
					                                        #
		else:                                                           #
					                                        #
			dist=x[1]-x[0]                                          #
					                                        #
			PopRat=populations_crtDB.populations_crtDB(dens/m_p/amu_mean, Einstein_A_DB, Cij, cij, freq0_DB, Dfreq_thermal_DB, T, mol, velx, vely, velz, dist, geom, y, gij, amu_mean, cmb)                       #
					                                        #
			PopRat_gathered=comm.gather(PopRat, root=0)             #
										#
			if iproc==0:                                            #
									        #
				PopRat=np.array(PopRat_gathered).astype(float)  #
										#
				np.save('{}/output_files/PopRat_DB'.format(working_dir), PopRat)
										#
				size2=PopRat.shape                              #
									        #
				PopRat=PopRat.reshape(nproc*size2[1], size2[2], size2[3], size2[4])
					                                        #
				np.save('{}/output_files/PopRat_DB'.format(working_dir), PopRat)
			 	                                                #
				PopRat = PopRat[:, :, :, transition_up-1]/PopRat[:, :, :, transition_low-1]
			 	                                                #
			else:                                                   #
				PopRat=None                                     #
					                                        #
			PopRat=comm.bcast(PopRat, root=0)                       #
					                                        #
else:                                                                           #
	dist=x[1]-x[0]                                                          #
			                                                        #
	Texcit = freq_0*h*c/K_b                                                 #
			                                                        #
	PopRat=g2/g1*np.exp(-Texcit/T)                                          #
									        #
	PopRat=comm.bcast(PopRat, root=0)                                       #
	#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -#
if iproc==0:                                                                    #
			                                                        #
	np.save('{}/output_files/PopRat'.format(working_dir), PopRat)           #
#-------------------------------------------------------------------------------#


#-------------------------------------------------------------------------------#
if iproc==0:                                                                    #
	                                                                        #
	if vturb==True:                                                         #
	                                                                        #
		if geom==0:                                                     #
		                                                                #
			velx_vturb, vely_vturb, velz_vturb = velx, np.empty(velx.shape)*np.nan, np.empty(velx.shape)*np.nan
		                                                                #
			Dfreq_thermal=turbulence.turbulence(geom, Dfreq_thermal, velx_vturb, vely_vturb, velz_vturb, freq_0, v_type, mturbv_param)
		                                                                #
		elif geom==1:                                                   #
		                                                                #
			velx_vturb, vely_vturb, velz_vturb = velx, velz, np.empty(velx.shape)*np.nan
		                                                                #
			Dfreq_thermal=turbulence.turbulence(geom, Dfreq_thermal, velx_vturb, vely_vturb, velz_vturb, freq_0, v_type, mturbv_param)
		                                                                #
		else:                                                           #
			velx_vturb, vely_vturb, velz_vturb = velr, vely, velz   #
		                                                                #
			Dfreq_thermal=turbulence.turbulence(geom, Dfreq_thermal, velx_vturb, vely_vturb, velz_vturb, freq_0, v_type, mturbv_param)
#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -#
#	                                                                        #
#                           Define interpolating functions                      #
#      so that in the following everything is updated no matter the case        #
	                                                                        #
if geom==1 and (fi0!=0. and fi0!=90.):                                          #
	#-----------------------------------------------------------------------#
	#            Interpolating function for off axis projection             #
	#              These should be defined for all processors               #
	#-----------------------------------------------------------------------#
	Z=np.linspace(min(z)-max(x)*np.tan(fi), max(z), len(z))                 #
		                                                                #
	PopRat_interpd=interpolate.interp2d(x, z, PopRat, kind='linear', fill_value=0.)
	                                                                        #
	Dfreq_thermal_interpd=interpolate.interp2d(x, z, Dfreq_thermal, kind='linear', fill_value=1.)
	                                                                        #
	dens_interpd=interpolate.interp2d(x, z, dens, kind='linear', fill_value=0.)
	                                                                        #
	mol_interpd=interpolate.interp2d(x, z, mol, kind='linear', fill_value=0.)
	                                                                        #
	velr_interpd=interpolate.interp2d(x, z, velx, kind='linear', fill_value=0.)
	                                                                        #
	velz_interpd=interpolate.interp2d(x, z, velz, kind='linear', fill_value=0.)
	                                                                        #
	T_interpd=interpolate.interp2d(x, z, T, kind='linear', fill_value=0.)   #
	                                                                        #
if geom==2 and (fi0!=0. or th0!=0.):                                            #
	#-----------------------------------------------------------------------#
	#            Interpolating function for off axis projection             #
	#              These should be defined for all processors               #
	#-----------------------------------------------------------------------#
	X=np.linspace(min(x)-max(z)*np.tan(fi), max(x)+max(z)*np.tan(fi), len(x))
						                                #
	Y=np.linspace(min(y)-max(z)*np.tan(th), max(y)+max(z)*np.tan(th), rut_even(len(y)+round(int(len(z)*np.tan(th)))))
	                                                                        #
	PopRat_interpd=interpolate.RegularGridInterpolator((y, x, z), PopRat, bounds_error=False, fill_value=0.)
	                                                                        #
	Dfreq_thermal_interpd=interpolate.RegularGridInterpolator((y, x, z), Dfreq_thermal, bounds_error=False, fill_value=1.)
	                                                                        #
	dens_interpd=interpolate.RegularGridInterpolator((y, x, z), dens, bounds_error=False, fill_value=0.)
	                                                                        #
	mol_interpd=interpolate.RegularGridInterpolator((y, x, z), mol, bounds_error=False, fill_value=0.)
	                                                                        #
	velx_interpd=interpolate.RegularGridInterpolator((y, x, z), velx, bounds_error=False, fill_value=0.)
	                                                                        #
	vely_interpd=interpolate.RegularGridInterpolator((y, x, z), vely, bounds_error=False, fill_value=0.)
	                                                                        #
	velz_interpd=interpolate.RegularGridInterpolator((y, x, z), velz, bounds_error=False, fill_value=0.)
	                                                                        #
	T_interpd=interpolate.RegularGridInterpolator((y, x, z), T, bounds_error=False, fill_value=0.)
	                                                                        #
pprint('\n')                                                                    #
pprint(" "*25+"Finished! Starting the integration...")                          #
#-------------------------------------------------------------------------------#


#-------------------------------------------------------------------------------#
#		                                                                #
#                         SPHERICAL CORE/LINE & MAP                             #
#		          -------------------------                             #
if geom==0:                                                                     #
	#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -#
	#                             MAP                                       #
	#                        (parallel mode)                                #
	#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -#
 		                                                                #
	if line==False:                                                         #
 		                                                                #
		if iproc==0:                                                    #
 		                                                                #
			rr, PopRat = x[len(x)/2:len(x)], PopRat[len(x)/2:len(x)]#
	 		                                                        #
			dens, mol, velx=dens[len(x)/2:len(x)], mol[len(x)/2:len(x)], velx[len(x)/2:len(x)]
	 		                                                        #
			T, Dfreq_thermal = T[len(x)/2:len(x)], Dfreq_thermal[len(x)/2:len(x)]
	 		                                                        #
			x=rr.copy()                                             #
		else:                                                           #
 		                                                                #
			rr, PopRat, dens, mol, velx = None, None, None, None, None           
 		                                                                #
			T, Dfreq_thermal, xx = None, None, None                 #
 		                                                                #
		rr, PopRat = comm.bcast(rr, root=0), comm.bcast(PopRat, root=0) #
 		                                                                #
		dens, mol = comm.bcast(dens, root=0), comm.bcast(mol, root=0)   #
 		                                                                #
		velx, T = comm.bcast(velx, root=0), comm.bcast(T, root=0)       #
 		                                                                #
		Dfreq_thermal, x = comm.bcast(Dfreq_thermal, root=0), comm.bcast(x, root=0)
 		                                                                #
		emission=[]                                                     #
 		                                                                #
		chopped_rrs=np.empty(len(rr)/nproc, dtype=np.float64)           #
					                                        #
		comm.Scatter([rr, MPI.DOUBLE], [chopped_rrs, MPI.DOUBLE])       #
					                                        #
		pr=0.                                                           #
					                                        #                        
		for j in range (0, len(chopped_rrs)):                           #
					                                        #
			pr = pr + 1./len(chopped_rrs)                           #
							                        #
			ILOS=np.empty(len(freq_range))                          #
							                        #
			index=np.where(x==chopped_rrs[j])[0][0]                 #
							                        #
			x_temp2, x_temp1=-x[index+1:len(x)][::-1], x[index+1:len(x)]
							                        #
			x_temp=np.hstack((x_temp2, x_temp1))		        #
							                        #
			dens_temp2, dens_temp1=dens[index+1:len(dens)][::-1], dens[index+1:len(dens)]
							                        #
			dens_temp=np.hstack((dens_temp2, dens_temp1))           #
							                        #
			mol_temp2, mol_temp1=mol[index+1:len(mol)][::-1], mol[index+1:len(mol)]
							                        #
			mol_temp=np.hstack((mol_temp2, mol_temp1))              #
							                        #
			velx_temp2, velx_temp1=-velx[index+1:len(velx)][::-1], velx[index+1:len(velx)]
							                        #
			velx_temp=np.hstack((velx_temp2, velx_temp1))           #
							                        #
			PopRat_temp2, PopRat_temp1 = PopRat[index+1:len(PopRat)][::-1], PopRat[index+1:len(PopRat)]
							                        #
			PopRat_temp=np.hstack((PopRat_temp2, PopRat_temp1))     #
							                        #
			Dfreq_thermal_temp2, Dfreq_thermal_temp1 = Dfreq_thermal[index+1:len(T)][::-1], Dfreq_thermal[index+1:len(T)]
							                        #
			Dfreq_thermal_temp=np.hstack((Dfreq_thermal_temp2, Dfreq_thermal_temp1))
							                        #
			T_temp2, T_temp1 = T[index+1:len(T)][::-1], T[index+1:len(T)]
							                        #
			T_temp=np.hstack((T_temp2, T_temp1))                    #
							                        #
			for m in range (len(freq_range)-1, -1, -1):             #
							                        #
				freq=freq_range[m]                              #
							                        #
				vel_a, S_line_a, Itotal, Line_abs_a, S_c_a, k_ext_a=0., 0., 0., 0., 0., 0.
							                        #
				if Tbgr==0.:                                    #
							                        #
					I_a=0.                                  #
				else:                                           #
					I_a=planck.planck(Tbgr, freq)           #
							                        #
				for i in range (0, len(x_temp)-1):              #
							                        #
					dens_grid_point=dens_temp[i]            #
							                        #
					vel_b=velx_temp[i]*np.cos(np.arcsin(chopped_rrs[j]/x_temp[i]))
							                        #
					mol_grid_point=mol_temp[i]              #
							                        #
					Xrat=PopRat_temp[i]                     #
							                        #
					Dfreq_thermal_grid_point, T_grid_point =Dfreq_thermal_temp[i], T_temp[i]
							                        #
					dist=abs(np.sqrt(x_temp[i+1]**2-chopped_rrs[j]**2)-np.sqrt(x_temp[i]**2-chopped_rrs[j]**2))
								                #
					S_c_b, k_ext_b, S_line_b, Line_abs_b=sourcef.sourcef(T_grid_point, freq, dens_grid_point, Xrat, Einstein_A, mol_grid_point, X_DoI, g1, g2, LTE)                                 #
					I_b=rad_tran_eq_integration.rad_tran_eq_integration(freq, vel_a, vel_b, dist, freq_0, Dfreq_thermal_grid_point, I_a, S_c_a, S_c_b, S_line_a, S_line_b, Line_abs_a, Line_abs_b, k_ext_a, k_ext_b)
								                #
					Itotal=I_b+Itotal                       #
						                                #
					I_a, vel_a, S_line_a, Line_abs_a, S_c_a, k_ext_a=I_b, vel_b, S_line_b, Line_abs_b, S_c_b, k_ext_b
							                        #
				ILOS[m]=Itotal                                  #
					                                        #
			if iproc==0:                                            #
						                                #
				update_progress(pr)                             #
							                        #
			ILOS=np.array(ILOS).astype(float)                       #
							                        #
			emission.append(ILOS)                                   #
							                        #
		emission=np.array(emission)                                     #
							                        #
		emission=comm.gather(emission, root=0)                          #
							                        #
		if iproc==0:                                                    #
							                        #
			emission=np.array(emission)                             #
							                        #
			emission=emission.astype(float)                         #
							                        #
			size2=emission.shape                                    #
							                        #
			emission=emission.reshape(nproc*size2[1], size2[2])     #
							                        #
			emission=units_ch.units_ch(units, emission, beam_size, freq0, freq_range0)
							                        #
			PPV=PPV.PPV(freq_range, emission, x, noise, ppv, beam, eSNR, mean, beam_size, distance)
							                        #
			np.save('{}/output_files/PPV'.format(working_dir), PPV) #
				 			                        #	
			x2=-x[::-1]                                             #
				 			                        #
			x=np.hstack((x2, x))                                    #
				 			                        #
			y=x.copy()                                              #
	#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -#
					                                        #
	else:                                                                   #
	#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -#
	#                           SiNGLE LINE                                 #
	#                  (fast enough in serial mode)                         #
	#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -#
					                                        #
		if iproc==0:                                                    #
							                        #
				ILOS=[]                                         #
								                #
				pr=0.                                           #
								                #
				dist=abs(x[1]-x[0])                             #
								                #
				for freq in freq_range[::-1]:                   #
								                #
					pr = pr + 1./len(freq_range)            #
								                #
					update_progress(pr)                     #
								                #
					vel_a, S_line_a, Itotal, Line_abs_a, S_c_a, k_ext_a=0., 0., 0., 0., 0., 0.
								                #
					if Tbgr==0.:                            #
									        #
						I_a=0.                          #
					else:                                   #
						I_a=planck.planck(Tbgr, freq)   #
									        #
					for i in range (0, len(x)):             #
								                #
						Xrat=PopRat[i]                  #
								                #
						dens_grid_point, vel_b, mol_grid_point=dens[i], velx[i], mol[i]
								                #
						Dfreq_thermal_grid_point, T_grid_point=Dfreq_thermal[i], T[i]
								                #
						S_c_b, k_ext_b, S_line_b, Line_abs_b=sourcef.sourcef(T_grid_point, freq, dens_grid_point, Xrat, Einstein_A, mol_grid_point, X_DoI, g1, g2, LTE)      		                #
						I_b=rad_tran_eq_integration.rad_tran_eq_integration(freq, vel_a, vel_b, dist, freq_0, Dfreq_thermal_grid_point, I_a, S_c_a, S_c_b, S_line_a, S_line_b, Line_abs_a, Line_abs_b, k_ext_a, k_ext_b)
								                #
						Itotal=I_b+Itotal               #
								                #
						I_a, vel_a, S_line_a, Line_abs_a, S_c_a, k_ext_a=I_b, vel_b, S_line_b, Line_abs_b, S_c_b, k_ext_b                                                                         #
							                        #
					ILOS.append(Itotal)                     #
								                #
				if noise==True:                                 #
								                #
					ILOS=gaussian_noise.gaussian_noise(ILOS, np.mean(ILOS), eSNR, mean)
								                #
				PPV=ILOS                                        #
								                #
				PPV= units_ch.units_ch(units, PPV, beam_size, freq0, freq_range0)
								                #
				np.save('{}/output_files/PPV'.format(working_dir), PPV)
#-------------------------------------------------------------------------------#



#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -#
#		                                                                #
#                         CYLINDRICAL CORE/LINE & MAP                           #
#		          ---------------------------                           #
if geom==1.:                                                                    #
				                                                #
	if fi0==90.:                                                            #
		#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -#
		#                   FACE ON MAP                                 #
		#           (fast enough in serial mode)                        #
		#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -#
		if iproc==0:                                                    #
 		                                                                #
			r, PopRat = x[len(x)/2:len(x)], PopRat[:, len(PopRat[0])/2:len(PopRat[0])]
	 		                                                        #
			dens, mol, velz=dens[:, len(dens[0])/2:len(dens[0])], mol[:, len(mol[0])/2:len(mol[0])], velz[:, len(mol[0])/2:len(mol[0])]
	 		                                                        #
			T, Dfreq_thermal = T[:, len(T[0])/2:len(T[0])], Dfreq_thermal[:, len(Dfreq_thermal[0])/2:len(Dfreq_thermal[0])]
	 		                                                        #
			if line==False:                                         #
						                                #
				emission=[]                                     #
							                        #
				pr=0.                                           #
							                        #                        
				for j in range (0, len(r)):                     #
								                #
					pr = pr + 1./len(r)                     #
								                #
					update_progress(pr)                     #
									        #
					ILOS=[]                                 #
									        #
					for freq in freq_range[::-1]:           #
									        #
						vel_a, S_line_a, Itotal, Line_abs_a, S_c_a, k_ext_a=0., 0., 0., 0., 0., 0.
									        #
						if Tbgr==0.:                    #
									        #
							I_a=0.                  #
						else:                           #
							I_a=planck.planck(Tbgr, freq)
									        #
						for i in range (0, len(z)):     #
									        #
							Xrat=PopRat[i, j]       #
									        #
							dens_grid_point, vel_b, mol_grid_point=dens[i, j], velz[i, j], mol[i, j]
									        #
							T_grid_point, Dfreq_thermal_grid_point=T[i, j], Dfreq_thermal[i, j]
								                #
							S_c_b, k_ext_b, S_line_b, Line_abs_b=sourcef.sourcef(T_grid_point, freq, dens_grid_point, Xrat, Einstein_A, mol_grid_point, X_DoI, g1, g2, LTE)		                #
							I_b=rad_tran_eq_integration.rad_tran_eq_integration(freq, vel_a, vel_b, dist, freq_0, Dfreq_thermal_grid_point, I_a, S_c_a, S_c_b, S_line_a, S_line_b, Line_abs_a, Line_abs_b, k_ext_a, k_ext_b)
										#
							Itotal=I_b+Itotal       #
									        #
							I_a, vel_a, S_line_a, Line_abs_a, S_c_a, k_ext_a=I_b, vel_b, S_line_b, Line_abs_b, S_c_b, k_ext_b                                                                         #
						ILOS.append(Itotal)             #
									        #
					emission.append(ILOS)                   #
									        #
				emission=np.array(emission)                     #
									        #
				emission = units_ch.units_ch(units, emission, beam_size, freq0, freq_range0)
									        #
				PPV=PPV.PPV(freq_range, emission, r, noise, ppv, beam, eSNR, mean, beam_size, distance)
								                #
				np.save('{}/output_files/PPV'.format(working_dir), PPV)
									        #
				y=x.copy()                                      #
		#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -#
		#                    FACE ON LINE                               #
		#           (fast enough in serial mode)                        #
		#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -#
			else:                                                   #
				ILOS=[]                                         #
								                #
				pr=0.                                           #
								                #
				for freq in freq_range[::-1]:                   #
								                #
					pr = pr + 1./len(freq_range)            #
								                #
					update_progress(pr)                     #
								                #
					vel_a, S_line_a, Itotal, Line_abs_a, S_c_a, k_ext_a=0., 0., 0., 0., 0., 0.
								                #
					if Tbgr==0.:                            #
								                #
						I_a=0.                          #
					else:                                   # 
						I_a=planck.planck(Tbgr, freq)   #
									        #
					for i in range (0, len(z)):             #
									        #
						Xrat=PopRat[i, 0]               #
								                #
						dens_grid_point, vel_b, mol_grid_point=dens[i, 0], velz[i, 0], mol[i, 0]
									        #
						T_grid_point, Dfreq_thermal_grid_point=T[i, 0], Dfreq_thermal[i, 0]
								                #
						S_c_b, k_ext_b, S_line_b, Line_abs_b=sourcef.sourcef(T_grid_point, freq, dens_grid_point, Xrat, Einstein_A, mol_grid_point, X_DoI, g1, g2, LTE)		                        #
						I_b=rad_tran_eq_integration.rad_tran_eq_integration(freq, vel_a, vel_b, dist, freq_0, Dfreq_thermal_grid_point, I_a, S_c_a, S_c_b, S_line_a, S_line_b, Line_abs_a, Line_abs_b, k_ext_a, k_ext_b)
								                #
						Itotal=I_b+Itotal               #
								                #
						I_a, vel_a, S_line_a, Line_abs_a, S_c_a, k_ext_a=I_b, vel_b, S_line_b, Line_abs_b, S_c_b, k_ext_b
								                #
					ILOS.append(Itotal)                     #
								                #
				if noise==True:                                 #
								                #
					ILOS=gaussian_noise.gaussian_noise(ILOS, np.mean(ILOS), eSNR, mean)
								                #
				PPV=ILOS                                        #
								                #
				PPV= units_ch.units_ch(units, PPV, beam_size, freq0, freq_range0)
								                #
				np.save('{}/output_files/PPV'.format(working_dir), PPV)
	#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -#
				                                                #
	elif fi0==0.:                                                           #
				                                                #
		if iproc==0:                                                    #
			                                                        #
			dens=dens[len(dens)/2:len(dens), len(dens[0])/2:len(dens[0])]
			                                                        #
			mol=mol[len(mol)/2:len(mol), len(mol[0])/2:len(mol[0])] #
			                                                        #
			T=T[len(T)/2:len(T), len(T[0])/2:len(T[0])]             #
			                                                        #
			Dfreq_thermal=Dfreq_thermal[len(Dfreq_thermal)/2:len(Dfreq_thermal), len(Dfreq_thermal[0])/2:len(Dfreq_thermal[0])]
			                                                        #
			PopRat=PopRat[len(PopRat)/2:len(PopRat), len(PopRat[0])/2:len(PopRat[0])]
			                                                        #
			velr=velx[len(velx)/2:len(velx), len(velx[0])/2:len(velx[0])]
			                                                        #
			rr, z = x[len(x)/2:len(x)], z[len(z)/2:len(z)]          #
			                                                        #
			x=rr.copy()                                             #
		else:                                                           #
			dens, mol, T, Dfreq_thermal=None, None, None, None      #
			                                                        #
			PopRat, velr, rr, z, x= None, None, None, None, None    #
					                                        #
		dens, mol, rr = comm.bcast(dens, root=0), comm.bcast(mol, root=0), comm.bcast(rr, root=0)
			                                                        #
		T, Dfreq_thermal, z = comm.bcast(T, root=0), comm.bcast(Dfreq_thermal, root=0), comm.bcast(z, root=0)
			                                                        #
		PopRat, velr, x = comm.bcast(PopRat, root=0), comm.bcast(velr, root=0), comm.bcast(x, root=0)
                                                                                #
		size=dens.shape                                                 #
                                                                                #
		chopped_zs=np.empty(size[0]/nproc, dtype=np.float64)            #
                                                                                #
		comm.Scatter([z, MPI.DOUBLE], [chopped_zs, MPI.DOUBLE])         #
                                                                                #
		#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -#
		#                   EDGE ON MAP                                 #
		#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -#
				                                                #
		if line==False:                                                 #
					                                        #
			emission=[]                                             #
					                                        #
			pr=0.                                                   #
					                                        #
			for i in range (0, len(chopped_zs)):                    #
								                # 
				pr = pr + 1./len(chopped_zs)                    #
								                #
				if iproc==0:                                    #
								                #
					update_progress(pr)                     #
								                #
				rows=np.empty((len(rr), len(freq_range)))       #
								                #
				for j in range (0, len(rr)):                    #
								                #
					ILOS=np.empty(len(freq_range))          #
								                #
					index1=np.where(x==rr[j])[0][0]         #
										#
					index2=np.where(z==chopped_zs[i])[0][0] #
										#
					r_temp2, r_temp1=-x[index1+1:len(x)][::-1], x[index1+1:len(x)]
										#
					r_temp=np.hstack((r_temp2, r_temp1))	#
										#
					dens_temp2, dens_temp1=dens[:, index1+1:len(dens[0])][:, ::-1], dens[:, index1+1:len(dens[0])]
										#
					dens_temp=np.hstack((dens_temp2, dens_temp1))
									        #
					mol_temp2, mol_temp1=mol[:, index1+1:len(mol[0])][:, ::-1], mol[:, index1+1:len(mol[0])]
									        #
					mol_temp=np.hstack((mol_temp2, mol_temp1))
										#
					velr_temp2, velr_temp1=-velr[:, index1+1:len(velr[0])][:, ::-1], velr[:, index1+1:len(velr[0])]
										#
					velr_temp=np.hstack((velr_temp2, velr_temp1))
									        #
					PopRat_temp2, PopRat_temp1=PopRat[:, index1+1:len(PopRat[0])][:, ::-1], PopRat[:, index1+1:len(PopRat[0])]
										#
					PopRat_temp=np.hstack((PopRat_temp2, PopRat_temp1))
										#
					T_temp2, T_temp1=T[:, index1+1:len(T[0])][:, ::-1], T[:, index1+1:len(T[0])]
										#
					T_temp=np.hstack((T_temp2, T_temp1))    #
										#
					Dfreq_thermal_temp2, Dfreq_thermal_temp1=Dfreq_thermal[:, index1+1:len(Dfreq_thermal[0])][:, ::-1], Dfreq_thermal[:, index1+1:len(Dfreq_thermal[0])]                                #
					Dfreq_thermal_temp=np.hstack((Dfreq_thermal_temp2, Dfreq_thermal_temp1))
										#
					for m in range (len(freq_range)-1, -1, -1): 
										#
						freq=freq_range[m]              #
									        #
						vel_a, S_line_a, Itotal, Line_abs_a, S_c_a, k_ext_a=0., 0., 0., 0., 0., 0.
		 								#
						if Tbgr==0.:                    #
									        #
							I_a=0.                  #
						else:                           #
							I_a=planck.planck(Tbgr, freq)
									        #
						for k in range (0, len(r_temp)-1):
							                        #
							Xrat=PopRat_temp[index2, k]
							                        #
							dens_grid_point=dens_temp[index2, k]
								                #
							T_grid_point=T_temp[index2, k]
								                #
							Dfreq_thermal_grid_point=Dfreq_thermal_temp[index2, k]
								                #
							vel_b=velr_temp[index2, k]*np.cos(np.arcsin(rr[j]/r_temp[k]))
										#
							mol_grid_point=mol_temp[index2, k]
								                #
							dist=np.sqrt(r_temp[k]**2+r_temp[k+1]**2-2*r_temp[k]*r_temp[k+1]*np.cos(np.arcsin(rr[j]/r_temp[k+1])-np.arcsin(rr[j]/r_temp[k])))                                             #
							#dist=abs(np.sqrt(r_temp[k+1]**2-rr[j]**2)-np.sqrt(r_temp[k]**2-rr[j]**2))
								                #
							S_c_b, k_ext_b, S_line_b, Line_abs_b=sourcef.sourcef(T_grid_point, freq, dens_grid_point, Xrat, Einstein_A, mol_grid_point, X_DoI, g1, g2, LTE)		                #
							I_b=rad_tran_eq_integration.rad_tran_eq_integration(freq, vel_a, vel_b, dist, freq_0, Dfreq_thermal_grid_point, I_a, S_c_a, S_c_b, S_line_a, S_line_b, Line_abs_a, Line_abs_b, k_ext_a, k_ext_b)
										#
							Itotal=I_b+Itotal       #
									        #
							I_a, vel_a, S_line_a, Line_abs_a, S_c_a, k_ext_a=I_b, vel_b, S_line_b, Line_abs_b, S_c_b, k_ext_b                                                                         #
						ILOS[m]=Itotal                  #
										#
					ILOS=np.array(ILOS).astype(float)       #
								                #
					rows[j]=ILOS                            #
								                #
				rows=np.array(rows).astype(float)               #
								                #
				emission.append(rows)                           #
								                #
			emission=np.array(emission)                             #
								                #
			emission_gathered=comm.gather(emission, root=0)         #
								                #
			if iproc==0:                                            #
								                #
				emission=np.array(emission_gathered).astype(float)
								                #
				size2=emission.shape                            #
								                #
				emission=emission.reshape(nproc*size2[1], size2[2], size2[3])
								                #
				emission = units_ch.units_ch(units, emission, beam_size, freq0, freq_range0)
								                #
				PPV=PPV.PPV(freq_range, emission, x, noise, ppv, beam, eSNR, mean, beam_size, distance)
								                #	
				x2=-x[::-1]                                     #
								                #	
				x=np.hstack((x2, x))                            #
								                #	
				PPV2=PPV[::-1]                                  #
								                #	
				PPV=np.vstack((PPV2, PPV))                      #
								                #	
				PPV2=np.fliplr(PPV)                             #
								                #	
				PPV=np.hstack((PPV2, PPV))                      #
								                #
				np.save('{}/output_files/PPV'.format(working_dir), PPV)
	#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -#
	else:                                                                   #
		size=dens.shape                                                 #
                                                                                #
		chopped_zs=np.empty(size[0]/nproc, dtype=np.float64)            #
                                                                                #
		comm.Scatter([Z, MPI.DOUBLE], [chopped_zs, MPI.DOUBLE])         #
                                                                                #
		if iproc==0:                                                    #
                                                                                #
			rr=x[len(x)/2:len(x)]                                   #
		else:                                                           #
			rr=None                                                 #
                                                                                #
		rr=comm.bcast(rr, root=0)                                       #
		#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -#
		#                   OFF AXIS MAP                                #
		#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -#  
		if line==False:                                                 #
				                                                #
			emission=np.empty((size[0]/nproc, len(rr), len(freq_range)))
					                                        #
			pr=0.                                                   #
					                                        #
			for i in range (0, len(chopped_zs)):                    #
								                # 
				pr = pr + 1./len(chopped_zs)                    #
								                #
				if iproc==0:                                    #
								                #
					update_progress(pr)                     #
								                #
				rows=np.empty((len(rr), len(freq_range)))       #
								                #
				for j in range (0, len(rr)):                    #
								                #
					ILOS=np.empty(len(freq_range))          #
										#
					r_temp1=rr[j:len(rr)]                   #
										#
					r_temp2=-r_temp1[::-1]                  #
										#
					r_temp=np.hstack((r_temp2, r_temp1))	#
										#
					for m in range (0, len(freq_range)):    #
								                #
						z_loc = chopped_zs[i]           #
										#
						freq=freq_range[m]              #
									        #
						vel_a, S_line_a, Itotal, Line_abs_a, S_c_a, k_ext_a=0., 0., 0., 0., 0., 0.
		 								#
						if Tbgr==0.:                    #
									        #
							I_a=0.                  #
						else:                           #
							I_a=planck.planck(Tbgr, freq)
									        #
						for k in range (0, len(r_temp)-1):
							                        #
							Xrat=PopRat_interpd(r_temp[k], z_loc)[0]
							                        #
							dens_grid_point=dens_interpd(r_temp[k], z_loc)[0]
								                #
							mol_grid_point=mol_interpd(r_temp[k], z_loc)[0]
										#
							T_grid_point=T_interpd(r_temp[k], z_loc)[0]
										#
							Dfreq_thermal_grid_point=Dfreq_thermal_interpd(r_temp[k], z_loc)[0]
										#
							vel_r_grid_point=velr_interpd(r_temp[k], z_loc)[0]*np.cos(np.arcsin(rr[j]/r_temp[k]))*np.cos(fi)                                                                #
							vel_z_grid_point=velz_interpd(r_temp[k], z_loc)[0]*np.sin(fi)
								                #
							if (vel_r_grid_point+vel_z_grid_point)<=0.:
								                #
								vel_b=-np.sqrt(vel_r_grid_point**2.+vel_z_grid_point**2.)
								                #
							else:                   #
								                #
								vel_b=np.sqrt(vel_r_grid_point**2.+vel_z_grid_point**2.)
								                #
							dist=(np.sqrt(r_temp[k]**2+r_temp[k+1]**2-2*r_temp[k]*r_temp[k+1]*np.cos(np.arcsin(rr[j]/r_temp[k+1])-np.arcsin(rr[j]/r_temp[k]))))/np.cos(fi)                           #
									        #
							S_c_b, k_ext_b, S_line_b, Line_abs_b=sourcef.sourcef(T_grid_point, freq, dens_grid_point, Xrat, Einstein_A, mol_grid_point, X_DoI, g1, g2, LTE)		                #
							I_b=rad_tran_eq_integration.rad_tran_eq_integration(freq, vel_a, vel_b, dist, freq_0, Dfreq_thermal_grid_point, I_a, S_c_a, S_c_b, S_line_a, S_line_b, Line_abs_a, Line_abs_b, k_ext_a, k_ext_b)
										#
							Itotal=I_b+Itotal       #
									        #
							I_a, vel_a, S_line_a, Line_abs_a, S_c_a, k_ext_a=I_b, vel_b, S_line_b, Line_abs_b, S_c_b, k_ext_b                                                                         #
							#   Time to update the  #
							#     value of "z_loc"  #
									        #
							z_loc = z_loc + dist*np.sin(fi)
									        #
						ILOS[m]=Itotal                  #
										#
					ILOS=np.array(ILOS).astype(float)       #
								                #
					rows[j]=ILOS                            #
								                #
				rows=np.array(rows).astype(float)               #
								                #
				emission[i]=rows                                #
								                #
			emission=np.array(emission)                             #
								                #
			emission_gathered=comm.gather(emission, root=0)         #
								                #
			if iproc==0:                                            #
								                #
				emission=np.array(emission_gathered).astype(float)
								                #
				size2=emission.shape                            #
								                #
				emission=emission.reshape(nproc*size2[1], size2[2], size2[3])
								                #
				emission = units_ch.units_ch(units, emission, beam_size, freq0, freq_range0)
								                #
				PPV=PPV.PPV(freq_range, emission, rr, noise, ppv, beam, eSNR, mean, beam_size, distance)
								                #
				PPV2=np.fliplr(PPV)                             #
								                #	
				PPV=np.hstack((PPV2, PPV))                      #
								                #
				np.save('{}/output_files/PPV'.format(working_dir), PPV)
								                #
				y=Z.copy()                                      #
#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -#



#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -#
#		                                                                #
#                                CARTESIAN MAP                                  #
#		          ---------------------------                           #
if geom==2:                                                                     #
                                                                                #
	if fi0==0. and th0==0.:                                                 #
                                                                                #
		dist=z[1]-z[0]                                                  #
                                                                                #
		chopped_ys=np.empty(size[0]/nproc, dtype=np.float64)            #
                                                                                #
		comm.Scatter([y, MPI.DOUBLE], [chopped_ys, MPI.DOUBLE])         #
                                                                                #
		#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -#
		#                   "EDGE ON" MAP                               #
		#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -#
				                                                #
		emission=[]                                                     #
					                                        #
		pr=0.                                                           #
					                                        #
		for i in range (0, len(chopped_ys)):                            #
								                # 
			pr = pr + 1./len(chopped_ys)                            #
							                        #
			if iproc==0:                                            #
							                        #
				update_progress(pr)                             #
							                        #
			rows=np.empty((len(x), len(freq_range)))                #
							                        #
			index=np.where(y==chopped_ys[i])[0][0]                  #
							                        #
			for j in range (0, len(x)):                             #
							                        #
				ILOS=np.empty(len(freq_range))                  #
							                        #
				for m in range (len(freq_range)-1, -1, -1):     #
									        #
					freq=freq_range[m]                      #
								                #
					vel_a, S_line_a, Itotal, Line_abs_a, S_c_a, k_ext_a=0., 0., 0., 0., 0., 0.
	 								        #
					if Tbgr==0.:                            #
								                #
						I_a=0.                          #
					else:                                   #
						I_a=planck.planck(Tbgr, freq)   #
									        #
					for k in range (0, len(z)):             #
						                                #
						dens_grid_point=dens[index, j, k] 
										#
						vel_b=velz[index, j, k]         #
										#
						mol_grid_point=mol[index, j, k] #
									        #
						T_grid_point=T[index, j, k]     #
									        #
						Dfreq_thermal_grid_point=Dfreq_thermal[index, j, k]
									        #
						Xrat=PopRat[index, j, k]        #
									        #
						S_c_b, k_ext_b, S_line_b, Line_abs_b=sourcef.sourcef(T_grid_point, freq, dens_grid_point, Xrat, Einstein_A, mol_grid_point, X_DoI, g1, g2, LTE)         #
						I_b=rad_tran_eq_integration.rad_tran_eq_integration(freq, vel_a, vel_b, dist, freq_0, Dfreq_thermal_grid_point, I_a, S_c_a, S_c_b, S_line_a, S_line_b, Line_abs_a, Line_abs_b, k_ext_a, k_ext_b)
										#
						Itotal=I_b+Itotal               #
								                #
						I_a, vel_a, S_line_a, Line_abs_a, S_c_a, k_ext_a=I_b, vel_b, S_line_b, Line_abs_b, S_c_b, k_ext_b                                                                         #
					ILOS[m]=Itotal                          #
									        #
				ILOS=np.array(ILOS).astype(float)               #
							                        #
				rows[j]=ILOS                                    #
							                        #
			rows=np.array(rows).astype(float)                       #
							                        #
			emission.append(rows)                                   #
							                        #
		emission=np.array(emission)                                     #
							                        #
		emission_gathered=comm.gather(emission, root=0)                 #
							                        #
		if iproc==0:                                                    #
							                        #
			emission=np.array(emission_gathered).astype(float)      #
							                        #
			size2=emission.shape                                    #
							                        #
			emission=emission.reshape(nproc*size2[1], size2[2], size2[3])
							                        #
			emission = units_ch.units_ch(units, emission, beam_size, freq0, freq_range0)
							                        #
			r=z.copy()                                              #
							                        #
			PPV=PPV.PPV(freq_range, emission, r, noise, ppv, beam, eSNR, mean, beam_size, distance) 
								                #
			np.save('{}/output_files/PPV'.format(working_dir), PPV) #
                                                                                #
	else:                                                                   #
                                                                                #
		chopped_ys=np.empty(len(Y)/nproc, dtype=np.float64)             #   or size[0] instead of len(Y)
                                                                                #
		comm.Scatter([Y, MPI.DOUBLE], [chopped_ys, MPI.DOUBLE])         #
                                                                                #
		dist=z[1]-z[0]                                                  #
                                                                                #	
		dz=z[1]-z[0]                                                    #
                                                                                #
		dist=dist/np.cos(fi)/np.cos(th)                                 #
                                                                                #
		emission=[]                                                     #
					                                        #
		pr=0.                                                           #
					                                        #
		for i in range (0, len(chopped_ys)):                            #
								                # 
			pr = pr + 1./len(chopped_ys)                            #
							                        #
			if iproc==0:                                            #
							                        #
				update_progress(pr)                             #
							                        #
			rows=np.empty((len(X), len(freq_range)))                #
							                        #
			for j in range (0, len(X)):                             #
							                        #
				ILOS=np.empty(len(freq_range))                  #
							                        #
				for m in range (len(freq_range)-1, -1, -1):     #
									        #
					y_loc=chopped_ys[i]                     #
							                        #
					x_loc=X[j]                              #
							                        #
					freq=freq_range[m]                      #
								                #
					vel_a, S_line_a, Itotal, Line_abs_a, S_c_a, k_ext_a=0., 0., 0., 0., 0., 0.
	 								        #
					if Tbgr==0.:                            #
								                #
						I_a=0.                          #
					else:                                   #
						I_a=planck.planck(Tbgr, freq)   #
								                #
					for k in range (0, len(z)):             #
						                                # 
						dens_grid_point=dens_interpd((y_loc, x_loc, z[k]))
										#
						mol_grid_point=mol_interpd((y_loc, x_loc, z[k]))
										#
						vz_kcomponent=velz_interpd((y_loc, x_loc, z[k]))*np.cos(th)*np.cos(fi)
										#
						vx_kcomponent=velx_interpd((y_loc, x_loc, z[k]))*np.sin(fi)
										#
						vy_kcomponent=vely_interpd((y_loc, x_loc, z[k]))*np.sin(th)
										#
						T_grid_point=T_interpd((y_loc, x_loc, z[k]))
										#
						Dfreq_thermal_grid_point=Dfreq_thermal_interpd((y_loc, x_loc, z[k]))
										#
						Xrat = PopRat_interpd((y_loc, x_loc, z[k]))
										#
						if (vz_kcomponent+vy_kcomponent+vx_kcomponent)<0.:
		                                                                #
							vel_b=-np.sqrt(vz_kcomponent**2+vy_kcomponent**2+vx_kcomponent**2+2*(vz_kcomponent*vy_kcomponent+vz_kcomponent*vx_kcomponent+vx_kcomponent*vy_kcomponent))
		                                                                #
						else:                           #
							vel_b=np.sqrt(vz_kcomponent**2+vy_kcomponent**2+vx_kcomponent**2+2*(vz_kcomponent*vy_kcomponent+vz_kcomponent*vx_kcomponent+vx_kcomponent*vy_kcomponent))
									        #
						S_c_b, k_ext_b, S_line_b, Line_abs_b=sourcef.sourcef(T_grid_point, freq, dens_grid_point, Xrat, Einstein_A, mol_grid_point, X_DoI, g1, g2, LTE)		   #
						I_b=rad_tran_eq_integration.rad_tran_eq_integration(freq, vel_a, vel_b, dist, freq_0, Dfreq_thermal_grid_point, I_a, S_c_a, S_c_b, S_line_a, S_line_b, Line_abs_a, Line_abs_b, k_ext_a, k_ext_b)
										#
						Itotal=I_b+Itotal               #
								                #
						I_a, vel_a, S_line_a, Line_abs_a, S_c_a, k_ext_a=I_b, vel_b, S_line_b, Line_abs_b, S_c_b, k_ext_b                                                                         #
						#x_loc=x_loc-dz*np.tan(fi)      #
					                                        #
						#y_loc=y_loc-dz*np.tan(th)      #
									        #
					ILOS[m]=Itotal                          #
									        #
				ILOS=np.array(ILOS).astype(float)               #
							                        #
				rows[j]=ILOS                                    #
							                        #
			rows=np.array(rows).astype(float)                       #
							                        #
			emission.append(rows)                                   #
							                        #
		emission=np.array(emission)                                     #
							                        #
		emission_gathered=comm.gather(emission, root=0)                 #
							                        #
		if iproc==0:                                                    #
							                        #
			emission=np.array(emission_gathered).astype(float)      #
							                        #
			size2=emission.shape                                    #
							                        #
			emission=emission.reshape(nproc*size2[1], size2[2], size2[3])
							                        #
			emission = units_ch.units_ch(units, emission, beam_size, freq0, freq_range0)
							                        #
			r=z.copy()                                              #
							                        #
			PPV=PPV.PPV(freq_range, emission, r, noise, ppv, beam, eSNR, mean, beam_size, distance)
								                #
			np.save('{}/output_files/PPV'.format(working_dir), PPV) #
							                        #
			x=X.copy()                                              #
							                        #
			y=Y.copy()                                              #
#-------------------------------------------------------------------------------#


#-------------------------------------------------------------------------------#
#                         Bin the frequencies                                   #
#                                                                               #
if iproc==0:                                                                    #
                                                                                #
	if bins==True:                                                          #
                                                                                #
		freq_range, PPV = binning.binning(freq_range, PPV, nbins, BINS, spectr_res, DSR)
#-------------------------------------------------------------------------------#


#-------------------------------------------------------------------------------#
#                                                                               #
#                              PLOTTING                                         #
#                                                                               #
#-------------------------------------------------------------------------------#
import matplotlib.pyplot as plt                                                 #
import matplotlib.ticker as ticker                                              #
from mpl_toolkits.axes_grid1 import make_axes_locatable                         #
import matplotlib                                                               #
from matplotlib import ticker                                                   #
tick_locator = ticker.MaxNLocator(nbins=4)                                      #
from matplotlib.ticker import ScalarFormatter, FormatStrFormatter               #
from pylab import *                                                             #
from matplotlib.ticker import MultipleLocator                                   #
from mpl_toolkits.axes_grid1 import make_axes_locatable, ImageGrid              #
import matplotlib.gridspec as gridspec                                          #
                                                                                #
                                                                                #
plt.rcParams.update({'font.size': 15})                                          #  
matplotlib.rcParams['pdf.fonttype'] = 42                                        #
plt.rcParams['ps.fonttype'] = 42                                                #
                                                                                #
#     Just a function so that the colorbar does not appear screwed up           #
def fmt(x, pos):                                                                #
    a, b = '{:.3e}'.format(x).split('e')                                        #
    b = int(b)                                                                  #
    return r'${} \times 10^{{{}}}$'.format(a, b)                                #
                                                                                #
#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -#
#                                                                               #
#                                                                               #
#        To convert the x-axis to velocity you can simply do:                   #
#                                                                               #
#                       v_radio=c*(f0-f)/f0                                     #
#                                                                               #
#-------------------------------------------------------------------------------#


#-------------------------------------------------------------------------------#
if not os.path.exists('{}/plots'.format(working_dir)):                          #
		                                                                #
	os.mkdir('{}/plots'.format(working_dir))                                #
		                                                                #
if iproc==0:                                                                    #
		                                                                #
	if line==True:                                                          #
		                                                                #
		fig, ax =plt.subplots()                                         #
		                                                                #
		ax.plot(freq_range[::-1]*c/1.e+9, PPV, ls='steps', c='k', linewidth=1.5)
		                                                                #
		ax.get_xaxis().get_major_formatter().set_useOffset(False)       #
		                                                                #
		ax.get_xaxis().get_major_formatter().set_scientific(False)      #
		                                                                #
		ax.get_yaxis().get_major_formatter().set_scientific(True)       #
		                                                                #
		ax2 = ax.twiny()                                                #
		                                                                #
		veloc=np.linspace(-window/freq0*c, window/freq0*c, 6)*1e-5      #
		                                                                #
		veloc=np.round(veloc, 2)                                        #
		                                                                #
		ax2.set_xticklabels([veloc[0], veloc[1], veloc[2], veloc[3], veloc[4], veloc[5]])
		                                                                #
		ax2.set_xlabel("velocity [km/s]", fontsize=22)                  #
		                                                                #
		ax.set_xlabel(r"$\mathregular{\nu}$"" [GHz]", fontsize=22)      #
		                                                                #
		if units==0:                                                    #
			ax.set_ylabel(r"$\mathregular{\nu}$" r"$\mathregular{F_{\nu}}$" "[erg " r"$\mathregular{cm^{-2}}$" r"$\mathregular{s^{-1}}$"']', fontsize=22)                                                             #
		elif units==1:                                                  #
			ax.set_ylabel("mJy", fontsize=22)                       #
		                                                                #
		elif units==2:                                                  #
			ax.set_ylabel(r"$\mathregular{T_{mb}}$" " (K)", fontsize=22)
		                                                                #
		start, end = ax.get_xlim()                                      #
		                                                                #
		ax.xaxis.set_ticks(np.linspace(start, end, 5))                  #
		                                                                #
		ax.ticklabel_format(style='plain', axis='y', scilimits=(0,0))   #
		                                                                #
		ax.set_xticklabels([round(freq_range[npoints-1]*c/1.e+9, 4), round(freq_range[npoints/2.+npoints/4.]*c/1.e+9, 4), round(freq_range[npoints/2.]*c/1.e+9, 4), round(freq_range[npoints/4.]*c/1.e+9, 4), round(freq_range[0]*c/1.e+9, 4)])
		                                                                #
		plt.savefig('{}/plots/line'.format(working_dir, i))             #
		                                                                #
		plt.show()                                                      #
		                                                                #
		#                     Velocity/frequency Maps                   #
		#          and integrated intensity if PPV[0, 0]==float         #
	else:                                                                   #
		if isinstance(PPV[0, 0], float):                                #
		                                                                #
			plt.imshow(PPV, cmap='hot')                             #
		                                                                #
			plt.colorbar()                                          #
		                                                                #
			plt.savefig('{}/plots/slice_{:03}'.format(working_dir, i))
		                                                                #
			plt.show()                                              #
		                                                                #
		else:                                                           #
			                                                        #
			for i in range (0, len(freq_range)):                    #
			                                                        #
				veloc=np.linspace(-window/freq0*c, window/freq0*c, 6)*1e-5
									        #
				f=plt.figure(figsize=(12, 18))                  #
				                                                #
				gs = gridspec.GridSpec(2, 1, height_ratios=[3, 1])  
							                        #
				ax1 = plt.subplot(gs[0])                        #
								                #
				ax2 = plt.subplot(gs[1])                        #
								                #
				im1=ax1.imshow(PPV[:, :, i], cmap='hot', vmin=np.min(PPV), vmax=np.max(PPV))
							                        #
				divider1 = make_axes_locatable(ax1)             #
								                #
				cax1 = divider1.append_axes("right", size="5%", pad=0.0)
						                                #
				cbar1 = plt.colorbar(im1, cax=cax1)             #
							                        #
				ax1.set_xticks([len(x)*0, len(x)*1/4.0, len(x)*2/4.0, len(x)*3/4.0, len(x)-1]) 
							                        #
				ax1.set_xticklabels([round(x[len(x)*0]/parsec, 2), round(x[len(x)*1/4]/parsec, 2), round(x[len(x)*2/4]/parsec, 2), round(x[len(x)*3/4]/parsec, 2), round(x[len(x)-1]/parsec, 2)])                  #
							                        #
				ax1.set_yticks([len(y)*0, len(y)*1/4.0, len(y)*2/4.0, len(y)*3/4.0, len(y)-1]) 
							                        #
				ax1.set_yticklabels([round(y[len(y)*0]/parsec, 2), round(y[len(y)*1/4]/parsec, 2), round(y[len(y)*2/4]/parsec, 2), round(y[len(y)*3/4]/parsec, 2), round(y[len(y)-1]/parsec, 2)])                  #
							                        #
				ax1.set_ylabel('pc')                            #
							                        #
				ax1.set_xlabel('pc')                            #
							                        #
				ax1.set_ylim(0, len(PPV)-1)                     #
							                        #
				ax2.plot(freq_range*c/1.e+9, PPV[len(PPV)/2, len(PPV[0])/2, :], ls='steps', linewidth=2.0, color='k')
							                        #
				vbarx=np.ones(15)*freq_range[i]*c/1.e+9         #
							                        #
				vbary=np.linspace(min(PPV[len(PPV)/2, len(PPV[0])/2, :]), max(PPV[len(PPV)/2, len(PPV[0])/2, :]), 15)
							                        #
				ax2.plot(vbarx, vbary, 'r', linewidth=1.2)      #
							                        #
				ax2.get_xaxis().get_major_formatter().set_useOffset(False) 
								                #
				ax2.get_xaxis().get_major_formatter().set_scientific(False)
								                #
				veloc=np.round(veloc, 2)                        #
								                #
				ax3 = ax2.twiny()                               #
								                #
				ax3.set_xticklabels([veloc[0], veloc[1], veloc[2], veloc[3], veloc[4], veloc[5]])
								                #
				start, end = ax2.get_xlim()                     #
								                #
				ax2.xaxis.set_ticks(np.linspace(start, end, 5)) #
		                                                                #
				ax2.set_xticklabels([round(freq_range[63]*c/1.e+9, 4), round(freq_range[48]*c/1.e+9, 4), round(freq_range[32]*c/1.e+9, 4), round(freq_range[16]*c/1.e+9, 4), round(freq_range[0]*c/1.e+9, 4)])
		                                                                #
				ax3.set_xlabel("velocity (km/s)")               #
								                #
				ax2.set_xlabel(r"$\nu$"" GHz")                  #
								                #
				if units==0:                                    #
					ax2.set_ylabel(r"$\mathregular{\nu}$" r"$\mathregular{F_{\nu}}$" "[erg " r"$\mathregular{cm^{-2}}$" r"$\mathregular{s^{-1}}$"']', fontsize=22)                                         #
				elif units==1:                                  #
					ax2.set_ylabel("mJy", fontsize=22)      #
						                                #
				elif units==2:                                  #
					ax2.set_ylabel(r"$\mathregular{T_mb}$" " (K)", fontsize=22)
						                                #
				f.savefig('{}/plots/slice_{:03}'.format(working_dir, i))
							                        #
				plt.close("all")                                #
									        #
				plt.clf()                                       #
#-------------------------------------------------------------------------------#


#-------------------------------------------------------------------------------#
#         Be advised! If 'line' equals True then this is not a PPV              #
#         cube. Similarly, if 'ppv' equal False this is 1D sorter               #
#           than a PPV since we have an integrated emission map                 #
if fits==True:                                                                  #
									        #
	if iproc==0:                                                            #
									        #
		PPV=np.rollaxis(PPV, 2)                                         #
									        #
		PPVnew=PPV                                                      #
									        #
		hdu = pyfits.PrimaryHDU(PPVnew)                                 #
									        #
		hdulist = pyfits.HDUList([hdu])                                 #
									        #
		hdulist.writeto('{}/output_files/your_PPV_cube.fits'.format(working_dir))
									        #
		hdulist = pyfits.open('{}/output_files/your_PPV_cube.fits'.format(working_dir), mode='update')
									        #
		prihdr = hdulist[0].header                                      #
									        #
		prihdr.set('LINEFREQ', '{} /GHZ'.format(freq0*1e+9))            #
									        #
		#            sure, I know that this is wrong unless             #
		#               window_l=window_r, but.....                     #
		prihdr.set('BW', '{} /GHZ'.format((window_l+window_r)*0.5))     #
									        #
		prihdr.set('LINENAME', '{}'.format(molecule))                   #
									        #
		prihdr.set('COMMENT', "Your own simulated PPV cube. Enjoy :)")  #
									        #
		hdulist.flush()                                                 #
									        #
		hdulist.close()                                                 #
									        #
#-------------------------------------------------------------------------------#

#-------------------------------------------------------------------------------#
if iproc==0:                                                                    #
				                                                #
	if txtexport==True:                                                     #
				                                                #
		if geom==1:                                                     #
				                                                #
			y, vely=None, None                                      #
				                                                #
			txt_export.txt_export(geom, x, y, z, dens, mol, velx, vely, velz, PopRat)
				                                                #
		elif geom==0:                                                   #
				                                                #
			y, vely, z, velz=None, None, None, None                 #
				                                                #
	 		txt_export.txt_export(geom, x, y, z, dens, mol, velx, vely, velz, PopRat)
				                                                #
		elif geom==2:                                                   #
				                                                #
	 		txt_export.txt_export(geom, x, y, z, dens, mol, velx, vely, velz, PopRat)
#-------------------------------------------------------------------------------#
