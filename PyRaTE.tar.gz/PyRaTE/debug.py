#----------------------------------------------------------------------------# 
#  NAME:                                                                     #
#                                                                            #
#  debug.py                                                                  #
#                                                                            #
#                                                                            #
#  DESCRIPTION:                                                              #
#                                                                            #
#  There are a million things that can go wrong and without having           #
#  too much knowledge about the guts of the code it can be really hard       #
#  to track down what was that went wrong.                                   # 
#                                                                            #
#  The purpose of this module is to at least make sure that what you are     #
#  putting into the main routines is ok.                                     #  
#                                                                            #
#                                                                            #
#  PARAMETERS:                                                               #
#                                                                            #
#     Input : geom, dens, mol, (x, y, z)/(r, z)/(r), Dfreq_thermal, T, C12   #
#             velocities, Einstein_A                                         #
#     Output : Plots/Messages                                                # #                                                                            #
#  AUTHOR:                                                                   #           
#                                                                            #
#  Aris E. Tritsis                                                           #
#  (Aris.Tritsis@anu.edu.au)                                                 #
#                                                                            #
#----------------------------------------------------------------------------#

#----------------------------------------------------------------------------#
import numpy as np                                                           #
import matplotlib.pyplot as plt                                              #
from scipy.constants import parsec, m_p                                      #
import matplotlib.ticker as ticker                                           #
from mpl_toolkits.axes_grid1 import make_axes_locatable                      #
import matplotlib                                                            #
from matplotlib import ticker                                                #
tick_locator = ticker.MaxNLocator(nbins=4)                                   #
from matplotlib.ticker import ScalarFormatter, FormatStrFormatter            #
from pylab import *                                                          #
from matplotlib.ticker import MultipleLocator                                #
from mpl_toolkits.axes_grid1 import make_axes_locatable, ImageGrid           #
import matplotlib.gridspec as gridspec                                       #
                                                                             #
plt.rcParams.update({'font.size': 15})                                       #  
matplotlib.rcParams['pdf.fonttype'] = 42                                     #
plt.rcParams['ps.fonttype'] = 42                                             #
                                                                             #
m_p=m_p*1e+3                                                                 #
parsec=parsec*1e+2                                                           #
#----------------------------------------------------------------------------#

#----------------------------------------------------------------------------#
def debug(geom, dens, mol, x, y, z, Dfreq_thermal, T, C21, velx, vely, velz, Einstein_A, freq0, amu):
                                                                             #
	#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - #
	#                        Spherical Part                              #
	#          First check that everything has the same dimensions       #
	#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - #
	if geom==0:                                                          #
                                                                             #
		if (x.shape!=mol.shape) or (x.shape!=velx.shape) or (x.shape!=T.shape) or (x.shape!=Dfreq_thermal.shape) or (x.shape!=dens.shape): 
                                                                             #
			print(" "*30+"Crap!!The shape of matrices differs!") #
			print(" "*30+"Density length is {}".format(dens.shape))
			print(" "*30+"Molecule length is {}".format(mol.shape))
			print(" "*30+"Velocity length is {}".format(velx.shape))
			print(" "*30+"Temperature length is {}".format(T.shape))
			print(" "*30+"radius length is {}".format(x.shape))  #
			print(" "*30+"Thermal width matrix length is {}".format(Dfreq_thermal.shape))
                                                                             #
		else:                                                        #
			print(" "*30+"All arrays have the same size")        #
                                                                             #
		#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - #
		#               Now check for NaN values                     #
		#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - #
		Nans=np.array([np.isnan(dens).any(), np.isnan(mol).any(), np.isnan(velx).any(), np.isnan(T).any(), np.isnan(Dfreq_thermal).any(), np.isnan(C21), np.isnan(Einstein_A), np.isnan(amu), np.isnan(freq0)])        #
		if np.isnan(Nans).any()==True:                               #
                                                                             #
			print(" "*30+"Aha!! I found a NaN value!!")          #
                                                                             #
			if np.isnan(C21)==True or np.isnan(Einstein_A)==True or np.isnan(amu)==True or np.isnan(freq0)==True:
                                                                             #
				print(" "*30+"Something is wrong with 'txtreader.py' module!")
				print(" "*30+"Try to find A, C, amu, freq in *.dat in /lambda and define them just before 'return'")
			else:                                                #
                                                                             #
				print(" "*30+"Seems that molecular data were read fine")
				print(" "*30+"Hopefully, there isn't something wrong with your simulation and it's PyRaTE's problem")
				print(" "*30+"Are you running in parallel? Have you modified the code? If so, be careful defining 'Nones'")
                                                                             #
		#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - #
		#       Now make a multipanel plot and return so that        #
		#         the user can check if something is wrong           #
		#                   with the input data                      #
 		#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - #
		fig=plt.figure()                                             #
		ax1=fig.add_subplot(221)   #top left                         #
		ax2=fig.add_subplot(222)   #top right                        #
		ax3=fig.add_subplot(223)   #bottom left                      #
		ax4=fig.add_subplot(224)   #bottom right                     #
		#- - -  - - - - - - - - - - - - - - - - - - - - - - - - - - -#
		ax1.plot(x/parsec, dens/m_p/2.4, 'k', linewidth=2.0)         #
		ax1.set_title('Density')                                     #
		ax1.set_xlabel('pc', fontsize=22)                            #
		ax1.set_ylabel(r"$\mathregular{n_{H_2}}$" " "r"$\mathregular{(cm^{-3})}$", fontsize=22)
		ax1.ticklabel_format(style='sci', axis='y', scilimits=(0,0)) #
		start, end = ax1.get_xlim()                                  #
		ax1.xaxis.set_ticks(np.linspace(start, end, 3))              #
		#- - -  - - - - - - - - - - - - - - - - - - - - - - - - - - -#
		ax2.plot(x/parsec, velx*1e-5, 'k', linewidth=2.0)            #
		ax2.set_title('Velocity')                                    #
		ax2.set_xlabel('pc', fontsize=22)                            #
		ax2.set_ylabel('km ' r"$\mathregular{s^{-1}}$", fontsize=22) #
		ax2.ticklabel_format(style='sci', axis='y', scilimits=(0,0)) #
		start, end = ax2.get_xlim()                                  #
		ax2.xaxis.set_ticks(np.linspace(start, end, 3))              #
		#- - -  - - - - - - - - - - - - - - - - - - - - - - - - - - -#
		ax3.plot(x/parsec, mol, 'k', linewidth=2.0)                  #
		ax3.set_title('Abundance')                                   #
		ax3.set_ylabel(r"$\mathregular{n_{CO}/n_{H_2}}$", fontsize=22) 
		ax3.set_xlabel('pc', fontsize=22)                            #
		ax3.ticklabel_format(style='sci', axis='y', scilimits=(0,0)) #
		start, end = ax3.get_xlim()                                  #
		ax3.xaxis.set_ticks(np.linspace(start, end, 3))              #
		#- - -  - - - - - - - - - - - - - - - - - - - - - - - - - - -#
		ax4.plot(x/parsec, T, 'k', linewidth=2.0)                    #
		ax4.set_title('Temperature')                                 #
		ax4.set_xlabel('pc', fontsize=22)                            #
		ax4.set_ylabel('K', fontsize=22)                             #
		start, end = ax4.get_xlim()                                  #
		ax4.xaxis.set_ticks(np.linspace(start, end, 3))              #
	#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - #
	#                        Cylindrical Part                            #
	#          First check that everything has the same dimensions       #
	#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - #
	if geom==1:                                                          #
                                                                             #
		if (dens.shape!=mol.shape) or (dens.shape!=velx.shape) or (dens.shape!=T.shape) or (dens.shape!=Dfreq_thermal.shape) or (dens.shape!=velz.shape):                                                                #
                                                                             #
			print(" "*30+"Crap!!The shape of matrices differs!") #
			print(" "*30+"Density length is {}".format(dens.shape))
			print(" "*30+"Molecule length is {}".format(mol.shape))
			print(" "*30+"Velocity length r is {}".format(velx.shape))
			print(" "*30+"Velocity length z is {}".format(velz.shape))
			print(" "*30+"Temperature length is {}".format(T.shape))
			print(" "*30+"Thermal width matrix length is {}".format(Dfreq_thermal.shape))
                                                                             #
		else:                                                        #
			print(" "*30+"All arrays have the same size")        #
                                                                             #
		#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - #
		#               Now check for NaN values                     #
		#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - #
		Nans=np.array([np.isnan(dens).any(), np.isnan(mol).any(), np.isnan(velx).any(), np.isnan(T).any(), np.isnan(Dfreq_thermal).any(), np.isnan(C21), np.isnan(Einstein_A), np.isnan(amu), np.isnan(freq0), np.isnan(velz).any()])
		if np.isnan(Nans).any()==True:                               #
                                                                             #
			print(" "*30+"Aha!! I found a NaN value!!")          #
                                                                             #
			if np.isnan(C21)==True or np.isnan(Einstein_A)==True or np.isnan(amu)==True or np.isnan(freq0)==True:
                                                                             #
				print(" "*30+"Something is wrong with 'txtreader.py' module!")
				print(" "*30+"Try to find A, C, amu, freq in *.dat in /lambda and define them just before 'return'")
			else:                                                #
                                                                             #
				print(" "*30+"Seems that molecular data were read fine")
				print(" "*30+"Hopefully, there isn't something wrong with your simulation and it's PyRaTE's problem")
				print(" "*30+"Are you running in parallel? Have you modified the code? If so, be careful defining 'Nones'")
                                                                             #
		#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - #
		#       Now make a multipanel plot and return so that        #
		#         the user can check if something is wrong           #
		#                   with the input data                      #
 		#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - #
		fig=plt.figure()                                             #
		ax1=fig.add_subplot(221)   #top left                         #
		ax2=fig.add_subplot(222)   #top right                        #
		ax3=fig.add_subplot(223)   #bottom left                      #
		ax4=fig.add_subplot(224)   #bottom right                     #
		#- - -  - - - - - - - - - - - - - - - - - - - - - - - - - - -#
		im1=ax1.imshow(dens/m_p/2.4, cmap='hot')                     #
		divider1 = make_axes_locatable(ax1)                          #
		cax1 = divider1.append_axes("right", size="5%", pad=0.0)     #
		cbar1 = plt.colorbar(im1, cax=cax1)                          #
		ax1.set_title('Density')                                     #
		#- - -  - - - - - - - - - - - - - - - - - - - - - - - - - - -#
		im2=ax2.imshow(velx, cmap='hot')                             #
		divider2 = make_axes_locatable(ax2)                          #
		cax2 = divider2.append_axes("right", size="5%", pad=0.0)     #
		cbar2 = plt.colorbar(im2, cax=cax2)                          #
		ax2.set_title('Velocity-r')                                  #
		#- - -  - - - - - - - - - - - - - - - - - - - - - - - - - - -#
		im3=ax3.imshow(mol, cmap='hot')                              #
		divider3 = make_axes_locatable(ax3)                          #
		cax3 = divider3.append_axes("right", size="5%", pad=0.0)     #
		cbar3 = plt.colorbar(im3, cax=cax3)                          #
		ax3.set_title('Abundance')                                   #
		#- - -  - - - - - - - - - - - - - - - - - - - - - - - - - - -#
		im4=ax4.imshow(velz, cmap='hot')                             #
		divider4 = make_axes_locatable(ax4)                          #
		cax4 = divider4.append_axes("right", size="5%", pad=0.0)     #
		cbar4 = plt.colorbar(im4, cax=cax4)                          #
		ax4.set_title('Velocity-z')                                  #
	#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - #
	#                        Cartesia Part                               #
	#          First check that everything has the same dimensions       #
	#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - #
	if geom==2:                                                          #
                                                                             #
		if (dens.shape!=mol.shape) or (dens.shape!=velx.shape) or (dens.shape!=T.shape) or (dens.shape!=Dfreq_thermal.shape) or (dens.shape!=velz.shape) or (dens.shape!=vely.shape):                                    #
                                                                             #
			print(" "*30+"Crap!!The shape of matrices differs!") #
			print(" "*30+"Density length is {}".format(dens.shape))
			print(" "*30+"Molecule length is {}".format(mol.shape))
			print(" "*30+"Velocity length x is {}".format(velx.shape))
			print(" "*30+"Velocity length y is {}".format(velx.shape))
			print(" "*30+"Velocity length z is {}".format(velz.shape))
			print(" "*30+"Temperature length is {}".format(T.shape))
			print(" "*30+"Thermal width matrix length is {}".format(Dfreq_thermal.shape))
                                                                             #
		else:                                                        #
			print(" "*30+"All arrays have the same size")        #
                                                                             #
		#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - #
		#               Now check for NaN values                     #
		#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - #
		Nans=np.array([np.isnan(dens).any(), np.isnan(mol).any(), np.isnan(velx).any(), np.isnan(T).any(), np.isnan(Dfreq_thermal).any(), np.isnan(C21), np.isnan(Einstein_A), np.isnan(amu), np.isnan(freq0), np.isnan(vely).any(), np.isnan(velz).any()])
		if np.isnan(Nans).any()==True:                               #
                                                                             #
			print(" "*30+"Aha!! I found a NaN value!!")          #
                                                                             #
			if np.isnan(C21)==True or np.isnan(Einstein_A)==True or np.isnan(amu)==True or np.isnan(freq0)==True:
                                                                             #
				print(" "*30+"Something is wrong with 'txtreader.py' module!")
				print(" "*30+"Try to find A, C, amu, freq in *.dat in /lambda and define them just before 'return'")
			else:                                                #
                                                                             #
				print(" "*30+"Seems that molecular data were read fine")
				print(" "*30+"Hopefully, there isn't something wrong with your simulation and it's PyRaTE's problem")
				print(" "*30+"Are you running in parallel? Have you modified the code? If so, be careful defining 'Nones'")
                                                                             #
		#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - #
		#       Now make a multipanel plot and return so that        #
		#         the user can check if something is wrong           #
		#                   with the input data                      #
 		#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - #
		fig=plt.figure()                                             #
		ax1=fig.add_subplot(221)   #top left                         #
		ax2=fig.add_subplot(222)   #top right                        #
		ax3=fig.add_subplot(223)   #bottom left                      #
		ax4=fig.add_subplot(224)   #bottom right                     #
		#- - -  - - - - - - - - - - - - - - - - - - - - - - - - - - -#
		im1=ax1.imshow(dens.sum(axis=0)/m_p/2.4, cmap='hot')         #
		divider1 = make_axes_locatable(ax1)                          #
		cax1 = divider1.append_axes("right", size="5%", pad=0.0)     #
		cbar1 = plt.colorbar(im1, cax=cax1)                          #
		ax1.set_title('Density')                                     #
		#- - -  - - - - - - - - - - - - - - - - - - - - - - - - - - -#
		im2=ax2.imshow(velx.sum(axis=0), cmap='hot')                 #
		divider2 = make_axes_locatable(ax2)                          #
		cax2 = divider2.append_axes("right", size="5%", pad=0.0)     #
		cbar2 = plt.colorbar(im2, cax=cax2)                          #
		ax2.set_title('Velocity-x')                                  #
		#- - -  - - - - - - - - - - - - - - - - - - - - - - - - - - -#
		im3=ax3.imshow(vely.sum(axis=0), cmap='hot')                 #
		divider3 = make_axes_locatable(ax3)                          #
		cax3 = divider3.append_axes("right", size="5%", pad=0.0)     #
		cbar3 = plt.colorbar(im3, cax=cax3)                          #
		ax3.set_title('Velocity-y')                                  #
		#- - -  - - - - - - - - - - - - - - - - - - - - - - - - - - -#
		im4=ax4.imshow(velz.sum(axis=0), cmap='hot')                 #
		divider4 = make_axes_locatable(ax4)                          #
		cax4 = divider4.append_axes("right", size="5%", pad=0.0)     #
		cbar4 = plt.colorbar(im4, cax=cax4)                          #
		ax4.set_title('Velocity-z')                                  #
		#------------------------------------------------------------#
		#   Feel free to modify the code to double check more things #
		#------------------------------------------------------------#
                                                                             #
	return fig                                                           #
#----------------------------------------------------------------------------#
