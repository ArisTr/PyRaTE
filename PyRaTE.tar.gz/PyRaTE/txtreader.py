#-------------------------------------------------------------------------#
#  NAME:                                                                  #
#                                                                         #
#  txtreader.py                                                           #
#                                                                         #
#  DESCRIPTION:                                                           #
#                                                                         #
#   This routine will take care of reading the data from the txt/dat      #
#   files given in the lambda directory. You can download more            #
#   molecular line data from:                                             #
#                                                                         #
#               http://home.strw.leidenuniv.nl/~moldata/                  #
#                                                                         #
#  OUPUT: Einstein A coefficient, molecular weight, frequency in GHz      #
#                                                                         #
#  AUTHOR:                                                                #           
#                                                                         #
#  Aris E. Tritsis                                                        #
#  (Aris.Tritsis@anu.edu.au)                                              #
#                                                                         #
#  *This module needs to be re-written for clarity.                       #
#-------------------------------------------------------------------------#

#-------------------------------------------------------------------------#
import numpy as np                                                        #
import os                                                                 #
import sys                                                                #
#-------------------------------------------------------------------------#

#-------------------------------------------------------------------------#
#                    Define the path where the files are                  #
                                                                          #
extension = '.dat'                                                        #
                                                                          #
def txtreader(molecule, transition_up, transition_low, working_dir):      #
                                                                          #
	path = working_dir + '/lambda/'                                   #
	                                                                  #
	mole = molecule.lower()                                           #
		                                                          #
	if (os.path.exists(path+mole+extension)):                         #
		                                                          #
		print (" "*10), ("+"*78)                                  #
		print (" "*10), "Using data file", path+mole+extension    #
		print (" "*10), ("+"*78)                                  #
	                                                                  #
		f=open(path+mole+extension)                               #
	                                                                  #
		txt=[]                                                    #
	                                                                  #
		for line in iter(f):                                      #
					                                  #
			txt.append(line)                                  #
					                                  #
		f.close()                                                 #
					                                  #
		amu = float(np.fromstring(txt[3], dtype='float', sep=' '))#
					                                  #
		coll_rate_C21, coll_rate_Cib=[], []                       #
					                                  #
		gij, Eij = [], []                                         #
 					                                  #
		Einstein_A, freq0 = [], []                                #
					                                  #
		for i in range(0, len(txt)):                              #
					                                  #
			if (txt[i]=="!LEVEL + ENERGIES(cm^-1) + WEIGHT + J\n"):
						                          #
				for m in range (0, 20):                   #
						                          #
					temp=np.fromstring(txt[m], dtype='float', sep=' ')
						                          #
					#   try-except here because of    #
					#   fucking numpy distributions   # 
					#          conflicts              #
					try:                              #
								          #
						gij.append(temp[2])       #
							                  #
						Eij.append(temp[1])       #
								          #
					except IndexError:                #
								          #
						pass                      #
						                          #
			if (txt[i]=="!TRANS + UP + LOW + EINSTEINA(s^-1) + FREQ(GHz) + E_u(K)\n"):
							                  #
							                  #
				for j in range (i+1, len(txt)):           #
							                  #
					temp=np.fromstring(txt[j], dtype='float', sep=' ')
						                          #
					Einstein_A.append(temp[3])        #
						                          #
					freq0.append(temp[4])             #
							                  #
					if temp[0]>=10:                   #
 							                  #
						break                     #
						                          #
			if (txt[i]=="!TRANS + UP + LOW + COLLRATES(cm^3 s^-1)\n"):
								          #
				temper=np.fromstring(txt[i-1], dtype='float', sep=' ')
							                  #
				for j in range (i+1, len(txt)):           #
					                                  #
					temp=np.fromstring(txt[j], dtype='float', sep=' ')
					                                  #
					if (temp[1]-temp[2])==1.:         #
						                          #
						coll_rate_C21.append(temp[3:len(temp)])
					                                  #
					elif (temp[1]-temp[2])>1.:        #
					                                  #
						coll_rate_Cib.append(temp[3:len(temp)])
					                                  #
					if temp[1]>=12:                   #
					                                  #
						break                     #
							                  #
		coll_rate_C21, coll_rate_Cib = np.array(coll_rate_C21), np.array(coll_rate_Cib)
						                          #
		gij, Eij = np.array(gij), np.array(Eij)                   #
						                          #
		Einstein_A, freq0 = np.array(Einstein_A), np.array(freq0) #
						                          #
		coll_rate_C21, coll_rate_Cib = coll_rate_C21[0:11], coll_rate_Cib[0:46]
						                          #
		return Einstein_A, amu, freq0, coll_rate_C21, gij, Eij, temper, coll_rate_Cib
	else:                                                             #
		print "Cannot find file: ", path+mole+extension           #
	                                                                  #
		print "Did you looked for an isotope?"                    #
	                                                                  #
		return sys.exit()                                         #
		                                                          #
#-------------------------------------------------------------------------#
