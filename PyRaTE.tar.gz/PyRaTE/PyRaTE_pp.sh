#####------------------------------------------------------------------#####
#####  Which script you will use to submit your job depends on the     #####
#####            setup of the machine you are using                    #####
#####------------------------------------------------------------------#####

#!/bin/bash	
#PBS -N PyRaTE_pp
#PBS -q smallmem
#PBS -l select=1:ncpus=24:mpiprocs=24
#PBS -l place=scatter:excl
#PBS -m bea
#PBS -M Mymail@Mydomain

module load someMPI (e.g. module load mpi/openmpi-x86_64)
source /path-to-yt/yt-x86_64/bin/activate
cd /home/tritsis/PyRaTE/
mpirun ipython main.py>output
                                                 
#!/bin/bash
#PBS -P MyProjectName
#PBS -q normal
#PBS -l walltime=48:00:00
#PBS -l mem=128GB
#PBS -l ncpus=256
#PBS -l wd
#PBS -j oe
#PBS -m bea
#PBS -M Mymail@Mydomain

module load someMPI (e.g. module load openmpi/1.10.3)
source /path-to-yt/yt-x86_64/bin/activate
mpirun -np $PBS_NCPUS ipython main.py > output


#!/bin/bash
#SBATCH --partition=parallel
#SBATCH -N 2
#SBATCH -c 2

module load someMPI (e.g. module load mpi/ofed/mpich2)
source /path-to-yt/yt-x86_64/bin/activate
mpirun -np 20 -ppn 10 python main.py

